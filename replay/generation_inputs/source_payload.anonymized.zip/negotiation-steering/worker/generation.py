"""Single-call generation/capture wrappers with complete execution receipts."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from worker.adapter_base import Site
from worker.receipts import canonical_sha256, summarize_cache, tensor_sha256, weight_fingerprint
from worker.transformers_native import NativeInterventionSession


@dataclass
class ExecutionResult:
    """Receipt plus transient token/cache objects; never serialize the cache."""

    receipt: dict[str, Any]
    sequences: Any = None
    cache: Any = None


def _clean_execution_receipt(receipt: dict[str, Any]) -> dict[str, Any]:
    return {
        **receipt,
        "model_execution": True,
        "research_checkpoint_used": False,
        "scientific_evidence": False,
        "meaning": "Mechanical execution record only; not a behavioral or construct-validity result.",
    }


def generate_with_receipts(
    model: Any,
    inputs: dict[str, Any],
    *,
    trial_id: str,
    sites: list[Site] | None = None,
    max_new_tokens: int,
    min_new_tokens: int | None = None,
    eos_token_id: Any = "USE_MODEL_GENERATION_CONFIG",
) -> ExecutionResult:
    """Execute one greedy generation call, without retries or hidden sampling."""
    import torch

    if isinstance(max_new_tokens, bool) or not isinstance(max_new_tokens, int) or max_new_tokens < 1 or max_new_tokens > 4096:
        raise ValueError("max_new_tokens must be a bounded positive integer.")
    if min_new_tokens is not None and (isinstance(min_new_tokens, bool) or not isinstance(min_new_tokens, int) or not 0 <= min_new_tokens <= max_new_tokens):
        raise ValueError("min_new_tokens must be between zero and max_new_tokens.")
    if not torch.is_tensor(inputs.get("input_ids")) or inputs["input_ids"].ndim != 2 or inputs["input_ids"].shape[0] != 1:
        raise ValueError("Only batch-1 token inputs are supported.")
    local = {name: value.detach().clone() if torch.is_tensor(value) else value for name, value in inputs.items()}
    weights_before = weight_fingerprint(model)
    hooks_before = weight_free_hook_receipt(model)
    was_training = model.training
    model.eval()
    generation_call = {
        "do_sample": False,
        "num_beams": 1,
        "num_return_sequences": 1,
        "use_cache": True,
        "cache_implementation": "dynamic",
        "max_new_tokens": max_new_tokens,
        "return_dict_in_generate": True,
        "output_scores": True,
        "output_hidden_states": False,
        "output_attentions": False,
    }
    if min_new_tokens is not None:
        generation_call["min_new_tokens"] = min_new_tokens
    if eos_token_id != "USE_MODEL_GENERATION_CONFIG":
        generation_call["eos_token_id"] = eos_token_id
    try:
        with torch.inference_mode():
            if sites:
                with NativeInterventionSession(
                    model, sites, trial_id=trial_id, attention_mask=local.get("attention_mask")
                ) as session:
                    output = model.generate(**local, **generation_call)
                trace = session.receipt()
            else:
                output = model.generate(**local, **generation_call)
                trace = None
    finally:
        model.train(was_training)
    weights_after = weight_fingerprint(model)
    if weights_before != weights_after:
        raise RuntimeError("Model parameters or buffers changed during generation.")
    hooks_after = weight_free_hook_receipt(model)
    if hooks_before != hooks_after:
        raise RuntimeError("The model hook registry differs after generation.")
    sequences = output.sequences
    if sequences.ndim != 2 or sequences.shape[0] != 1:
        raise RuntimeError("Generation returned an unexpected sequence shape.")
    input_length = local["input_ids"].shape[1]
    if not torch.equal(sequences[:, :input_length].cpu(), local["input_ids"].cpu()):
        raise RuntimeError("Generation changed the original input prefix.")
    generated = sequences[0, input_length:]
    scores = output.scores
    if len(scores) != generated.numel() or len(scores) > max_new_tokens:
        raise RuntimeError("Generated token and processed-score step counts disagree.")
    processed = []
    for step, score in enumerate(scores):
        if score.ndim != 2 or score.shape[0] != 1:
            raise RuntimeError("Processed logits must be [batch=1, vocabulary].")
        processed.append({
            "step": step,
            "selected_token_id": int(generated[step].item()),
            "shape": list(score.shape),
            "storage_dtype": str(score.dtype),
            "native_sha256": tensor_sha256(score),
        })
    # Do not retain full score tensors in the returned object or evidence receipt.
    output.scores = None
    cache = getattr(output, "past_key_values", None)
    position_state = {name: local[name] for name in ("position_ids", "cache_position") if name in local}
    receipt = _clean_execution_receipt({
        "receipt_kind": "NATIVE_GREEDY_GENERATION_EXECUTION",
        "trial_id": trial_id,
        "generation_call_count": 1,
        "retry_count": 0,
        "operation": "generate_with_recording" if sites else "unchanged_generation",
        "input_token_ids": local["input_ids"][0].detach().cpu().tolist(),
        "generated_token_ids": generated.detach().cpu().tolist(),
        "new_token_count": int(generated.numel()),
        "terminal_reason": "eos" if generated.numel() < max_new_tokens else "max_new_tokens",
        "generation_call": generation_call,
        "loaded_generation_config": model.generation_config.to_dict(),
        "generation_call_sha256": canonical_sha256(generation_call),
        "processed_logit_steps": processed,
        "trace": trace,
        "weights_before": weights_before,
        "weights_after": weights_after,
        "weights_unchanged": True,
        "hooks_before": hooks_before,
        "hooks_after": hooks_after,
        "hook_registry_restored": True,
        "cache_state": summarize_cache(cache, model=model, position_state=position_state or None),
    })
    return ExecutionResult(receipt, sequences.detach().clone(), cache)


def capture_only_with_receipts(
    model: Any,
    inputs: dict[str, Any],
    *,
    trial_id: str,
    sites: list[Site],
    max_selected_values: int = 4096,
) -> ExecutionResult:
    """Run a declared forward without generation or intervention."""
    import torch

    if not sites:
        raise ValueError("Capture-only execution requires declared sites.")
    local = {name: value.detach().clone() if torch.is_tensor(value) else value for name, value in inputs.items()}
    weights_before = weight_fingerprint(model)
    hooks_before = weight_free_hook_receipt(model)
    was_training = model.training
    model.eval()
    try:
        with torch.inference_mode(), NativeInterventionSession(
            model, sites, trial_id=trial_id, attention_mask=local.get("attention_mask"),
            max_selected_values=max_selected_values,
        ) as session:
            output = model(**local, use_cache=True, return_dict=True)
        trace = session.receipt()
    finally:
        model.train(was_training)
    if weight_fingerprint(model) != weights_before or weight_free_hook_receipt(model) != hooks_before:
        raise RuntimeError("Capture-only execution mutated weights or hooks.")
    for capture in trace["captures"]:
        if capture["nonzero_edit"] or capture["coefficient"] != 0.0 or capture["pre_sha256"] != capture["post_sha256"]:
            raise RuntimeError("Capture-only execution was not an exact no-op.")
    cache = getattr(output, "past_key_values", None)
    position_state = {name: local[name] for name in ("position_ids", "cache_position") if name in local}
    receipt = _clean_execution_receipt({
        "receipt_kind": "NATIVE_CAPTURE_ONLY_EXECUTION",
        "trial_id": trial_id,
        "generation_call_count": 0,
        "generated_answer": False,
        "operation": "capture_only",
        "trace": trace,
        "weights_before": weights_before,
        "weights_unchanged": True,
        "hook_registry_restored": True,
        "cache_state": summarize_cache(cache, model=model, position_state=position_state or None),
    })
    return ExecutionResult(receipt, cache=cache)


def weight_free_hook_receipt(model: Any) -> dict[str, Any]:
    """Serializable forward-hook registry without callable memory addresses."""
    paths = sorted(name for name, module in model.named_modules() if module._forward_hooks)
    return {"active_hook_paths": paths, "active_hook_count": sum(len(module._forward_hooks) for _, module in model.named_modules())}


def assert_exact_generation_parity(reference: ExecutionResult, candidate: ExecutionResult) -> dict[str, Any]:
    """Zero-tolerance comparison of tokens and native processed-logit bytes."""
    left, right = reference.receipt, candidate.receipt
    token_match = left["generated_token_ids"] == right["generated_token_ids"]
    logit_match = left["processed_logit_steps"] == right["processed_logit_steps"]
    if not token_match or not logit_match:
        raise AssertionError("Generation parity failed: token IDs and every native processed-logit hash must match exactly.")
    return {
        "token_ids_exact": True,
        "processed_logit_hashes_exact": True,
        "step_count": len(left["processed_logit_steps"]),
        "absolute_tolerance": 0.0,
        "relative_tolerance": 0.0,
    }
