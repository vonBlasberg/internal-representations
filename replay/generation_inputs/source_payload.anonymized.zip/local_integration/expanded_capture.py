"""Capture-only preparation for a separately admitted expanded contrast.

No provider, launch or calibration entry point. The unchanged Steerability
construction helper owns the estimator. A passive forward wrapper counts the
48 calls and retains the exact selected BF16 states used by that helper.
"""
from contextlib import contextmanager
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

import torch

from .direction_construction import construct_directions, validate_inputs
from .preparatory_phases import identity, save_new
from .preparatory_worker import generate_control_files
from .expanded_references import FORWARD_COUNT


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@contextmanager
def retained_forward_states(model, pairs, spec, destination, *, deadline, clock=time.monotonic, execution_counts=None):
    """Return model outputs untouched, retaining only selected response states.

    The middle-layer mapping was independently qualified in A06. It must not be
    applied to the final normalized hidden-state entry or to a new architecture.
    No callbacks, global patches, extra forwards or state edits are performed.
    """
    validate_inputs(spec, pairs)
    if spec.pooling != 'response_mean' or spec.accumulation_dtype != 'float32' or spec.insertion_dtype != 'bfloat16':
        raise ValueError('Only the unchanged response-mean FP32/BF16 estimator is supported.')
    schedule = [(pair.pair_id, label, getattr(pair, label)) for pair in pairs for label in ('positive', 'negative')]
    if len(schedule) != FORWARD_COUNT:
        raise ValueError('Exactly 24 paired inputs and 48 forwards are required.')
    if any(layer not in (14, 15) for layer, _ in spec.sites) or len(spec.sites) != 2:
        raise ValueError('Only the two independently qualified middle-layer sites are supported.')
    destination.mkdir(parents=True, exist_ok=False)
    receipt = execution_counts if execution_counts is not None else {}
    receipt.update({'status': 'STARTED', 'attempted_forwards': 0, 'completed_forwards': 0, 'retained_captures': 0,
               'generation_calls': 0, 'additional_forwards': 0, 'rows': [],
               'outputs_modified': False, 'automatic_retry': False, 'forward_restored': False})
    sentinel = object()
    previous_attribute = model.__dict__.get('forward', sentinel)
    original = model.forward

    def recorded(*args, **kwargs):
        number = receipt['attempted_forwards']
        if number >= len(schedule) or clock() >= deadline:
            raise RuntimeError('Capture allowance exhausted; no additional forward is permitted.')
        pair_id, label, response = schedule[number]
        ids, mask = kwargs.get('input_ids'), kwargs.get('attention_mask')
        if (args or ids is None or ids.tolist() != [list(response.input_ids)]
                or mask is None or mask.shape != ids.shape or not torch.all(mask == 1)
                or kwargs.get('use_cache') is not False or kwargs.get('past_key_values') is not None
                or kwargs.get('output_hidden_states') is not True or kwargs.get('return_dict') is not True
                or kwargs.get('cache_position') is None
                or kwargs['cache_position'].tolist() != list(range(len(response.input_ids)))):
            raise ValueError('Capture input, position, mask or no-cache contract differs.')
        receipt['attempted_forwards'] += 1
        output = original(**kwargs)
        receipt['completed_forwards'] += 1
        hidden = output.hidden_states
        positions = [len(response.prefix_ids) + index for index in response.selected_response_positions]
        states = {}
        for layer, _ in spec.sites:
            if layer + 1 >= len(hidden) - 1:
                raise ValueError('Final normalized states are not admitted by this capture.')
            value = hidden[layer + 1]
            if (tuple(value.shape) != (1, len(response.input_ids), spec.hidden_width)
                    or value.dtype != torch.bfloat16 or not torch.isfinite(value).all()):
                raise ValueError('Raw captured state shape, precision or finiteness differs.')
            states[str(layer)] = value[:, positions, :].detach().cpu().clone()
        name = f'{number:02d}-{label}.pt'
        with (destination / name).open('xb') as stream:
            torch.save(states, stream)
        receipt['rows'].append({'pair_id': pair_id, 'label': label, 'path': name,
            'sha256': sha(destination / name), 'input_sha256': identity(list(response.input_ids)),
            'sequence_length': len(response.input_ids), 'absolute_positions': positions,
            'shape': [1, len(positions), spec.hidden_width], 'dtype': 'bfloat16'})
        receipt['retained_captures'] += 1
        return output

    model.forward = recorded
    try:
        yield receipt
        if any(receipt[key] != FORWARD_COUNT for key in ('attempted_forwards', 'completed_forwards', 'retained_captures')):
            raise RuntimeError('The capture did not complete all 48 declared forwards.')
        receipt['status'] = 'COMPLETE'
    except BaseException as error:
        receipt.update(status='FAILED_NO_RETRY', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        if previous_attribute is sentinel:
            del model.forward
        else:
            model.forward = previous_attribute
        receipt['forward_restored'] = model.forward == original
        save_new(destination / 'receipt.json', receipt)


def capture(model, pairs, spec, program, destination, *, maximum_seconds=1200, execution_counts=None):
    """Capture all new pairs once and regenerate the fixed controls; never select."""
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    save_new(destination / 'construction_spec.json', asdict(spec))
    with retained_forward_states(model, pairs, spec, destination / 'selected_states',
                                 deadline=started + maximum_seconds, execution_counts=execution_counts) as forwards:
        fitted = construct_directions(model, pairs, spec)
    fitted.save(destination / 'constructed')
    directions = generate_control_files(program, fitted, destination / 'directions')
    result = {'status': 'EXPANDED_CAPTURE_COMPLETE', 'generation_calls': 0,
        'capture_forwards': forwards['completed_forwards'], 'attempted_forwards': forwards['attempted_forwards'],
        'retained_captures': forwards['retained_captures'],
        'selected_token_states_retained': True, 'forward_restored': forwards['forward_restored'],
        'directions': directions, 'calibration_started': False, 'candidate_selected': False,
        'behavioral_result': False, 'automatic_retry': False,
        'elapsed_seconds': time.monotonic() - started}
    save_new(destination / 'capture_result.json', result)
    return result


def audit_selected_states(evidence, pairs, spec):
    """Reconstruct masked FP32 pooling from retained BF16 token-state tensors."""
    evidence = Path(evidence)
    validate_inputs(spec, pairs)
    receipt = json.loads((evidence / 'selected_states/receipt.json').read_text())
    expected = {'status': 'COMPLETE', 'attempted_forwards': FORWARD_COUNT, 'completed_forwards': FORWARD_COUNT, 'retained_captures': FORWARD_COUNT,
                'generation_calls': 0, 'additional_forwards': 0, 'outputs_modified': False,
                'automatic_retry': False, 'forward_restored': True}
    if any(receipt.get(key) != value for key, value in expected.items()) or len(receipt['rows']) != FORWARD_COUNT:
        raise ValueError('Capture completion/count/restoration receipt differs.')
    header = json.loads((evidence / 'constructed/construction.json').read_text())
    if identity(header['construction_spec']) != identity(asdict(spec)) or len(header['pairs']) != len(pairs):
        raise ValueError('Construction specification or pair count differs.')
    schedule = [(pair, label) for pair in pairs for label in ('positive', 'negative')]
    for number, ((pair, label), row) in enumerate(zip(schedule, receipt['rows'], strict=True)):
        response = getattr(pair, label)
        positions = [len(response.prefix_ids) + index for index in response.selected_response_positions]
        expected_row = {'pair_id': pair.pair_id, 'label': label, 'path': f'{number:02d}-{label}.pt',
            'input_sha256': identity(list(response.input_ids)), 'sequence_length': len(response.input_ids),
            'absolute_positions': positions, 'shape': [1, len(positions), spec.hidden_width], 'dtype': 'bfloat16'}
        if any(row.get(key) != value for key, value in expected_row.items()):
            raise ValueError('Retained state input/position provenance differs.')
        path = evidence / 'selected_states' / expected_row['path']
        if sha(path) != row['sha256']:
            raise ValueError('Retained state bytes changed.')
        states = torch.load(path, map_location='cpu', weights_only=True)
        if set(states) != {str(layer) for layer, _ in spec.sites}:
            raise ValueError('Retained state layer inventory differs.')
        saved = header['pairs'][number // 2]
        if saved['pair_id'] != pair.pair_id or saved['family_id'] != pair.family_id:
            raise ValueError('Retained state pair identity differs.')
        saved_response = saved['responses'][label]
        expected_response = {'prefix_ids': list(response.prefix_ids), 'response_ids': list(response.response_ids),
            'selected_response_positions': list(response.selected_response_positions), 'absolute_positions': positions}
        if any(saved_response.get(key) != value for key, value in expected_response.items()):
            raise ValueError('Construction header response token or position provenance differs.')
        for layer, _ in spec.sites:
            raw = states[str(layer)]
            if tuple(raw.shape) != tuple(row['shape']) or raw.dtype != torch.bfloat16 or not torch.isfinite(raw).all():
                raise ValueError('Retained state dimensions, precision or values differ.')
            # Keep the original sequence positions in the sum, including zeros
            # outside selection, so FP32 reduction order matches masked pooling.
            full = torch.zeros((1, len(response.input_ids), spec.hidden_width), dtype=torch.float32)
            full[:, positions, :] = raw.float()
            pooled = full.sum(dim=1) / len(positions)
            recorded = torch.tensor(saved['responses'][label]['pooled_states'][str(layer)], dtype=torch.float32).reshape(1, -1)
            if not torch.equal(pooled, recorded):
                raise ValueError('Pooled states do not reproduce from retained BF16 token states.')
    files = {path.name for path in (evidence / 'selected_states').iterdir() if path.is_file()}
    if files != {'receipt.json', *(row['path'] for row in receipt['rows'])}:
        raise ValueError('Unexpected or missing retained state file.')
    return {'selected_state_files': FORWARD_COUNT, 'response_layer_means_reproduced': FORWARD_COUNT * 2,
            'capture_forwards': FORWARD_COUNT, 'generation_calls': 0,
            'research_model_loaded': False, 'behavioral_result': False}
