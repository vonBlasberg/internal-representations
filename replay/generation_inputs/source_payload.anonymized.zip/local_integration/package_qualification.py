"""One-use package-route qualification, with loading supplied by the admitted worker.

No provider is imported here. The caller supplies a snapshot-verified model
factory and a fresh-process restoration function. Both run only after a separate
approval has bound the plan. This module cannot authorize its own execution.
"""
from __future__ import annotations

from dataclasses import asdict
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import time

import torch
from inspect_ai import Task, eval as evaluate
from inspect_ai.dataset import Sample
from inspect_ai.log import read_eval_log
from inspect_ai.model import ChatMessageSystem, ChatMessageUser
from inspect_ai.solver import generate

from .direction_construction import canonical_hash
from .research_pipeline import GenerationContract, EditSpec, RecordedSteeringPipeline
from worker.adapter_base import Site
from worker.generation import generate_with_receipts
from worker.receipts import tensor_sha256, weight_fingerprint
from worker.wp3_runner import write_immutable_json

PARITY_KEYS = ("input_token_ids", "generated_token_ids", "processed_logit_steps")
OPERATIONS = (
    ("native-baseline-1", "native", 0, None, None),
    ("native-baseline-2", "native", 1, None, None),
    ("package-baseline-1", "package", 0, None, None),
    ("package-baseline-2", "package", 1, None, None),
    ("package-zero", "package", 1, 2, 0.0),
    ("native-linear-edit", "native", 1, 2, 1.0),
    ("package-linear-edit", "package", 1, 2, 1.0),
    ("native-full-edit", "native", 1, 3, 1.0),
    ("package-full-edit", "package", 1, 3, 1.0),
)
REFERENCES = {"package-baseline-1": "native-baseline-1", "package-baseline-2": "native-baseline-2",
    "package-zero": "native-baseline-2", "package-linear-edit": "native-linear-edit",
    "package-full-edit": "native-full-edit", "fresh-restoration": "native-baseline-2"}
SITES = ((2, "model.language_model.layers.2"), (3, "model.language_model.layers.3"))
ROOT = Path(__file__).resolve().parents[1]
SOURCE_FILES = ("local_integration/package_qualification.py", "local_integration/research_pipeline.py",
    "local_integration/qualification_worker.py",
    "local_integration/direction_construction.py", "negotiation-steering/worker/generation.py",
    "negotiation-steering/worker/transformers_native.py", "negotiation-steering/worker/adapter_base.py",
    "negotiation-steering/worker/receipts.py", "negotiation-steering/worker/wp3_runner.py")


def source_inventory():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCE_FILES}


def validate_plan(plan):
    if plan.get("phase") != "package_route_qualification" or plan.get("automatic_retry") is not False:
        raise ValueError("Only one no-retry package qualification is supported.")
    run_id = plan.get("run_id")
    if not isinstance(run_id, str) or not run_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in run_id):
        raise ValueError("The run ID must be a safe, explicit directory name.")
    if type(plan.get("synthetic_test")) is not bool:
        raise ValueError("Declare whether this is an invented local test.")
    wall = plan.get("maximum_wall_seconds")
    if plan.get("maximum_generation_calls") != 10 or type(wall) not in (int, float) or not math.isfinite(wall) or wall <= 0:
        raise ValueError("Declare ten calls and a positive wall-clock bound.")
    contract_data = dict(plan["generation_contract"])
    if contract_data.get("eos_token_ids") is not None:
        contract_data["eos_token_ids"] = tuple(contract_data["eos_token_ids"])
    contract = GenerationContract(**contract_data)
    if contract.synthetic_test != plan["synthetic_test"] or contract.max_generation_calls != 1:
        raise ValueError("Every package operation must admit one call with consistent test status.")
    inputs = plan["inputs"]
    if not isinstance(inputs, list) or len(inputs) != 2 or len({item["case_id"] for item in inputs}) != 2:
        raise ValueError("Exactly two distinct declared competence inputs are required.")
    for item in inputs:
        if item.get("partition") != "quality" or canonical_hash(item["input_token_ids"]) != item["input_token_ids_sha256"]:
            raise ValueError("Qualification input partition or token hash differs.")
        messages = item["messages"]
        if len(messages) != 2 or [m["role"] for m in messages] != ["system", "user"] or any(not isinstance(m["content"], str) for m in messages):
            raise ValueError("Only the declared system/user text messages are supported.")
        reference = item["native_reference"]
        if reference["input_token_ids"] != item["input_token_ids"] or not reference["generated_token_ids"]:
            raise ValueError("Reference output is not bound to its input.")
        if len(reference["processed_logit_steps"]) != len(reference["generated_token_ids"]):
            raise ValueError("Reference token and logit counts disagree.")
        if item.get("reference_competence_passed") is not True:
            raise ValueError("Both reference competence records must have passed.")
    return contract


def validate_approval(plan, approval):
    validate_plan(plan)
    if not isinstance(approval, dict) or approval.get("owner_authorized") is not True:
        raise PermissionError("A new, separate owner approval is required.")
    required = {"plan_sha256": canonical_hash(plan), "run_id": plan["run_id"],
        "maximum_generation_calls": 10, "automatic_retry": False,
        "deployment_authorized": False, "behavioral_study_authorized": False}
    if any(approval.get(k) != v for k, v in required.items()):
        raise PermissionError("Approval does not bind this exact qualification and its limits.")
    if approval.get("local_synthetic_only") is not plan["synthetic_test"]:
        raise PermissionError("A local test approval cannot authorize a research-model run.")
    if not plan["synthetic_test"] and (approval.get("paid_qualification_authorized") is not True or not approval.get("owner_authorization_reference")):
        raise PermissionError("The research-model run needs explicit paid qualification authority.")
    if plan.get("source_sha256") != source_inventory():
        raise PermissionError("Qualification sources changed after plan preparation.")


def compare(reference, candidate):
    differences = [key for key in PARITY_KEYS if reference.get(key) != candidate.get(key)]
    if differences:
        raise RuntimeError("Exact native/package parity failed: " + ", ".join(differences))
    return {key: True for key in PARITY_KEYS}


def _inspect_operation(model, tokenizer, contract, item, operation, direction, directory, plan_hash):
    trial_id, _, _, layer, coefficient = operation
    edit = None if layer is None else EditSpec(layer, SITES[layer - 2][1], coefficient, tensor_sha256(direction))
    pipeline = RecordedSteeringPipeline(model, tokenizer, contract, edit=edit,
        direction=direction if edit else None, observe_sites=SITES)
    messages = [ChatMessageSystem(content=item["messages"][0]["content"]),
                ChatMessageUser(content=item["messages"][1]["content"])]
    task = Task(name="package-route-qualification", dataset=[Sample(id=trial_id, input=messages,
        metadata={"case_id": item["case_id"], "plan_sha256": plan_hash,
                  "input_token_ids_sha256": item["input_token_ids_sha256"]})], solver=generate())
    try:
        with pipeline.trial(trial_id, tuple(item["input_token_ids"])):
            logs = evaluate(task, model=pipeline.inspect_model(), log_dir=str(directory / "inspect"),
                log_format="json", display="none", notification=False, ctl_server=False, acp_server=False,
                checkpoint=False, epochs=1, retry_on_error=0, max_retries=0, max_samples=1,
                max_tasks=1, max_connections=1, cache=False, fail_on_error=False, score_on_error=False,
                sample_shuffle=False, max_tokens=contract.max_new_tokens, temperature=0)
            if len(logs) != 1:
                raise RuntimeError("Inspect must return one evaluation log.")
            saved = read_eval_log(logs[0].location)
            if saved.status != "success" or len(saved.samples or []) != 1 or saved.samples[0].error:
                raise RuntimeError("Inspect reported a failed or incomplete qualification sample.")
            sample = saved.samples[0]
            if sample.id != trial_id or sample.metadata["plan_sha256"] != plan_hash:
                raise RuntimeError("Inspect sample identity changed.")
            receipt = pipeline.records[-1]
            if sample.output.completion != tokenizer.decode(receipt["generated_token_ids"], skip_special_tokens=True):
                raise RuntimeError("Inspect completion differs from recorded generated tokens.")
            receipt["inspect_log"] = {"path": str(Path(logs[0].location).relative_to(directory)),
                "sha256": hashlib.sha256(Path(logs[0].location).read_bytes()).hexdigest(),
                "sample_id": sample.id, "completion": sample.output.completion}
            return receipt
    finally:
        # Commit even a failed generation before comparison or dependent work.
        write_immutable_json(directory / "package_execution.json", {"records": pipeline.records})


def execute(plan, approval, runs_root, *, model_factory, fresh_process_restore):
    """Execute the fixed ten-call schedule. Callbacks must be admitted worker code.

    model_factory returns a snapshot-verified model, tokenizer and the declared
    float32 instrumentation direction. fresh_process_restore returns one native
    generation receipt from a different process after the parent releases its
    model. No fallback or automatic retry is performed here.
    """
    validate_approval(plan, approval)  # Before creating a run or loading a model.
    contract = validate_plan(plan)
    directory = Path(runs_root) / plan["run_id"]
    directory.mkdir(parents=True, exist_ok=False)
    started, results = time.monotonic(), {}
    model = tokenizer = direction = None
    write_immutable_json(directory / "started.json", {"plan_sha256": canonical_hash(plan),
        "plan": plan, "approval": approval, "process_id": os.getpid(), "status": "STARTED_NO_RETRY"})
    current = "load"
    try:
        model, tokenizer, direction = model_factory(plan)
        if tensor_sha256(direction) != plan["direction_sha256"]:
            raise RuntimeError("Loaded instrumentation direction differs from the plan.")
        initial_weights = weight_fingerprint(model)
        if initial_weights["entries_sha256"] != plan["model_weight_entries_sha256"]:
            raise RuntimeError("Loaded weights differ from the admitted reference.")
        admission = RecordedSteeringPipeline(model, tokenizer, contract, observe_sites=SITES)
        del admission
        for item in plan["inputs"]:
            rendered_ids = tokenizer.apply_chat_template(item["messages"], tokenize=True,
                return_dict=False, add_generation_prompt=True, enable_thinking=False)
            if rendered_ids != item["input_token_ids"] or len(rendered_ids) > contract.max_input_tokens:
                raise RuntimeError("Qualification chat rendering differs from its exact input record.")
        for operation in OPERATIONS:
            current, route, case_index, layer, coefficient = operation
            if time.monotonic() - started > plan["maximum_wall_seconds"]:
                raise TimeoutError("Qualification wall-clock limit reached; no retry.")
            item = plan["inputs"][case_index]
            operation_dir = directory / current
            operation_dir.mkdir(exist_ok=False)
            write_immutable_json(operation_dir / "started.json", {"operation": list(operation),
                "case_id": item["case_id"], "input_token_ids_sha256": item["input_token_ids_sha256"]})
            if route == "native":
                ids = torch.tensor([item["input_token_ids"]], dtype=torch.long, device=model.get_input_embeddings().weight.device)
                sites = None if layer is None else [Site(current, SITES[layer - 2][1],
                    "linear_attention" if layer == 2 else "full_attention", direction=direction.flatten(), coefficient=coefficient)]
                output = generate_with_receipts(model, {"input_ids": ids, "attention_mask": torch.ones_like(ids)},
                    trial_id=current, sites=sites, max_new_tokens=contract.max_new_tokens,
                    min_new_tokens=contract.min_new_tokens,
                    eos_token_id=None if contract.eos_token_ids is None else list(contract.eos_token_ids))
                receipt = output.receipt
                del output
            else:
                receipt = _inspect_operation(model, tokenizer, contract, item, operation, direction, operation_dir, canonical_hash(plan))
            write_immutable_json(operation_dir / "execution.json", receipt)
            if receipt["generation_call_count"] != 1 or receipt["weights_after"] != initial_weights:
                raise RuntimeError("Generation count or weight preservation failed.")
            if current.startswith("native-baseline"):
                parity = compare(item["native_reference"], receipt)
            elif current in REFERENCES:
                parity = compare(results[REFERENCES[current]], receipt)
            else:
                parity = None
            write_immutable_json(operation_dir / "check.json", {"status": "PASS", "parity": parity,
                "behavioral_interpretation_allowed": False})
            results[current] = receipt
        # A new process, original input and fresh model must supply restoration.
        model = tokenizer = direction = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        current = "fresh-restoration"
        if time.monotonic() - started > plan["maximum_wall_seconds"]:
            raise TimeoutError("No allowance remains for fresh-process restoration.")
        fresh = fresh_process_restore(plan, directory)
        write_immutable_json(directory / "fresh-restoration.json", fresh)
        if fresh.get("process_id") in (None, os.getpid()) or fresh.get("fresh_process") is not True or fresh.get("generation_call_count") != 1:
            raise RuntimeError("Restoration did not establish one new-process generation.")
        if fresh["weights_after"] != initial_weights:
            raise RuntimeError("Fresh-process restoration changed the weights.")
        compare(results["native-baseline-2"], fresh)
        if time.monotonic() - started > plan["maximum_wall_seconds"]:
            raise TimeoutError("Qualification exceeded the declared wall-clock limit.")
        summary = {"status": "PASS", "run_id": plan["run_id"], "generation_calls": 10,
            "synthetic_test": plan["synthetic_test"], "elapsed_seconds": time.monotonic() - started,
            "package_route_mechanics_passed": True, "scientific_evidence": False,
            "behavioral_result": False, "deployment_authorized": False,
            "plan_sha256": canonical_hash(plan), "fresh_process_id": fresh["process_id"]}
        write_immutable_json(directory / "result.json", summary)
        return summary
    except BaseException as error:
        write_immutable_json(directory / "failure.json", {"status": "FAILED_NO_RETRY", "operation": current,
            "completed_operations": list(results), "error_type": type(error).__name__, "error": str(error),
            "scientific_evidence": False, "behavioral_result": False, "elapsed_seconds": time.monotonic() - started})
        raise
