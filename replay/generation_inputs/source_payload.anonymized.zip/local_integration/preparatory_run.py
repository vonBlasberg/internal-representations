"""Prepare, check, launch once, retrieve, or independently audit one phase."""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import zipfile

from .construction_program import ROOT, A03, specification, phase_plan, calibration_arms
from .preparatory_phases import identity, save_new, checked_scores, check_construction_labels
from . import qualification_transport as delivery
from . import preparatory_transport as transport

OWNER_REFERENCE = (
    "Owner: Go ahead with direction construction and calibration so we get real behavioral results. "
    "Fix result delivery first, preserve all records, keep F4 paused and the design unchanged, and stop on failure without retrying. "
    "Owner's subsequent case decision: Prepare the additional construction cases; preserve existing records."
)

def read(path):
    return json.loads(Path(path).read_text())

def approval_for(request, package):
    return {"owner_authorized": True, "paid_phase_authorized": True, "request_sha256": identity(request),
        "transport_sha256": delivery.canonical_hash(package), "stage": request["stage"],
        "maximum_generation_calls": request["maximum_generation_calls"], "maximum_wall_seconds": request["maximum_wall_seconds"],
        "automatic_retry": False, "deployment_authorized": False, "f4_authorized": False,
        "owner_authorization_reference": OWNER_REFERENCE,
        "recorded_at_utc": datetime.now(timezone.utc).isoformat()}

def write_request(directory, request, direction_files=None):
    directory.mkdir(parents=True, exist_ok=False)
    package, payloads = transport.build_package(request, direction_files)
    approval = approval_for(request, package)
    transport.verify(package, payloads, approval)
    save_new(directory / "request.json", request)
    save_new(directory / "transport.json", package)
    save_new(directory / "approval.json", approval)
    with zipfile.ZipFile(directory / "source_payload.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in payloads.items():
            archive.writestr(name, data)
    save_new(directory / "source_archive.json", {"sha256": delivery.file_digest(directory / "source_payload.zip"),
        "files": len(payloads), "provider_contacted": False, "f4_accessed": False})
    return package

def prepare(directory):
    directory.mkdir(parents=True, exist_ok=False)
    program = specification()
    save_new(directory / "program.json", program)
    # A new standalone bank contains the original unchanged case plus additions.
    with (directory / "construction_fit_v2.jsonl").open("x") as stream:
        for case in program["cases"]["construction_fit"]:
            stream.write(json.dumps(case,sort_keys=True)+"\n")
    save_new(directory / "case_expansion.json", {"owner_authorization_reference": OWNER_REFERENCE,
        "original_file_hashes": program["original_case_files"], "retained_original_fit_cases": 1,
        "additional_fit_cases": 3, "check_cases_unchanged": True, "calibration_cases_unchanged": True,
        "old_case_files_written": False, "development_or_untouched_read": False})
    request = {"run_id": program["program_id"] + "-construction", "stage": "construction",
        "program": program, "program_sha256": identity(program), "qualification_audit": read(A03 / "terminal_audit.json"),
        "maximum_generation_calls": 10, "maximum_wall_seconds": 1800}
    write_request(directory / "construction", request)
    return {"status": "PREPARED_NOT_LAUNCHED", "directory": str(directory), "program_sha256": identity(program)}

def load_request(directory):
    request, package, approval = (read(directory / name) for name in ("request.json", "transport.json", "approval.json"))
    if delivery.file_digest(directory / "source_payload.zip") != read(directory / "source_archive.json")["sha256"]:
        raise ValueError("Preserved source archive changed.")
    with zipfile.ZipFile(directory / "source_payload.zip") as archive:
        payloads = {name: archive.read(name) for name in archive.namelist()}
    transport.verify(package,payloads,approval)
    # Check local source and artifact identities immediately before submission.
    for name, data in payloads.items():
        if not name.startswith("request/") and (ROOT / name).read_bytes() != data:
            raise ValueError("A frozen source or artifact changed: " + name)
    from .preparatory_worker import check_request
    check_request(request,approval)
    return request,approval,package,payloads

def audit(directory):
    request, approval, package, payloads = load_request(directory)
    returned = directory / "launch/returned"
    retrieval = read(returned / "retrieval.json")
    if retrieval["status"] != "ALL_COMMITTED_FILES_VERIFIED":
        raise ValueError("Delivery has not been verified.")
    manifest = read(returned / "manifest.json")
    for row in manifest["files"]:
        path = returned / "evidence" / row["path"]
        if path.stat().st_size != row["size_bytes"] or delivery.file_digest(path) != row["sha256"]:
            raise ValueError("A retrieved file changed.")
    evidence = returned / "evidence/attempt"
    result = read(evidence / "result.json") if (evidence / "result.json").is_file() else None
    program = request["program"]
    phases = ("construction_check", "construction_fit") if request["stage"] == "construction" else ("calibration",)
    rows, phase_results, checks = [], {}, {}
    for phase in phases:
        arms = calibration_arms(program,request["directions"]) if phase == "calibration" else None
        plan = phase_plan(program,phase,arms)
        path = evidence / "phases" / plan["run_id"] / "result.json"
        if not path.is_file():
            continue
        saved = read(path)
        scores = checked_scores(plan,program["cases"][phase],saved)
        for trial, row in zip(plan["trials"],saved["records"]):
            score = scores[row["trial_id"]]
            rows.append({"phase":phase,"case_id":row["case_id"],"arm_id":row["arm_id"],"kind":row["kind"],
                "execution_status":row["execution_status"],"raw_response":row["raw_response"],"score":score})
            if row["execution_status"] != "COMPLETED":
                continue
            if score != row["score"]:
                raise ValueError("Independent rescoring differs.")
            location=path.parent / trial["trial_id"]
            source=row["source"]
            log_path=location / source["source_log_path"]
            if delivery.file_digest(log_path) != source["source_log_sha256"]:
                raise ValueError("Inspect source log hash differs.")
            from inspect_ai.log import read_eval_log
            log=read_eval_log(str(log_path))
            if log.status != "success" or len(log.samples or []) != 1 or log.samples[0].output.completion != row["raw_response"]:
                raise ValueError("Inspect log and recorded response differ.")
            execution=read(location / "state_execution.json")["records"]
            if len(execution)!=1 or execution[0]["generated_token_ids"] != source["generated_token_ids"]:
                raise ValueError("Generation receipt differs.")
            input_record=read(location / "input.json")
            if execution[0]["input_token_ids"] != input_record["input_token_ids"] or input_record["messages_sha256"] != trial["messages_sha256"]:
                raise ValueError("Input receipt differs.")
            loaded=read(location / "loaded_model.json")
            if loaded["weights"]["entries_sha256"]!=program["qualification_plan"]["model_weight_entries_sha256"]:
                raise ValueError("Loaded weights differ from qualification.")
        phase_results[phase]=saved
        if phase=="construction_check":
            checks[phase]=check_construction_labels(plan,program["cases"][phase],saved)
            stored=evidence / "construction_check.json"
            if stored.is_file() and read(stored)!=checks[phase]:
                raise ValueError("Construction check differs on replay.")
    complete = result is not None and result.get("status") == request["stage"].upper()+"_COMPLETE"
    if complete and len(phase_results)!=len(phases):
        raise ValueError("Successful worker omitted a phase.")
    if complete and request["stage"]=="construction":
        import torch
        from steerability.algorithms.state_control.common.steering_vector import SteeringVector
        from .direction_construction import ConstructedDirections
        from .preparatory_worker import generate_control_files
        header=read(evidence / "constructed/construction.json")
        if header["capture_forward_count"]!=8 or header["pair_count"]!=4 or checks["construction_check"]["status"]!="PASS":
            raise ValueError("Construction gate/count differs.")
        raw={}
        for layer,_ in program["sites"]:
            values=[torch.tensor(p["responses"]["positive"]["pooled_states"][str(layer)],dtype=torch.float32)-torch.tensor(p["responses"]["negative"]["pooled_states"][str(layer)],dtype=torch.float32) for p in header["pairs"]]
            raw[layer]=(sum(values,torch.zeros_like(values[0]))/len(values)).reshape(1,-1)
            data=raw[layer].numpy().astype("<f4").tobytes()
            if data!=(evidence / "constructed" / f"layer-{layer}-raw.f32le").read_bytes():
                raise ValueError("Raw direction does not equal the paired-state estimator.")
        vector=SteeringVector(model_type="qwen3_5",directions=raw)
        with tempfile.TemporaryDirectory() as location:
            replay=generate_control_files(program,ConstructedDirections(vector,vector.normalized(),header),Path(location)/"controls")
            if replay!=read(evidence / "directions/directions.json")["directions"]:
                raise ValueError("Controls differ on independent deterministic replay.")
        status="CONSTRUCTION_AND_CONTROLS_VERIFIED"
    elif complete:
        from .calibration_selection import select
        plan=phase_plan(program,"calibration",calibration_arms(program,request["directions"]))
        selection=select(plan,program["cases"]["calibration"],phase_results["calibration"])
        if selection!=read(evidence / "selection.json"):
            raise ValueError("Selection differs on independent replay.")
        checks["selection"]=selection
        status="CALIBRATION_VERIFIED"
    else:
        status="STOPPED_NO_RETRY_RECORDS_VERIFIED"
    report={"status":status,"run_id":request["run_id"],"request_sha256":identity(request),"worker_result":result,
        "checked_at_utc":datetime.now(timezone.utc).isoformat(),"checks":checks,"rows":rows,
        "returned_files_verified":len(manifest["files"]),"research_model_loaded":False,"f4_accessed":False,"retry_performed":False,
        "further_execution_authorized":False,"held_out_result":False}
    save_new(directory / "terminal_audit.json",report)
    return report

def prepare_calibration(directory):
    construction = directory / "construction"
    audit_record=read(construction / "terminal_audit.json")
    if audit_record["status"]!="CONSTRUCTION_AND_CONTROLS_VERIFIED":
        raise PermissionError("Construction did not pass; no calibration.")
    program=read(directory / "program.json")
    evidence=construction / "launch/returned/evidence/attempt"
    directions=read(evidence / "directions/directions.json")["directions"]
    files={entry["path"]:(evidence/"directions"/entry["path"]).read_bytes() for by_layer in directions.values() for entry in by_layer.values()}
    for by_layer in directions.values():
        for entry in by_layer.values():
            if delivery.digest(files[entry["path"]])!=entry["sha256"]:
                raise ValueError("A constructed direction changed.")
    plan=phase_plan(program,"calibration",calibration_arms(program,directions))
    request={"run_id":program["program_id"]+"-calibration","stage":"calibration","program":program,
        "program_sha256":identity(program),"qualification_audit":read(A03/"terminal_audit.json"),
        "construction_audit":audit_record,"directions":directions,"phase_plan_sha256":identity(plan),
        "maximum_generation_calls":41,"maximum_wall_seconds":7200}
    write_request(directory/"calibration",request,files)
    return {"status":"CALIBRATION_PREPARED_NOT_LAUNCHED","phase_plan_sha256":identity(plan)}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("prepare","prepare-calibration","check","launch","retrieve","audit"))
    parser.add_argument("directory",type=Path)
    args=parser.parse_args()
    if args.action=="prepare": result=prepare(args.directory)
    elif args.action=="prepare-calibration": result=prepare_calibration(args.directory)
    elif args.action=="audit":
        report=audit(args.directory)
        result={"status":report["status"],"checks":report["checks"],"completed_rows":len(report["rows"])}
    elif args.action=="check":
        request,approval,package,payloads=load_request(args.directory)
        result={"status":"LOCAL_PHASE_CHECK_PASS","files":len(payloads),"stage":request["stage"],"provider_contacted":False}
    else:
        sys.path.append(str(ROOT.parent/"model-trace-observatory/.venv/lib/python3.12/site-packages"))
        if args.action=="retrieve": result=delivery.retrieve(args.directory/"launch")
        else:
            request,approval,package,payloads=load_request(args.directory)
            result=transport.launch(request,approval,package,payloads,args.directory/"launch")
    print(json.dumps(result,sort_keys=True))

if __name__=="__main__":
    main()
