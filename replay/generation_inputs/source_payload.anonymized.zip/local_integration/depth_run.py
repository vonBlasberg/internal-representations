"""Prepare, check, launch once and retrieve the explicit A06 diagnostic."""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import zipfile

from . import authored_transport, qualification_transport as delivery
from .preparatory_phases import identity, save_new
from .depth_worker import RUN_ID, SITES, check_request

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/"records/revised_intervention_2026-10-31_A06"
EXTRA=("local_integration/depth_worker.py","local_integration/depth_diagnostics.py","local_integration/depth_run.py")
WORKER="local_integration.depth_worker"


def build(request):
    package,payloads=authored_transport.build_package(request)
    for name in EXTRA:payloads[name]=(ROOT/name).read_bytes()
    inventory=[{"path":name,"sha256":delivery.digest(data),"size_bytes":len(data)} for name,data in sorted(payloads.items())]
    package.update(artifact_type="DEPTH_AUDIT_TRANSPORT",files=inventory,inventory_sha256=identity(inventory),
        worker_module=WORKER,maximum_generation_calls=8,process_tree_timeout_seconds=1800,
        maximum_reserved_usd=12.0,aggregate_limit_usd=100.0)
    return package,payloads


def verify(package,payloads,approval,*,local=False):
    expected={x["path"]:x for x in package["files"]}
    if len(expected)!=len(package["files"]) or set(expected)!=set(payloads) or identity(package["files"])!=package["inventory_sha256"]:
        raise ValueError("A06 source inventory differs.")
    for name,row in expected.items():
        delivery.safe_relative(name)
        if len(payloads[name])!=row["size_bytes"] or delivery.digest(payloads[name])!=row["sha256"]:
            raise ValueError("A06 payload changed: "+name)
    request=json.loads(payloads["request/research.json"])
    required={"artifact_type":"DEPTH_AUDIT_TRANSPORT","worker_module":WORKER,"run_id":RUN_ID,
        "maximum_generation_calls":8,"process_tree_timeout_seconds":1800,"maximum_containers":1,
        "gpu":"L40S","base_image_id":delivery.BASE_IMAGE,"application_retries":0,
        "maximum_reserved_usd":12.0,"aggregate_limit_usd":100.0,"deployment":False,"checkpoint_download":False}
    if any(package.get(k)!=v for k,v in required.items()) or package["request_sha256"]!=identity(request):
        raise ValueError("A06 settings or spending allowance changed.")
    if approval["transport_sha256"]!=delivery.canonical_hash(package) or approval["request_sha256"]!=identity(request):
        raise PermissionError("Exact one-use A06 approval is required.")
    if local:check_request(request,approval)
    return request


def protected_inventory():
    protected={}
    for folder in (ROOT/"records",ROOT/"local_integration",ROOT/"negotiation-steering/analysis",ROOT/"negotiation-steering/worker"):
        for path in sorted(folder.rglob("*")):
            if path.is_file() and not path.is_symlink() and BASE not in path.parents and "__pycache__" not in path.parts:
                protected[str(path.relative_to(ROOT))]=delivery.file_digest(path)
    return protected


def request_values():
    parent=json.loads((ROOT/"records/calibration_headroom_2026-10-30_A05/calibration/request.json").read_text())
    program=deepcopy(parent["program"]);program["program_id"]="negotiation-depth-audit-2026-10-31-A06"
    program["sites"]=[list(x) for x in SITES]
    request={"run_id":RUN_ID,"stage":"construction","program":program,"parent_request":parent,
        "construction_source":parent["construction_source"],"maximum_generation_calls":8,"maximum_wall_seconds":1800,
        "capture_checks":{"direct_capture_exact":True,"cache_relative_l2_max":.02,"cache_cosine_min":.999,"first_cached_response_tokens":7},
        "authorization_sha256":delivery.file_digest(BASE/"AUTHORIZATION.md"),
        "reservation_sha256":delivery.file_digest(BASE/"reservation.json"),
        "preserved_inventory_sha256":identity(protected_inventory())}
    return request


def approval_for(request,package):
    return {"owner_authorized":True,"request_sha256":identity(request),"transport_sha256":delivery.canonical_hash(package),
        "maximum_generation_calls":8,"maximum_wall_seconds":1800,"maximum_reserved_usd":12.0,"aggregate_limit_usd":100.0,
        "automatic_retry":False,"deployment_authorized":False,
        "owner_authorization_reference":"Active goal: deep audit, fresh revised run and prototype, further model/GPU runs approved up to US$100.",
        "authorization_sha256":request["authorization_sha256"],"reservation_sha256":request["reservation_sha256"]}


def prepare():
    request=request_values()
    package,payloads=build(request)
    approval=approval_for(request,package)
    verify(package,payloads,approval,local=True)
    preflight=json.loads((BASE/"preflight.json").read_text())
    report=json.loads((ROOT/preflight["report_path"]).read_text())
    if delivery.file_digest(ROOT/preflight["report_path"])!=preflight["report_sha256"] or report["status"]!="PASS" or report["tests_run"]<23 or report["request_sha256"]!=identity(request) or report["transport_sha256"]!=identity(package):
        raise PermissionError("Exact A06 preflight has not passed.")
    for name,expected in report["source_sha256"].items():
        if delivery.file_digest(ROOT/name)!=expected:raise ValueError("Preflight source changed: "+name)
    approval["preflight_sha256"]=delivery.file_digest(BASE/"preflight.json")
    directory=BASE/"construction";directory.mkdir(exist_ok=False)
    for name,value in (("request.json",request),("approval.json",approval),("transport.json",package)):
        save_new(directory/name,value)
    with zipfile.ZipFile(directory/"source_payload.zip","x",zipfile.ZIP_DEFLATED) as archive:
        for name,data in payloads.items():archive.writestr(name,data)
    save_new(directory/"source_archive.json",{"sha256":delivery.file_digest(directory/"source_payload.zip")})
    # Protect the original research and all retained attempts before new execution.
    protected=protected_inventory()
    if identity(protected)!=request["preserved_inventory_sha256"]:raise ValueError("Protected files changed during preparation.")
    save_new(directory/"preserved_before.json",protected)
    return {"status":"PREPARED_NOT_SUBMITTED","files":len(payloads),"protected_files":len(protected),"request_sha256":identity(request)}


def load():
    directory=BASE/"construction"
    request,approval,package=[json.loads((directory/name).read_text()) for name in ("request.json","approval.json","transport.json")]
    if identity(json.loads((directory/"preserved_before.json").read_text()))!=request["preserved_inventory_sha256"]:
        raise ValueError("Original preservation inventory changed.")
    if delivery.file_digest(directory/"source_payload.zip")!=json.loads((directory/"source_archive.json").read_text())["sha256"]:
        raise ValueError("A06 source archive changed.")
    with zipfile.ZipFile(directory/"source_payload.zip") as archive:
        if len(set(archive.namelist()))!=len(archive.namelist()):raise ValueError("Duplicate source path.")
        payloads={n:archive.read(n) for n in archive.namelist()}
    if verify(package,payloads,approval,local=True)!=request:raise ValueError("Saved request differs.")
    for name,data in payloads.items():
        if not name.startswith("request/") and (ROOT/name).read_bytes()!=data:raise ValueError("Frozen A06 source changed: "+name)
    if delivery.file_digest(BASE/"AUTHORIZATION.md")!=request["authorization_sha256"] or delivery.file_digest(BASE/"reservation.json")!=request["reservation_sha256"]:
        raise PermissionError("Authority or budget changed after preparation.")
    if delivery.file_digest(BASE/"preflight.json")!=approval["preflight_sha256"]:
        raise PermissionError("A06 preflight binding changed.")
    return request,approval,package,payloads


def remote(approval,package,payloads,claim,commit):
    request=verify(package,payloads,approval)
    if not claim(RUN_ID,{"request_sha256":identity(request),"time":time.time()}):
        return {"status":"ALREADY_CLAIMED_NO_EXECUTION","run_id":RUN_ID}
    outer=Path(delivery.MOUNT)/delivery.result_prefix(RUN_ID);outer.mkdir(parents=True,exist_ok=False)
    delivery.write_new(outer/"claimed.json",delivery.encoded({"run_id":RUN_ID,"request_sha256":identity(request)}));commit()
    try:
        root=Path(delivery.REMOTE)
        for name,data in payloads.items():delivery.write_new(root/delivery.safe_relative(name),data)
        delivery.write_new(root/"request/approval.json",delivery.encoded(approval))
        process=delivery.run_process([sys.executable,"-m",WORKER,str(root/"request/research.json"),str(root/"request/approval.json"),delivery.SNAPSHOT,str(outer/"attempt")],
            root,outer/"stdout.log",outer/"stderr.log",1800)
        path=outer/"attempt/result.json";result=json.loads(path.read_text()) if path.is_file() else {}
        status=result.get("status") if process["returncode"]==0 and not process.get("timed_out") else "FAILED_OR_INDETERMINATE_NO_RETRY"
        terminal={"run_id":RUN_ID,"status":status,"process":process,"request_sha256":identity(request),"automatic_retry":False}
    except BaseException as error:
        terminal={"run_id":RUN_ID,"status":"FAILED_NO_RETRY","error_type":type(error).__name__,"error":str(error)}
    delivery.write_new(outer/"terminal.json",delivery.encoded(terminal))
    return delivery.publish_result(outer,terminal,package,commit)


def driver(package,payloads):
    import modal
    stage=Path(tempfile.mkdtemp(prefix="orgsci-depth-image-"))
    for name,data in payloads.items():delivery.write_new(stage/name,data)
    requirements=[x.strip() for x in payloads[delivery.LOCK].decode().splitlines() if x.strip() and not x.startswith(("#","./upstream"))]
    image=(modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage),"/opt/preparatory-build",copy=True)
        .pip_install("/opt/preparatory-build/"+delivery.UPSTREAM,extra_options="--no-deps"))
    volume=modal.Volume.from_name(delivery.VOLUME,create_if_missing=False)
    app=modal.App("orgsci-depth-diagnostic-a06",include_source=False)
    @app.function(image=image,gpu="L40S",cpu=8.0,memory=65536,volumes={delivery.MOUNT:volume},
        timeout=1860,retries=0,max_containers=1,max_inputs=1,block_network=True,serialized=True,include_source=False,
        env={"HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1","PYTHONDONTWRITEBYTECODE":"1","OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"})
    def execute(approval,package,payloads):
        import sys
        import modal
        sys.path.insert(0,"/opt/preparatory-build")
        from local_integration import depth_run
        claims=modal.Dict.from_name("orgsci-revised-intervention-100usd-one-use",create_if_missing=True)
        volume=modal.Volume.from_name(depth_run.delivery.VOLUME,create_if_missing=False)
        return depth_run.remote(approval,package,payloads,lambda k,v:claims.put(k,v,skip_if_exists=True),volume.commit)
    return modal,app,execute


def launch():
    request,approval,package,payloads=load()
    budget=json.loads((BASE/"budget.json").read_text())
    reservation=json.loads((BASE/"reservation.json").read_text())
    if budget["aggregate_limit"]!=100.0 or reservation["maximum_usd"]!=12.0 or reservation["run_id"]!=RUN_ID:
        raise PermissionError("The aggregate budget or this reservation changed.")
    amounts=[row["maximum_usd"] for row in budget["planned_reservations"]]
    prior=[row.get("reserved_usd") for row in budget["new_runs"]]
    if any(type(x) not in (int,float) or not (0<x<=100) for x in amounts+prior) or sum(amounts)+sum(prior)>100:
        raise PermissionError("Reservations exceed the authorized aggregate budget.")
    if not any(row["run_id"]==RUN_ID and row["maximum_usd"]==12 and row["status"]=="NOT_SUBMITTED" for row in budget["planned_reservations"]):
        raise PermissionError("A06 does not have an unused budget reservation.")
    # Reserve before all provider contact, including an image lookup or build.
    directory=BASE/"construction/launch";directory.mkdir(exist_ok=False)
    save_new(directory/"submission_claim.json",{"run_id":RUN_ID,"request_sha256":identity(request),
        "maximum_reserved_usd":12.0,"aggregate_limit_usd":100.0,"automatic_retry":False})
    try:
        modal,app,function=driver(package,payloads)
        with modal.enable_output(),app.run(detach=True):
            call=function.spawn(approval,package,payloads)
            receipt={"artifact_type":"PACKAGE_QUALIFICATION_DETACHED_LAUNCH","run_id":RUN_ID,
                "modal_app_id":app.app_id,"modal_function_call_id":call.object_id,
                "transport_sha256":delivery.canonical_hash(package),"status":"SUBMITTED_NOT_VERIFIED"}
            save_new(directory/"launch.json",receipt)
            return receipt
    except BaseException as error:
        save_new(directory/"submission_error.json",{"error_type":type(error).__name__,"error":str(error),"status":"ERROR_OR_INDETERMINATE_NO_RETRY"})
        raise


def main():
    action=sys.argv[1]
    if action in {"launch","retrieve"}:
        # Use the already-installed local SDK, as in the completed A04/A05
        # launchers. This imports a dependency only; no archived study runs.
        sys.path.append(str(ROOT.parent/"model-trace-observatory/.venv/lib/python3.12/site-packages"))
    if action=="prepare":result=prepare()
    elif action=="check":
        request,approval,package,payloads=load()
        result={"status":"A06_CHECK_PASS","request_sha256":identity(request),"files":len(payloads),"provider_contacted":False}
    elif action=="launch":result=launch()
    elif action=="retrieve":result=delivery.retrieve(BASE/"construction/launch")
    else:raise ValueError("Unknown action.")
    print(json.dumps(result),flush=True)

if __name__=="__main__":main()
