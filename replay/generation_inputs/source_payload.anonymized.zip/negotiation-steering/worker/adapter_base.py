"""Model-independent contracts shared by qualification backends."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class Site:
    """A declared decoder-block output and its optional synthetic edit."""

    site_id: str
    module_path: str
    block_type: str
    direction: Any = None
    coefficient: float = 0.0
    output_kind: str = "tensor_or_first"
    position_rule: str = "prefill_last_active_plus_every_decode_token"

    def __post_init__(self) -> None:
        if not self.site_id or not self.module_path or self.module_path.startswith("."):
            raise ValueError("Every site requires a nonempty ID and safe relative module path.")
        if self.block_type not in {"linear_attention", "full_attention", "generic"}:
            raise ValueError("The block type must be declared, not inferred from a tensor shape.")
        if self.output_kind not in {"tensor_or_first", "last_hidden_state"}:
            raise ValueError("Unsupported declared site output.")
        if self.position_rule not in {
            "prefill_last_active_plus_every_decode_token",
            "all_for_bounded_capture_test",
        }:
            raise ValueError("Unsupported position rule.")


class EvidenceAdapter(Protocol):
    """Minimal boundary for later conformance adapters, not a claim of support."""

    def capture_only(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...
    def generate(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...
