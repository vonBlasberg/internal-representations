# Code and local checks

The package now has a working offline review path. It does not contain a research-model launcher.

Latest: [validation audit](../reviews/FINAL_VALIDATION_AUDIT_2026-10-31.md), [test results](../verification/validation-2026-10-31/full-tests-A02/checks.json), and [prospective input materials](../preparation/README.md). No research-model execution was added or performed.

## Implemented

- `history.py`: hash-check and rescore the fixed A05, A06, A09 and A10 publications. Explain each historical eligibility predicate, rank and tie-break without changing the selection.
- `comparison.py` and `sensitivity.py`: retain all nine proposed conditions, invalid or unresolved attempts, original family-weighted statistics, and descriptive variant effects, sign reversals and validity changes.
- `admission.py`: bind actual messages, token-ID records, case content, original settings, all same-run attempts and the outer completion record to a separately pinned input plan. This is an additional admission layer, not a replacement for the mechanical auditor.
- `scoring.py`: the shared narrow malformed-decision guard. It preserves original responses and missing payoffs without modifying the retained scorer.
- `workflow.py`: common study, scorer and saved-result interfaces. Negotiation and an authored resource-allocation task use the same recording/display/export path. The general interface deliberately accepts only synthetic checks for now.
- `inspect_bridge.py`: actual Steerability configuration expansion and provider connection, actual Inspect tasks/scoring/logging, Inspect sample dataframes and local Inspect View bundles. Its pipeline returns explicitly authored responses; it cannot load a model. Outbound connections are blocked.
- `presentation.py` and `cli.py`: flat HTML, complete JSON and CSV exports. All nine conditions and both parties' outcomes remain visible. Exports refuse overwriting and escape spreadsheet formulas.
- `demo.py`: assemble the review build from history and synthetic checks.
- `inputs.py`: canonical messages, with the historical prompt appended to the system message; reject absent, malformed or altered inputs.
- `case_validation.py`: require one base inside each family, actual declared variant changes and no additional input change. Non-fixture plans require a named human review bound to exact case bytes and rendered messages. Free-text privacy and semantic equivalence are human judgments, not claimed keyword-scan guarantees.
- `recording.py`: prepare original inputs and both metadata records before generation; collect original Inspect logs byte-for-byte into the independently checked analysis format. It contains no generation call.
- `recording_check.py`: test that connection through actual Steerability/Inspect using authored responses, including malformed output. It cannot load a model or call a provider service.
- `cache_coverage.py`: wrap the retained cache recorder and reject silently omitted fields. Integrate this explicit wrapper into a future approved worker; do not rewrite historical receipts.
- `local_preparation.py`: prepare an unapproved case-bank draft, exhaustive arithmetic checks, a bounded prior-input scan and assumption-based precision examples. It does not mutate the original protocol or execute a model.
- `geometry.py`: source-bound post hoc A10 vector alignment and actual per-application displacement. No new selection or significance test.
- `checks.py`: run and retain six test suites in a new output directory.
- `verify.py`: check the current inventory and run tests into a new directory outside the package. It never overwrites historical verification records.

The original `code/reused`, `reference_runtime`, proposed scientific protocol, tests/original and historical evidence files are unchanged. The workflow-status specification is updated, and a separate source-bound geometry extract is added. The adapters do not alter historical results or selection rules.

## Verified local environment and commands

For historical replay only, use the two dependencies in `environment/requirements-offline.txt`. From the package root:

```sh
uv venv --python 3.12.10 ../history-venv
uv pip install --python ../history-venv/bin/python --index-url https://pypi.org/simple -r environment/requirements-offline.txt
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=code ../history-venv/bin/python -B -m review_package.cli history --attempt a10 --output ../a10-replay-01
```

This rebuilds the saved result's HTML, JSON and CSV without Torch, Transformers, Steerability or Inspect. Use a new output directory and `--attempt a09` to inspect a failed selection. It does not repeat the research-model execution or mechanical audit. Use the full environment below for integration tests and the complete demo.

Run from the package root, using the existing reviewed environment:

```sh
review_python="../STAGE1_INTERVENTION_PROTOTYPE_2026-10-25/integration-checks/steerability-inspect-2026-10-29/.venv/bin/python"
PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=code:code/reused "$review_python" -m review_package.checks --output verification/my-new-local-check
PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=code:code/reused "$review_python" -m review_package.demo --output outputs/my-new-review-build
```

Choose new directories. Existing records are never overwritten. These commands run software checks and saved-response analysis only. They do not construct a direction, download a model, contact a provider or deploy.

See [the environment record](../environment/README.md) and [current test output](../verification/validation-2026-10-31/full-tests-A02/checks.json) for the exact tested count and versions. All prior tests and receipts remain preserved. A standalone public-source installation is tested; use the reviewer artifact's instructions rather than relying on the historical local path.

## Original-input admission

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=code:code/reused "$review_python" -m review_package.cli check-inputs --manifest PATH/manifest.json --original-plan PATH/original-plan.json --plan-sha256 SEPARATELY_PINNED_ORIGINAL_HASH --output outputs/new-input-review
```

For real saved records the CLI also requires `--allow-real-saved-records`. That option does not authorize execution or certify results. All outputs leave runtime qualification, case independence and release unapproved.

The input-check HTML reports the verified attempt count, pinned source identities and remaining checks. Its download is verification JSON. No scored-attempt CSV is produced by this check.

The new plan format is demonstrated in the synthetic build. It includes exact original case hashes, model-visible messages and token IDs per trial, all log paths and original trial metadata. Its hash must be independently preserved before execution. Retrospective hashing is not proof of precommitment. The complete source-log inventory is required; a check cannot discover a secret omitted log outside that inventory.

Before tokenization, `prepare_plan` checks case-family and variant consistency. For non-fixtures it additionally requires `prompt_review`, created pending with `make_prompt_review(cases, spec)` and completed by an identified reviewer after inspecting the exact text. The plan retains this review, and admission checks it again. Any case or message change invalidates it. The pending draft review is not automatically approved, and its hashes do not authenticate a reviewer or replace the separate owner execution approval. Legacy instruction-paraphrase fixtures remain software tests; prospective scenario paraphrases must actually change the scenario wording.

The retained historical generator records `preparatory_trial`. The new `recording.inspect_sample` adds `behavioral_trial`, `execution_input` and the frozen plan hash before dispatch. `collect_saved_inspect` consumes the exact original Inspect serialization, preserving source bytes and checking the complete attempt inventory. This is now tested end to end with authored responses. The future approved worker must call this adapter and the cache-coverage wrapper; the historical worker was not altered. Applied edits, restoration, weights, real tokenization and actual runtime settings still require the independent mechanical audit.

For a retained model-free demonstration of the new path:

```sh
PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=code:code/reused "$review_python" -m review_package.recording_check --output verification/my-new-recording-check
```

The actual serializer adds message IDs. Only that non-model-visible field is normalized; role, order, text and other metadata remain checked. The test's character-code token IDs are explicitly synthetic, never described as Qwen tokenization.

## Scope of reuse and remaining work

The synthetic checks prove replaceable cases, outcome names and scoring with unchanged shared recording/display/export code. They do not establish arbitrary-model support, safe user uploads, new-study candidate selection or a production nine-arm GPU path.

The frozen family analysis remains specific to negotiation. A different empirical study needs a declared estimand and selection rule; changing the scorer alone does not validate its statistics.

Before a new experiment: approve the proposed amendment and case bank, bind the real execution metadata and mechanical records, verify the exact qualified environment/directions, and approve one source-bound request. No new calibration or construction follows from this implementation.

The review build is separate from the canonical application on port 7114. It has not been merged or deployed. Inspect View bundles contain synthetic logs only; do not bundle private or real logs for release without a separate content and rights review.
