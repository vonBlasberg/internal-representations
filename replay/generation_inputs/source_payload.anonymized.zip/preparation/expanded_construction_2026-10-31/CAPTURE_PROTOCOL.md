# A10 construction-only expansion

Owner approval, October 31, 2026: “Yes expand,” following the request to expand only the construction examples. The active revised-intervention allowance remains US$100 aggregate. No scientific evaluation case, outcome rule or success threshold changes.

## Question and change

Can a direction constructed from making mutually improving counteroffers, rather than accepting standing packages, change the existing calibration decision? A09's two-offer contrast did not change it. A09 remains a negative result. This is a prospective construction hypothesis, not a corrected historical result or a proven diagnosis of a runtime error.

Use all four original construction-fit scenarios with their exact original case content and payoff tables. Add five construction-only standing-package contexts per family, for 24 paired inputs total. Each new context changes only the standing package, its rendered prompt, identifiers and content hash. Original constraints, role, information, option labels, payoff tables and instructions remain exact. Six contexts per family receive equal pair weights; there are still four construction families, not 24 independent families. Nothing is drawn from checking, calibration, development or evaluation cases.

For each standing package, the negative authored reference accepts it. The positive reference offers a valid package accepted under the existing supplier rule, with strictly greater joint payoff and neither party's payoff reduced. Select the positive deterministically: fewest changed terms, then highest joint payoff, then ascending canonical package key. Keep the original standing context first. Greedily choose five additional eligible contexts by least-used set of changed issues, least-used individual issue transitions, greatest minimum Hamming distance between standing packages, then ascending standing-package key. This deterministic diversity rule uses only the construction tables; no model outcomes enter it. Never omit a required original family or redraw after an outcome.

The four originals plus the added contexts cover delivery, payment, and combinations involving price and warranty. Authored reference payoffs verify the input contrast, not model behavior or future transfer. The scorer calculates payoffs; the model is not asked to calculate them. Private payoff tables are used for authoring and scoring but never appended to model prompts.

## Unchanged estimator and bounded execution

Reuse the qualified Qwen/Qwen3.5-9B checkpoint at c202236235762e1c871ad0ccb60c8ee5ba337b9a, BF16, sites 14/15, response-mean pooling, FP32 accumulation, raw difference of equally weighted paired means, and BF16 insertion. Retain selected token states during the same 48 teacher-forced forwards. One load; zero generated responses; no new qualification, download or calibration in this worker. Keep all fixed random seeds. The old four-pair control swaps indices [1,2]. For the expanded set, prospectively fix indices 1,3,...,23: three swaps per six-pair family. This retains the half-swapped control principle but changes the realized index schedule. Keep the original norm matching, nonzero, finite, non-collinearity check and no-redraw rule. The expanded schedule is fixed before any A10 model execution, not chosen from control outcomes.

One L40S container, eight CPU cores, 65,536 MiB, 1,200-second child limit, 1,260-second provider limit, zero application retries and a US$4 maximum reservation. Independent review and exact-upload tests must pass before the unique local and remote claims are consumed. Preserve any failure and stop without retry.

## Verification and later calibration

Local tests must check all original case hashes, independent table arithmetic, the 24 ordered contexts, actual pinned-tokenizer inputs, 48-forward bookkeeping, unchanged weights/restoration, raw-state pooling replay, native vector and fixed-control replay, rejected corrupt records, exact uploaded admission and one-use delivery. A separate local audit verifies returned inventory, outer process, checkpoint/runtime, every retained state, direction and control; it must never load the research model.

Only verified construction permits preparing a separately checked calibration request under the owner's existing goal. Calibration retains its original case, payoff/scoring rules, baseline headroom stop, two layers, three strengths, prompting and control comparisons, selector and 41-generation/7,200-second allowance. No automatic subsequent phase, evaluation, deployment, account upgrade or human recruitment. Preserve all earlier attempts and source files. The tool will show new results only after independent verification.
