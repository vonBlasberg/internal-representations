"""One-use Modal transport for explicitly approved preparatory phases.

The delivery implementation is shared with the locally verified qualification
transport. No qualification, development, evaluation or F4 action is launched.
"""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time

from . import qualification_transport as delivery
from .preparatory_phases import identity

ROOT = Path(__file__).resolve().parents[1]
CLAIMS = "orgsci-preparatory-phase-one-use-claims"
EXTRA = (
    "local_integration/preparatory_transport.py", "local_integration/preparatory_worker.py",
    "local_integration/preparatory_phases.py", "local_integration/preparatory_inspect.py",
    "local_integration/construction_inputs.py", "local_integration/construction_program.py",
    "local_integration/calibration_selection.py", "submission_analysis/__init__.py", "submission_analysis/analyze.py",
    "local_integration/preparatory_run.py",
    "negotiation-steering/study/manifests/behavioral_analysis_contract.json",
    "negotiation-steering/contracts/behavioral_trial.schema.json",
)

def build_package(request, direction_files=None):
    _, payloads = delivery.build_package(request["program"]["qualification_plan"])
    for name in EXTRA:
        path = ROOT / name
        if path.is_symlink():
            raise ValueError("Source symlink refused.")
        payloads[name] = path.read_bytes()
    payloads["request/research.json"] = delivery.encoded(request)
    for name, data in (direction_files or {}).items():
        delivery.safe_relative(name)
        payloads["request/directions/" + name] = data
    inventory = [{"path": name, "sha256": delivery.digest(data), "size_bytes": len(data)} for name, data in sorted(payloads.items())]
    package = {"artifact_type": "PREPARATORY_PHASE_TRANSPORT", "schema_version": 1,
        "run_id": request["run_id"], "stage": request["stage"], "request_sha256": identity(request),
        "files": inventory, "inventory_sha256": identity(inventory),
        "maximum_generation_calls": request["maximum_generation_calls"],
        "process_tree_timeout_seconds": request["maximum_wall_seconds"],
        "base_image_id": delivery.BASE_IMAGE, "gpu": "L40S", "maximum_containers": 1,
        "application_retries": 0, "checkpoint_download": False, "deployment": False}
    return package, payloads

def verify(package, payloads, approval):
    if package.get("artifact_type") != "PREPARATORY_PHASE_TRANSPORT" or package.get("schema_version") != 1:
        raise ValueError("Unsupported preparatory transport.")
    if identity(package["files"]) != package["inventory_sha256"]:
        raise ValueError("Inventory hash differs.")
    expected = {row["path"]: row for row in package["files"]}
    if len(expected) != len(package["files"]) or set(expected) != set(payloads):
        raise ValueError("Source file set differs.")
    for name, row in expected.items():
        delivery.safe_relative(name)
        if len(payloads[name]) != row["size_bytes"] or delivery.digest(payloads[name]) != row["sha256"]:
            raise ValueError("Source file changed: " + name)
    request = json.loads(payloads["request/research.json"])
    if identity(request) != package["request_sha256"] or request["run_id"] != package["run_id"] or request["stage"] != package["stage"]:
        raise ValueError("Request identity differs.")
    caps = {"construction": (10, 1800), "calibration": (41, 7200)}
    if (package["maximum_generation_calls"], package["process_tree_timeout_seconds"]) != caps.get(request["stage"]):
        raise ValueError("Phase allowance differs.")
    if package["base_image_id"] != delivery.BASE_IMAGE or package["gpu"] != "L40S" or package["maximum_containers"] != 1 or package["application_retries"] != 0 or package["deployment"] is not False or package["checkpoint_download"] is not False:
        raise ValueError("Provider configuration differs.")
    required = {"owner_authorized": True, "paid_phase_authorized": True, "request_sha256": identity(request),
        "transport_sha256": delivery.canonical_hash(package), "stage": request["stage"],
        "maximum_generation_calls": request["maximum_generation_calls"], "maximum_wall_seconds": request["maximum_wall_seconds"],
        "automatic_retry": False, "deployment_authorized": False, "f4_authorized": False}
    if any(approval.get(k) != v for k, v in required.items()) or not approval.get("owner_authorization_reference"):
        raise PermissionError("No authority for these exact phase inputs and limits.")
    return request

def remote_execute(approval, package, payloads, claim, commit):
    request = verify(package, payloads, approval)
    if not claim(request["run_id"], {"request_sha256": identity(request), "claimed_at": time.time()}):
        return {"status": "ALREADY_CLAIMED_NO_EXECUTION", "run_id": request["run_id"]}
    outer = Path(delivery.MOUNT) / delivery.result_prefix(request["run_id"])
    outer.mkdir(parents=True, exist_ok=False)
    delivery.write_new(outer / "claimed.json", delivery.encoded({"run_id": request["run_id"], "request_sha256": identity(request), "process_id": os.getpid()}))
    commit()
    try:
        root = Path(delivery.REMOTE)
        for name, data in payloads.items():
            delivery.write_new(root / delivery.safe_relative(name), data)
        delivery.write_new(root / "request/approval.json", delivery.encoded(approval))
        command = [sys.executable, "-m", "local_integration.preparatory_worker",
            str(root / "request/research.json"), str(root / "request/approval.json"), delivery.SNAPSHOT, str(outer / "attempt")]
        process = delivery.run_process(command, root, outer / "stdout.log", outer / "stderr.log", package["process_tree_timeout_seconds"])
        path = outer / "attempt/result.json"
        success = request["stage"].upper() + "_COMPLETE"
        status = success if process["returncode"] == 0 and path.is_file() and json.loads(path.read_text()).get("status") == success else "FAILED_OR_INDETERMINATE_NO_RETRY"
        terminal = {"status": status, "run_id": request["run_id"], "stage": request["stage"], "process": process,
            "automatic_retry": False, "held_out_result": False, "f4_accessed": False, "deployment": False}
    except BaseException as error:
        terminal = {"status": "FAILED_NO_RETRY", "run_id": request["run_id"], "error_type": type(error).__name__, "error": str(error)}
    delivery.write_new(outer / "terminal.json", delivery.encoded(terminal))
    return delivery.publish_result(outer, terminal, package, commit)

def modal_driver(package, payloads):
    import modal
    requirements = [line.strip() for line in payloads[delivery.LOCK].decode().splitlines()
        if line.strip() and not line.startswith("#") and not line.startswith("./upstream")]
    stage = Path(tempfile.mkdtemp(prefix="orgsci-preparatory-image-"))
    # Include the exact module tree in the image so the deserialized entry has
    # no unresolved local imports or captured SDK handles.
    for name, data in payloads.items():
        delivery.write_new(stage / name, data)
    image = (modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage), "/opt/preparatory-build", copy=True)
        .pip_install("/opt/preparatory-build/" + delivery.UPSTREAM, extra_options="--no-deps"))
    volume = modal.Volume.from_name(delivery.VOLUME, create_if_missing=False)
    app = modal.App("orgsci-direction-construction-calibration", include_source=False)
    @app.function(image=image, gpu="L40S", cpu=8.0, memory=65536, volumes={delivery.MOUNT: volume},
        timeout=package["process_tree_timeout_seconds"] + 60, retries=0, max_containers=1, max_inputs=1,
        block_network=True, serialized=True, include_source=False,
        env={"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
             "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false", "DO_NOT_TRACK": "1",
             "PYTHONDONTWRITEBYTECODE": "1", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
    def run(approval, package, payloads):
        import sys
        import modal
        sys.path.insert(0, "/opt/preparatory-build")
        from local_integration import preparatory_transport as transport
        claims = modal.Dict.from_name(transport.CLAIMS, create_if_missing=True)
        volume = modal.Volume.from_name(transport.delivery.VOLUME, create_if_missing=False)
        return transport.remote_execute(approval, package, payloads,
            lambda key, value: claims.put(key, value, skip_if_exists=True), volume.commit)
    return modal, app, run

def launch(request, approval, package, payloads, directory, *, driver=modal_driver):
    if identity(verify(package, payloads, approval)) != identity(request):
        raise ValueError("Local and transported request differ.")
    from .preparatory_worker import check_request
    check_request(request, approval)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    delivery.write_new(directory / "submission_claim.json", delivery.encoded({"run_id": request["run_id"],
        "request_sha256": identity(request), "transport_sha256": delivery.canonical_hash(package), "automatic_retry": False}))
    try:
        modal, app, function = driver(package, payloads)
        with modal.enable_output(), app.run(detach=True):
            call = function.spawn(approval, package, payloads)
            receipt = {"artifact_type": "PACKAGE_QUALIFICATION_DETACHED_LAUNCH", "execution_type": "PREPARATORY_PHASE",
                "run_id": request["run_id"], "stage": request["stage"], "modal_app_id": app.app_id,
                "modal_function_call_id": call.object_id, "transport_sha256": delivery.canonical_hash(package), "status": "SUBMITTED_NOT_VERIFIED"}
            if not receipt["modal_app_id"] or not receipt["modal_function_call_id"]:
                raise RuntimeError("Missing launch handle; do not resubmit.")
            delivery.write_new(directory / "launch.json", delivery.encoded(receipt))
            return receipt
    except BaseException as error:
        delivery.write_new(directory / "submission_error.json", delivery.encoded({"status": "ERROR_OR_INDETERMINATE_NO_RETRY",
            "error_type": type(error).__name__, "error": str(error)}))
        raise
