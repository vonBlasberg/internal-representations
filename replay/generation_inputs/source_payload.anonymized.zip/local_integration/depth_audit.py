"""Independent local audit of A06 files. Never loads research model weights."""
import base64
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import torch

from . import depth_run
from .authored_run import verify_capture
from .authored_worker import prepared_pairs
from .package_qualification import compare, validate_plan
from .preparatory_phases import identity, save_new
from .research_pipeline import GenerationContract
from worker.receipts import tensor_sha256


def read(path):
    return json.loads(Path(path).read_text())


def require(value, message):
    if not value:
        raise ValueError(message)


def near(left, right):
    return (type(left) in (int, float) and math.isfinite(left)
            and math.isfinite(right) and math.isclose(left, right, rel_tol=2e-5, abs_tol=2e-6))


def audit_capture_checks(evidence, response, sites, thresholds, width):
    saved = read(evidence / "capture_checks.json")
    require(saved["thresholds"] == thresholds and saved["pass"] is True, "Capture check or tolerance failed.")
    require(saved["direct_capture_exact"] == {str(layer): True for layer, _ in sites}, "Capture sites differ.")
    artifact = saved["direct_capture_tensors"]
    require(artifact["path"] == "direct_capture_states.pt", "Unexpected tensor artifact.")
    file = evidence / artifact["path"]
    require(depth_run.delivery.file_digest(file) == artifact["sha256"], "Capture tensor hash differs.")
    states = torch.load(file, map_location="cpu", weights_only=True)
    require(set(states) == {f"{kind}_{layer}" for kind in ("capture", "passive") for layer, _ in sites}, "Capture tensor inventory differs.")
    count = min(thresholds["first_cached_response_tokens"], len(response.response_ids))
    positions = [("last_response_token", len(response.input_ids)-1)] + [
        ("successive_response_token", len(response.prefix_ids)+i) for i in range(count)]
    rows = saved["cache_comparison"]
    require(len(rows) == len(sites)*len(positions), "Cached comparison count differs.")
    require(saved["forward_count"] == 5+count, "Diagnostic forward count differs.")
    for layer, _ in sites:
        captured, passive = states[f"capture_{layer}"], states[f"passive_{layer}"]
        require(captured.dtype == passive.dtype == torch.bfloat16, "Capture precision differs.")
        require(tuple(captured.shape) == (1, len(response.input_ids), width), "Capture dimensions differ.")
        require(artifact["shape_by_layer"][str(layer)] == list(captured.shape), "Declared capture shape differs.")
        require(torch.equal(captured, passive), "Helper capture and passive raw hooks differ.")
        selected = [row for row in rows if row["layer"] == layer]
        require([(row["comparison"], row["logical_position"]) for row in selected] == positions, "Cached positions differ.")
        for row in selected:
            full = torch.tensor(row["full_state"], dtype=torch.float32)
            cached = torch.tensor(row["cached_state"], dtype=torch.float32)
            require(full.shape == cached.shape == (width,), "Cached vector dimensions differ.")
            require(torch.equal(full, passive[0, row["logical_position"]].float()), "Full-prefix vector differs from original tensor.")
            require(torch.isfinite(cached).all() and full.norm() > 0, "Nonfinite or zero capture.")
            relative = float((full-cached).norm()/full.norm())
            cosine = float(torch.nn.functional.cosine_similarity(full[None], cached[None])[0])
            require(near(row["relative_l2"], relative) and near(row["cosine"], cosine), "Cached metrics do not reproduce.")
            require(relative <= thresholds["cache_relative_l2_max"] and cosine >= thresholds["cache_cosine_min"], "Cached/full-prefix tolerance exceeded.")
    return {"direct_sites_exact": True, "cached_positions_replayed": len(rows), "diagnostic_forwards": 5+count}


def decode_state(value, name, width):
    require(value["dtype"] == "torch.bfloat16" and value["shape"] == [1, width], "Edited state precision or shape differs.")
    raw = base64.b64decode(value[name], validate=True)
    require(len(raw) == width*2, "Edited state byte count differs.")
    result = torch.frombuffer(bytearray(raw), dtype=torch.bfloat16).clone().reshape(1, width)
    require(torch.isfinite(result).all(), "Nonfinite recorded state.")
    return result


def audit_native(record, contract, expected_weights, input_ids, *, layer=None, direction=None):
    require(record["generation_call_count"] == 1 and record["retry_count"] == 0, "Native call/retry count differs.")
    require(record["weights_before"] == record["weights_after"] and record["weights_unchanged"]
        and record["weights_before"]["entries_sha256"] == expected_weights and record["hook_registry_restored"]
        and record["hooks_before"] == record["hooks_after"] == {"active_hook_paths":[],"active_hook_count":0}, "Native weights/hooks differ.")
    expected = contract.generation_kwargs();expected.pop("pad_token_id")
    require(record["generation_call"] == expected and record["input_token_ids"] == list(input_ids), "Native generation settings/input differ.")
    require(identity(record["loaded_generation_config"]) == contract.generation_config_sha256, "Native generation defaults differ.")
    tokens = record["generated_token_ids"]
    require(0 < len(tokens) == record["new_token_count"] <= contract.max_new_tokens
        and len(record["processed_logit_steps"]) == len(tokens), "Native token count differs.")
    if layer is None:
        require(record["trace"] is None, "Unexpected baseline intervention.")
        return
    trace = record["trace"];name = f"native-{layer}"
    require(trace["hook_registry_restored"] and trace["hook_calls_by_site"] == {name:len(tokens)}
        and trace["nonzero_hook_calls_by_site"] == {name:len(tokens)} and len(trace["captures"]) == len(tokens), "Native edit coverage differs.")
    for i,row in enumerate(trace["captures"]):
        require(row["site_id"] == name and row["resolved_module_path"] == dict(depth_run.SITES)[layer]
            and row["call_index"] == i and row["coefficient"] == 1 and row["nonzero_edit"]
            and row["direction_sha256"] == tensor_sha256(direction.flatten()) and row["finite"]
            and row["storage_dtype"] == "torch.bfloat16" and row["shape"] == [1,1,direction.shape[1]], "Native state receipt differs.")
        require(row["local_token_indices"] == [len(input_ids)-1 if i == 0 else 0]
            and row["logical_token_positions"] == [len(input_ids)-1+i]
            and row["prefill_or_decode"] == ("prefill" if i == 0 else "decode")
            and row["position_metadata_attestation"]["selected_values_verified_from_metadata"]
            and row["realized_l2"] > 0 and row["pre_sha256"] != row["post_sha256"], "Native position/change differs.")


def audit_package(record, direction, input_ids, layer, coefficient, sites, expected_contract, expected_weights, native_trace):
    require(record["status"] == "completed" and record["generation_call_count"] == 1 and record["retry_count"] == 0, "Package execution incomplete.")
    require(record["weights_unchanged"] and record["hooks_restored"] and record["weights_before"] == record["weights_after"], "Package did not restore weights/hooks.")
    require(record["weights_before"]["entries_sha256"] == expected_weights, "Package weights differ from admission.")
    require(record["input_token_ids"] == list(input_ids), "Package input IDs differ.")
    require(record["edit"] == {"layer": layer, "module_path": dict(sites)[layer], "coefficient": coefficient, "direction_sha256": tensor_sha256(direction)}, "Edit specification differs.")
    require(record["applied_direction_sha256"] == tensor_sha256(direction.to(torch.bfloat16)), "Applied direction dtype conversion differs.")
    require(record["contract_sha256"] == identity(record["contract"]), "Execution contract changed.")
    from dataclasses import asdict
    require(identity(record["contract"]) == identity(asdict(expected_contract)), "Package contract differs from admission.")
    contract = GenerationContract(**record["contract"])
    require(record["generation_call"] == contract.generation_kwargs(), "Generation settings differ from contract.")
    tokens = record["generated_token_ids"]
    require(0 < len(tokens) <= contract.max_new_tokens, "Generated token count invalid.")
    require(record["attention_mask"] == [1]*len(input_ids), "Input attention mask differs.")
    diagnostics = record["depth_diagnostics"]
    state_rows, observations = diagnostics["state_steps"], record["state_observations"]
    require(len(state_rows) == len(observations) == len(tokens)*len(sites), "State schedule incomplete.")
    observed = {(row["layer"], row["forward_index"]): row for row in observations}
    require(len(observed) == len(observations), "Duplicate state observation.")
    width = direction.shape[1]
    magnitudes = []
    for selected_layer, path in sites:
        rows = [row for row in state_rows if row["layer"] == selected_layer]
        require([row["step"] for row in rows] == list(range(len(tokens))), "Missing or repeated edit step.")
        for row in rows:
            step = row["step"]; observation = observed[(selected_layer, step)]
            sequence_length = len(input_ids) if step == 0 else 1
            require(observation["module_path"] == path and observation["shape"] == [1, sequence_length, width]
                and observation["dtype"] == "torch.bfloat16" and observation["exact_expected_state"] is True, "State observation does not match schedule.")
            edited = selected_layer == layer and coefficient != 0
            require(observation["changed_batch_token_indices"] == ([[0, sequence_length-1]] if edited else []), "Unexpected direct change position.")
            require(near(observation["realized_l2"], row["realized_l2"]), "Displacement receipts disagree.")
            if selected_layer != layer:
                require(observation["before_sha256"] == observation["after_sha256"] and row["realized_l2"] == 0, "Non-target output directly modified.")
                continue
            before = decode_state(row["values"], "before", width)
            after = decode_state(row["values"], "after", width)
            if step > 0:
                require(tensor_sha256(before) == observation["before_sha256"] and tensor_sha256(after) == observation["after_sha256"], "Decoded state bytes differ from generation observation.")
            if coefficient != 0:
                native = native_trace["captures"][step]
                require(tensor_sha256(before) == native["pre_sha256"] and tensor_sha256(after) == native["post_sha256"], "Package/native selected-row state hashes differ.")
            elif step == 0:
                require(tensor_sha256(before) == native_trace["captures"][0]["pre_sha256"], "Zero-edit prefill differs from native pre-edit state.")
            expected = before + direction.to(torch.bfloat16)*coefficient
            require(torch.equal(after, expected), "Recorded BF16 addition does not reproduce.")
            before_norm = float(before.float().norm()); after_norm = float(after.float().norm())
            displacement = float((after.float()-before.float()).norm())
            require(near(row["before_l2"], before_norm) and near(row["after_l2"], after_norm)
                and near(row["realized_l2"], displacement), "Recorded state norms do not reproduce.")
            require((displacement > 0) == edited, "Nonzero/zero edit requirement failed.")
            if before_norm:
                require(near(row["relative_displacement"], displacement/before_norm), "Relative edit norm differs.")
            else:
                require(row["relative_displacement"] is None, "Zero-norm state has a relative displacement.")
            magnitudes.append(row["relative_displacement"])
    steps = diagnostics["token_steps"]
    require(len(steps) == len(tokens) == len(record["processed_logit_steps"]), "Token diagnostics incomplete.")
    for i, row in enumerate(steps):
        require(row["step"] == i and row["selected_token_id"] == tokens[i]
            and record["processed_logit_steps"][i]["selected_token_id"] == tokens[i], "Token diagnostic identity differs.")
        scores = row["top_scores"]
        require(len(scores) == len(row["top_ids"]) == len(row["top_scores_finite"]) == 5, "Top-score record differs.")
        require([score is not None for score in scores] == row["top_scores_finite"], "Masked score encoding differs.")
        finite = [score for score in scores if score is not None]
        require(finite and all(math.isfinite(score) for score in finite) and finite == sorted(finite, reverse=True), "Invalid top-score ordering.")
        require(row["selected_score"] == row["maximum_score"] == scores[0], "Greedy-selected score is not maximal.")
        if scores[0] is not None and scores[1] is not None:
            require(near(row["top_two_margin"], scores[0]-scores[1]), "Token margin differs.")
        else:
            require(row["top_two_margin"] is None, "Masked top-score margin is not null.")
    finite_magnitudes = [value for value in magnitudes if value is not None]
    return {"generated_tokens":len(tokens), "edited_position_bytes_replayed":True,
        "relative_displacement_min": min(finite_magnitudes) if finite_magnitudes else None,
        "relative_displacement_max": max(finite_magnitudes) if finite_magnitudes else None,
        "token_margins":"Saved summary consistency checked; full score tensors are not retained."}


def audit():
    request, approval, package, payloads = depth_run.load()
    directory = depth_run.BASE / "construction"
    returned = directory / "launch/returned"
    receipt, manifest = read(returned/"retrieval.json"), read(returned/"manifest.json")
    require(receipt["status"] == "ALL_COMMITTED_FILES_VERIFIED" and receipt["manifest_sha256"] == depth_run.delivery.file_digest(returned/"manifest.json"), "Incomplete or changed delivery.")
    require(manifest["run_id"] == request["run_id"] and manifest["transport_sha256"] == identity(package), "Delivery belongs to another request.")
    names = [row["path"] for row in manifest["files"]]
    require(len(names) == len(set(names)) == receipt["file_count"], "Duplicate/missing delivered file.")
    require(set(names) == {str(p.relative_to(returned/"evidence")) for p in (returned/"evidence").rglob("*") if p.is_file()}, "Delivered inventory differs.")
    for row in manifest["files"]:
        file = returned / "evidence" / depth_run.delivery.safe_relative(row["path"])
        require(file.stat().st_size == row["size_bytes"] and depth_run.delivery.file_digest(file) == row["sha256"], "Delivered file changed: "+row["path"])
    terminal = read(returned/"evidence/terminal.json")
    require(terminal == manifest["terminal"] == read(returned/"result.json"), "Outer terminal records differ.")
    require(terminal["request_sha256"] == identity(request) and terminal["process"]["returncode"] == 0
        and terminal["process"].get("timed_out") is False and terminal["status"] == "DEPTH_CONSTRUCTION_AND_MECHANICS_COMPLETE", "Outer process did not complete successfully.")
    evidence = returned / "evidence/attempt"
    started, result = read(evidence/"started.json"), read(evidence/"result.json")
    require(started["request"] == request and started["approval"] == approval and started["request_sha256"] == identity(request), "Worker admission record differs.")
    required = {"status":"DEPTH_CONSTRUCTION_AND_MECHANICS_COMPLETE", "run_id":request["run_id"],
        "request_sha256":identity(request), "generation_calls":8, "completed_generation_records":8,
        "capture_forwards":20, "model_loads":2, "new_sites":request["program"]["sites"],
        "calibration_started":False, "behavioral_result":False, "automatic_retry":False,
        "calibration_authorized_by_this_result":False}
    require(all(result.get(key) == value for key,value in required.items()) and 0 < result["elapsed_seconds"] <= 1800, "Worker counts or scope differ.")
    program = request["program"]; plan = program["qualification_plan"]; contract = validate_plan(plan)
    for name in ("capture_model", "restoration"):
        loaded, runtime = read(evidence/name/"loaded_model.json"), read(evidence/name/"runtime.json")
        require(loaded["weights"]["entries_sha256"] == plan["model_weight_entries_sha256"]
            and loaded["admitted_model_id"] == contract.model_id and loaded["admitted_model_revision"] == contract.model_revision, "Loaded weights/checkpoint differ.")
        reference = plan["runtime_reference"]
        require(runtime["versions"] == reference["actual_runtime_versions"] and runtime["optional_kernels"] == reference["optional_kernel_module_visibility"], "Runtime differs.")
        require(runtime["gpu"]["name"] == reference["actual_gpu"]["name"] and runtime["gpu"]["driver_version"] == reference["actual_gpu"]["driver_version"], "GPU/driver differs.")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(depth_run.ROOT/"negotiation-steering/snapshots/qwen35-9b"/contract.model_revision/"verified-snapshot"), local_files_only=True, trust_remote_code=False)
    pairs, tokens = prepared_pairs(request, tokenizer)
    construction = verify_capture(program, request["construction_source"], evidence, pairs, tokens)
    construction.pop("generation_count")  # Legacy helper's two generated checks do not apply to A06.
    width = read(evidence/"construction_spec.json")["hidden_width"]
    capture = audit_capture_checks(evidence, pairs[0].positive, program["sites"], request["capture_checks"], width)
    require(result["directions"] == read(evidence/"directions/directions.json")["directions"], "Returned directions differ.")
    baseline = read(evidence/"native-baseline/execution.json")
    compare(plan["inputs"][1]["native_reference"], baseline)
    audit_native(baseline,contract,plan["model_weight_entries_sha256"],plan["inputs"][1]["input_token_ids"])
    mechanics = {}
    for layer, _ in program["sites"]:
        direction = torch.frombuffer(bytearray((evidence/"constructed"/f"layer-{layer}-raw.f32le").read_bytes()), dtype=torch.float32).clone().reshape(1,width)
        native = read(evidence/f"native-{layer}/execution.json")
        audit_native(native,contract,plan["model_weight_entries_sha256"],plan["inputs"][1]["input_token_ids"],layer=layer,direction=direction)
        for name, coefficient, reference in ((f"zero-{layer}",0,baseline),(f"package-{layer}",1,native)):
            record = read(evidence/name/"execution.json")
            require(read(evidence/name/"package_execution.json") == [record], "Package receipt copies differ.")
            compare(reference, record)
            mechanics[name] = audit_package(record,direction,plan["inputs"][1]["input_token_ids"],layer,coefficient,program["sites"],contract,plan["model_weight_entries_sha256"],native["trace"])
    for name in ("native-baseline","zero-14","native-14","package-14","zero-15","native-15","package-15"):
        require(read(evidence/name/"check.json") == {"status":"PASS","kind":"mechanical_not_behavioral"}, "Mechanical check missing.")
    restored = read(evidence/"restoration/execution.json")
    require(read(evidence/"restore_process.json")["returncode"] == 0 and restored["fresh_process"]
        and restored["process_id"] != started["pid"], "Fresh restoration not established.")
    compare(baseline, restored)
    audit_native(restored,contract,plan["model_weight_entries_sha256"],plan["inputs"][1]["input_token_ids"])
    protected = read(directory/"preserved_before.json")
    require(identity(protected) == request["preserved_inventory_sha256"], "Original preservation snapshot changed.")
    require(all(depth_run.delivery.file_digest(depth_run.ROOT/name) == expected for name,expected in protected.items()), "Protected original source or record changed.")
    report = {"status":"A06_CONSTRUCTION_AND_MECHANICS_VERIFIED", "run_id":request["run_id"],
        "request_sha256":identity(request), "checked_at_utc":datetime.now(timezone.utc).isoformat(),
        "returned_files_verified":len(names), "protected_files_unchanged":len(protected),
        "construction":construction, "capture":capture, "mechanics":mechanics,
        "fresh_process_restoration_exact":True, "research_model_loaded":False,
        "behavioral_result":False, "automatic_execution":False}
    save_new(directory/"terminal_audit.json",report)
    return report


if __name__ == "__main__":
    print(json.dumps(audit(), indent=2))
