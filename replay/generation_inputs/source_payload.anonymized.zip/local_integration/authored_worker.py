"""One authorized authored-reference construction, or its verified calibration.

Generation, model loading, state capture, controls and calibration reuse the
unchanged qualified implementation. Only construction-example provenance changes.
"""
from copy import deepcopy
from dataclasses import asdict
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from . import preparatory_worker as base
from .preparatory_phases import identity, save_new, execute_phase, check_construction_labels
from .construction_program import phase_plan, phase_approval, calibration_arms
from .reference_construction import validate_bundle, prepare_reference_tokens

PARENT_PROGRAM_ID = "negotiation-construction-calibration-2026-10-30-A03"
PARENT_PROGRAM_SHA256 = "04852a3dc86a28557446906a1944dbad13fbfac6802a508257c966ec65028d54"
PROGRAM_ID = "negotiation-authored-construction-calibration-2026-10-30-A04"


def check_request(request, approval):
    contract = base.check_request(request, approval)
    program = request["program"]
    original = deepcopy(program)
    original["program_id"] = PARENT_PROGRAM_ID
    if identity(original) != PARENT_PROGRAM_SHA256 or program["program_id"] != PROGRAM_ID:
        raise ValueError("Only the execution identifier may change in the preserved A03 program.")
    if request["run_id"] != PROGRAM_ID + "-" + request["stage"]:
        raise ValueError("Unexpected one-use run identifier.")
    source = request.get("construction_source", {})
    required_keys = {"kind", "schema_version", "parent_program_sha256", "references", "references_sha256",
        "teacher_forcing_inputs", "teacher_forcing_inputs_sha256", "amendment_sha256", "adapter_sha256"}
    if (set(source) != required_keys or source["kind"] != "score_defined_authored_references"
            or source["schema_version"] != 1 or source["parent_program_sha256"] != PARENT_PROGRAM_SHA256):
        raise ValueError("Unsupported authored-reference amendment.")
    if (identity(source["references"]) != source["references_sha256"]
            or identity(source["teacher_forcing_inputs"]) != source["teacher_forcing_inputs_sha256"]):
        raise ValueError("Authored inputs changed.")
    if (approval.get("construction_source_sha256") != identity(source)
            or approval.get("amendment_sha256") != source["amendment_sha256"]
            or approval.get("authored_reference_amendment_authorized") is not True):
        raise PermissionError("The authored-reference amendment lacks exact owner authority.")
    adapter = Path(__file__).with_name("reference_construction.py")
    if hashlib.sha256(adapter.read_bytes()).hexdigest() != source["adapter_sha256"]:
        raise ValueError("The prepared reference adapter changed.")
    cases = program["cases"]["construction_fit"]
    validate_bundle(cases, source["references"], expected_case_ids=[c["case_id"] for c in cases])
    if request["stage"] == "calibration":
        audit = request["construction_audit"]
        if (audit.get("run_id") != PROGRAM_ID + "-construction"
                or audit.get("request_sha256") != request.get("construction_request_sha256")
                or audit.get("construction_source_sha256") != identity(source)
                or audit.get("checks", {}).get("authored_inputs_verified") is not True
                or audit.get("checks", {}).get("construction_check", {}).get("status") != "PASS"):
            raise PermissionError("Calibration requires this exact independently verified authored construction.")
    return contract


def prepared_pairs(request, tokenizer):
    source, program = request["construction_source"], request["program"]
    pairs, receipt = prepare_reference_tokens(program["cases"]["construction_fit"], source["references"],
        tokenizer, program["qualification_plan"]["generation_contract"])
    # Match the persisted JSON representation, without changing token values.
    record = json.loads(json.dumps({**receipt, "pairs": [asdict(pair) for pair in pairs]}))
    if record != source["teacher_forcing_inputs"]:
        raise ValueError("Actual tokenizer does not reproduce the approved authored inputs exactly.")
    return pairs, record


def run_construction(request, reference, destination, model_factory, tokenizer, *, generator_class=base.InspectPhaseGenerator):
    program = request["program"]
    contract = base.qualification_contract(program["qualification_plan"])
    pairs, record = prepared_pairs(request, tokenizer)
    save_new(destination / "authored_references.json", request["construction_source"]["references"])
    save_new(destination / "teacher_forcing_inputs.json", record)
    plan = phase_plan(program, "construction_check")
    connection = generator_class(plan, contract, model_factory=model_factory, direction_loader=None)
    result = execute_phase(plan, program["cases"]["construction_check"], phase_approval(plan, reference),
        destination / "phases", generate=connection)
    check = check_construction_labels(plan, program["cases"]["construction_check"], result)
    save_new(destination / "construction_check.json", check)
    if result["failure"] or check["status"] != "PASS":
        raise RuntimeError("Separate construction check failed; no capture or calibration.")
    if len(result["records"]) != 2:
        raise ValueError("Authored construction requires exactly two separate check generations.")
    location = destination / "capture_model"
    location.mkdir(exist_ok=False)
    model, _ = model_factory(location)
    try:
        spec = base.ConstructionSpec(contract.model_id, contract.model_revision, contract.model_type,
            tuple(tuple(site) for site in program["sites"]), model.get_input_embeddings().weight.shape[1],
            tuple(p.pair_id for p in pairs), base.input_hash(pairs),
            tuple(f for f, p in program["family_partitions"].items() if p != "construction_fit"),
            program["pooling"], program["accumulation_dtype"], program["insertion_dtype"],
            contract.max_input_tokens + contract.max_new_tokens, False)
        save_new(destination / "construction_spec.json", asdict(spec))
        fitted = base.construct_directions(model, pairs, spec)
        if fitted.record["capture_forward_count"] != program["limits"]["construction_capture_forwards"]:
            raise RuntimeError("Capture count differs from the preserved allowance.")
        fitted.save(destination / "constructed")
        directions = base.generate_control_files(program, fitted, destination / "directions")
    finally:
        del model
        gc.collect()
    return {"status": "CONSTRUCTION_COMPLETE", "direction_manifest": directions,
        "generation_calls": 2, "authored_reference_count": 8,
        "authored_reference_source": "algorithmically_authored_reference",
        "capture_forwards": fitted.record["capture_forward_count"], "behavioral_steering_result": False}


def main():
    request_path, approval_path, snapshot, destination = map(Path, sys.argv[1:])
    request, approval = json.loads(request_path.read_text()), json.loads(approval_path.read_text())
    contract = check_request(request, approval)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination / "started.json", {"request": request, "approval": approval})
    started, loads = time.monotonic(), 0
    program = request["program"]

    def factory(directory):
        nonlocal loads
        limit = 3 if request["stage"] == "construction" else request["maximum_generation_calls"]
        if loads >= limit:
            raise RuntimeError("Declared model-loading count exhausted.")
        loads += 1
        import torch
        gc.collect()
        torch.cuda.empty_cache()
        model, tokenizer, unused = base.load_admitted_model(program["qualification_plan"], snapshot, directory)
        del unused
        return model, tokenizer

    try:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
        if request["stage"] == "construction":
            prepared_pairs(request, tokenizer)
            plans = [phase_plan(program, "construction_check")]
        else:
            plans = [phase_plan(program, "calibration", calibration_arms(program, request["directions"]))]
        admission = []
        for plan in plans:
            for trial in plan["trials"]:
                ids = tokenizer.apply_chat_template(trial["messages"], tokenize=True, return_dict=False,
                    add_generation_prompt=True, enable_thinking=False)
                admission.append({"trial_id": trial["trial_id"], "input_token_ids": ids,
                    "sha256": identity(ids), "within_limit": len(ids) <= contract.max_input_tokens})
        save_new(destination / "input_admission.json", admission)
        if not all(r["within_limit"] for r in admission):
            raise ValueError("Input exceeds the unchanged limit; no truncation.")
        if request["stage"] == "construction":
            result = run_construction(request, approval["owner_authorization_reference"], destination, factory, tokenizer)
        else:
            result = base.run_calibration(request, approval["owner_authorization_reference"], destination, factory)
    except BaseException as error:
        result = {"status": "FAILED_NO_RETRY", "error_type": type(error).__name__, "error": str(error)}
    result.update(run_id=request["run_id"], request_sha256=identity(request),
        construction_source_sha256=identity(request["construction_source"]),
        elapsed_seconds=time.monotonic()-started, model_loads=loads,
        automatic_retry=False, f4_accessed=False, deployment=False)
    save_new(destination / "result.json", result)
    print(json.dumps(result), flush=True)
    if result["status"] == "FAILED_NO_RETRY":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
