"""Thin native PyTorch adapter with fail-closed positions and exact receipts."""
from __future__ import annotations

import copy
import math
from typing import Any

from worker.adapter_base import Site
from worker.receipts import HookRegistry, tensor_sha256


def resolve_module(model: Any, path: str, layer: int | None = None) -> Any:
    if layer is not None:
        if isinstance(layer, bool) or not isinstance(layer, int) or layer < 0:
            raise ValueError("Layer must be a nonnegative integer.")
        path = path.replace("{layer}", str(layer))
    if not isinstance(path, str) or not path or "{layer}" in path or path.startswith("."):
        raise ValueError("Module path is empty, absolute, or has an unresolved layer placeholder.")
    current = model
    for segment in path.split("."):
        if not segment or segment.startswith("_") or not segment.isidentifier() and not segment.isdigit():
            raise ValueError(f"Unsafe module path segment: {segment!r}")
        if segment.isdigit():
            if not hasattr(current, "__getitem__"):
                raise ValueError(f"Module is not indexable at {segment}.")
            try:
                current = current[int(segment)]
            except (IndexError, KeyError, TypeError) as exc:
                raise ValueError(f"Module index cannot be resolved: {segment}") from exc
        else:
            if not hasattr(current, segment):
                raise ValueError(f"Resolved model has no declared module: {segment}")
            current = getattr(current, segment)
    if not hasattr(current, "register_forward_hook"):
        raise TypeError("Declared site does not resolve to a hookable module.")
    return current


def _output_tensor(output: Any, kind: str) -> Any:
    import torch

    if kind == "last_hidden_state":
        value = getattr(output, "last_hidden_state", None)
    elif torch.is_tensor(output):
        value = output
    elif isinstance(output, (tuple, list)) and output:
        value = output[0]
    else:
        value = None
    if not torch.is_tensor(value):
        raise TypeError("Declared site output does not resolve to a tensor.")
    if value.ndim != 3 or value.shape[0] != 1:
        raise ValueError("The bounded adapter requires [batch=1, local_sequence, hidden].")
    return value


def _replace_output(output: Any, tensor: Any, kind: str) -> Any:
    import torch

    if kind == "last_hidden_state":
        if hasattr(output, "_replace"):
            return output._replace(last_hidden_state=tensor)
        replaced = copy.copy(output)
        setattr(replaced, "last_hidden_state", tensor)
        return replaced
    if torch.is_tensor(output):
        return tensor
    if isinstance(output, tuple):
        return (tensor,) + output[1:]
    if isinstance(output, list):
        return [tensor] + output[1:]
    raise TypeError("Unsupported declared site output container.")


def _position_values(value: Any, local_sequence: int) -> list[int] | None:
    if value is None or not hasattr(value, "detach"):
        return None
    position = value.detach().to(device="cpu")
    if position.ndim == 3:
        if position.shape[0] < 1 or position.shape[-1] != local_sequence or position.shape[1] != 1:
            raise ValueError("Multimodal position metadata does not contain a batch-1 text row.")
        position = position[0]
    if position.shape[-1] != local_sequence or position.numel() != local_sequence:
        raise ValueError("Position metadata length differs from the local query sequence.")
    values = position.reshape(-1).tolist()
    if any(isinstance(item, bool) or not isinstance(item, int) or item < 0 for item in values):
        raise ValueError("Logical token positions must be nonnegative integers.")
    return values


def position_attestation(kwargs: dict[str, Any], local_sequence: int) -> tuple[list[int], dict[str, Any]]:
    cache_values = _position_values(kwargs.get("cache_position"), local_sequence)
    position_values = _position_values(kwargs.get("position_ids"), local_sequence)
    if cache_values is not None and position_values is not None and cache_values != position_values:
        raise RuntimeError("cache_position and text position_ids disagree.")
    values = cache_values if cache_values is not None else position_values
    if values is None:
        raise RuntimeError("No actual position metadata; refusing to infer logical position from local index zero.")
    sources = [name for name, value in (("cache_position", cache_values), ("position_ids", position_values)) if value is not None]
    attestation = {
        "source": sources,
        "selected_values_verified_from_metadata": True,
        "local_sequence_length": local_sequence,
        "local_index_fallback_forbidden": True,
        "cache_and_text_positions_agree": cache_values is None or position_values is None or cache_values == position_values,
        "multimodal_position_rule": "first_of_four_rows_is_text" if kwargs.get("position_ids") is not None and kwargs["position_ids"].ndim == 3 else "two_dimensional_text_positions",
    }
    return values, attestation


class NativeInterventionSession:
    """Multi-site recording or a single-site additive edit; never a weight edit."""

    def __init__(
        self,
        model: Any,
        sites: list[Site],
        *,
        trial_id: str,
        attention_mask: Any = None,
        max_selected_values: int = 4096,
    ) -> None:
        import torch

        if not sites or not trial_id:
            raise ValueError("A trial ID and at least one declared site are required.")
        if isinstance(max_selected_values, bool) or not isinstance(max_selected_values, int) or not 0 < max_selected_values <= 4096:
            raise ValueError("The capture bound must be in 1..4096 values per site and forward.")
        if len({site.site_id for site in sites}) != len(sites) or len({site.module_path for site in sites}) != len(sites):
            raise ValueError("Site IDs and resolved paths must be unique within a trial.")
        nonzero_sites = [site for site in sites if site.coefficient != 0.0]
        if len(nonzero_sites) > 1:
            raise ValueError("Only one nonzero edited site is permitted per trial.")
        for site in nonzero_sites:
            if site.position_rule != "prefill_last_active_plus_every_decode_token":
                raise ValueError("Nonzero qualification edits use only the declared prefill/decode position rule.")
        self.model = model
        self.trial_id = trial_id
        self.attention_mask = attention_mask
        self.max_selected_values = max_selected_values
        self.hook_registry = HookRegistry(model)
        self._resolved: list[tuple[Site, Any, Any]] = []
        self._handles: list[Any] = []
        self._counts: dict[str, int] = {}
        self._nonzero_counts: dict[str, int] = {}
        self.captures: list[dict[str, Any]] = []
        self.closed = False
        for site in sites:
            module = resolve_module(model, site.module_path)
            if module._forward_hooks:
                raise RuntimeError(f"Pre-existing target hook makes {site.module_path} ambiguous.")
            direction = site.direction
            if direction is not None:
                if not torch.is_tensor(direction) or direction.ndim != 1 or direction.numel() < 1 or not direction.dtype.is_floating_point:
                    raise ValueError("Direction must be a nonempty one-dimensional floating-point tensor.")
                if not bool(torch.isfinite(direction).all().item()):
                    raise ValueError("Direction must be finite.")
                direction = direction.detach().clone()
            elif site.coefficient != 0.0:
                raise ValueError("A nonzero coefficient requires a direction.")
            self._resolved.append((site, module, direction))
            self._counts[site.site_id] = 0
            self._nonzero_counts[site.site_id] = 0

    def _indices(self, site: Site, tensor: Any, logical: list[int]) -> Any:
        import torch

        local_sequence = tensor.shape[1]
        decode = self._counts[site.site_id] > 0 or (local_sequence == 1 and logical[0] > 0)
        if decode:
            if local_sequence != 1:
                raise RuntimeError("A cached decode call must have exactly one local query token.")
            indices = [0]
        elif site.position_rule == "all_for_bounded_capture_test":
            indices = list(range(local_sequence))
        else:
            if local_sequence == 1:
                indices = [0]
            elif self.attention_mask is None:
                indices = [local_sequence - 1]
            else:
                mask = self.attention_mask
                if mask.ndim != 2 or tuple(mask.shape) != (1, local_sequence):
                    raise ValueError("The original batch-1 attention mask must match the prefill sequence.")
                active = torch.nonzero(mask[0] != 0, as_tuple=False).reshape(-1)
                if active.numel() == 0:
                    raise ValueError("The actual prefill input has no active token.")
                indices = [int(active[-1].item())]
        if len(indices) * tensor.shape[-1] > self.max_selected_values:
            raise ValueError("Capture exceeds the declared 4096-value bound per site and forward.")
        return torch.tensor(indices, dtype=torch.long, device=tensor.device)

    def _hook(self, site: Site, direction: Any, module_path: str, args: tuple[Any, ...], kwargs: dict[str, Any], output: Any) -> Any:
        import torch

        tensor = _output_tensor(output, site.output_kind)
        logical, attestation = position_attestation(kwargs, tensor.shape[1])
        indices = self._indices(site, tensor, logical)
        local_indices = [int(item) for item in indices.detach().cpu().tolist()]
        logical_positions = [logical[index] for index in local_indices]
        if direction is not None and direction.numel() != tensor.shape[-1]:
            raise ValueError(f"Direction width {direction.numel()} != site width {tensor.shape[-1]}.")
        if not isinstance(site.coefficient, (int, float)) or isinstance(site.coefficient, bool) or not math.isfinite(site.coefficient):
            raise ValueError("The site coefficient must be finite and numeric.")
        pre = tensor.index_select(1, indices).detach().clone()
        requested_nonzero = bool(direction is not None and site.coefficient != 0.0 and torch.count_nonzero(direction).item())
        if site.coefficient != 0.0 and not requested_nonzero:
            raise RuntimeError("A declared nonzero intervention cannot use a zero direction.")
        if requested_nonzero:
            delta = direction.to(device=tensor.device, dtype=tensor.dtype) * site.coefficient
            if not bool(torch.isfinite(delta).all().item()) or not bool(torch.count_nonzero(delta).item()):
                raise RuntimeError("The nonzero direction vanished or became nonfinite during the storage-dtype cast.")
            edited = tensor.clone()
            edited.index_add_(1, indices, delta.reshape(1, 1, -1).expand(1, len(indices), -1))
            post = edited.index_select(1, indices).detach().clone()
            result = _replace_output(output, edited, site.output_kind)
        else:
            post = pre.clone()
            result = output
        difference = post.float() - pre.float()
        finite = bool(torch.isfinite(pre).all().item() and torch.isfinite(post).all().item() and torch.isfinite(difference).all().item())
        realized_max = float(difference.abs().max().item())
        if not finite:
            raise RuntimeError("The selected state or realized edit is nonfinite.")
        if requested_nonzero and realized_max <= 0.0:
            raise RuntimeError("The requested nonzero edit produced no realized post-insertion-dtype displacement.")
        if not requested_nonzero and realized_max != 0.0:
            raise RuntimeError("A recording or zero-strength hook was not an exact no-op.")
        call_index = self._counts[site.site_id]
        phase = "decode" if call_index > 0 or (tensor.shape[1] == 1 and logical[0] > 0) else "prefill"
        capture = {
            "trial_id": self.trial_id,
            "site_id": site.site_id,
            "resolved_module_path": module_path,
            "block_type": site.block_type,
            "call_index": call_index,
            "prefill_or_decode": phase,
            "local_token_indices": local_indices,
            "logical_token_positions": logical_positions,
            "position_metadata_attestation": attestation,
            "shape": list(pre.shape),
            "selected_value_count": int(pre.numel()),
            "storage_dtype": str(tensor.dtype),
            "direction_sha256": tensor_sha256(direction) if direction is not None else None,
            "coefficient": float(site.coefficient),
            "nonzero_edit": requested_nonzero,
            "pre_sha256": tensor_sha256(pre),
            "post_sha256": tensor_sha256(post),
            "realized_l2": float(difference.norm().item()),
            "realized_max_abs": realized_max,
            "finite": finite,
            "same_layer_cache_directly_edited": False,
            "raw_state_retained": False,
        }
        self.captures.append(capture)
        self._counts[site.site_id] += 1
        if requested_nonzero:
            self._nonzero_counts[site.site_id] += 1
        return result

    def __enter__(self) -> "NativeInterventionSession":
        if self._handles or self.closed:
            raise RuntimeError("A closed or active session cannot be reopened.")
        try:
            for site, module, direction in self._resolved:
                def hook(_module: Any, args: tuple[Any, ...], kwargs: dict[str, Any], output: Any, *, _site: Site = site, _direction: Any = direction, _path: str = site.module_path) -> Any:
                    return self._hook(_site, _direction, _path, args, kwargs, output)
                self._handles.append(module.register_forward_hook(hook, with_kwargs=True))
        except Exception:
            self.close()
            raise
        return self

    def close(self) -> None:
        for handle in reversed(self._handles):
            handle.remove()
        self._handles.clear()
        self.closed = True
        self.hook_registry.assert_restored(self.model)

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> bool:
        self.close()
        return False

    def receipt(self) -> dict[str, Any]:
        return {
            "trace_kind": "BOUNDED_SELECTED_STATE_EDIT_RECEIPT",
            "trial_id": self.trial_id,
            "captures": list(self.captures),
            "hook_calls_by_site": dict(self._counts),
            "nonzero_hook_calls_by_site": dict(self._nonzero_counts),
            "max_selected_values_per_site_per_forward": self.max_selected_values,
            "raw_full_hidden_states_retained": False,
            "hook_registry_restored": self.closed,
            "weight_mutation_check": "REQUIRED_OUTER_GENERATION_OR_CAPTURE_RECEIPT",
        }
