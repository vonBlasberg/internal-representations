"""Prospective A10 behavioral phase. No provider or automatic execution entry.

The one-load generation/scoring sequence follows the frozen A06 implementation.
Only verified construction artifacts, their descriptive metadata and run identity
change. Actual calibration cases, 41 conditions and selection criteria are fixed.
"""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time

from . import headroom_worker
from .construction_program import phase_plan, calibration_arms
from .calibration_diagnostics import calibration_diagnostic_connection
from .depth_diagnostics import typed_decision_parser
from .package_qualification import validate_plan
from .preparatory_phases import identity, save_new
from .qualification_worker import load_admitted_model
from .reused_model import SequentialModelSession, ReusedInspectGenerator

ROOT = Path(__file__).resolve().parents[1]
PROGRAM_ID = "negotiation-expanded-2026-10-31-A10"
RUN_ID = PROGRAM_ID + "-calibration"
CONSTRUCTION_ID = PROGRAM_ID + "-construction"
REUSE_POLICY = "same_admitted_weights_new_pipeline_and_dynamic_cache_per_trial"
PARENT_REQUEST_ID = "3fa9a8cbb226fb200a855c179f7755cd334da6e4ada304508989c75019fb523a"
PARENT_TRANSPORT_ID = "67b0cb2564d865d948b52737c8e3210b7d081e3b44aa220554af13da4fd69191"
PINNED = {
    "previous-calibration.json": "34871224f45b41948282fd539e9d3b75446cd3912ed2416cd01efeb78f999ec9",
    "parent-request.json": "a8c98f128aa8f7beacd58defeb54f9938a9257c237a4a37e0220fbe3f28fcea7",
    "parent-audit.json": "de0ac53081c460b0b8e14f0c879caf7aff82d3bc4cf06343c97e811352965a8f",
    "parent-manifest.json": "be9393d1ceaa94a5efedec562f5b89e11b0bae4f5812bf98bb1ca423f814f460",
    "parent-directions.json": "57f73043bc3a02d3d2496947446c74680792ec7913bb06b9cde8a7a8f43f3877",
}
LIMITS = {"maximum_generation_calls": 41, "maximum_wall_seconds": 7200,
          "maximum_model_loads": 1, "maximum_reserved_usd": 12.0, "aggregate_limit_usd": 100.0}


def checked_evidence(files):
    for name, expected in PINNED.items():
        if hashlib.sha256(files[name]).hexdigest() != expected:
            raise ValueError("Verified construction or previous design changed: " + name)
    previous, parent, audit, manifest, directions = [json.loads(files[name]) for name in PINNED]
    if (identity(parent) != PARENT_REQUEST_ID or parent["run_id"] != CONSTRUCTION_ID
            or audit["status"] != "EXPANDED_CONSTRUCTION_VERIFIED"
            or audit["request_sha256"] != PARENT_REQUEST_ID or audit["run_id"] != CONSTRUCTION_ID
            or audit["behavioral_result"] or audit["generation_calls"] != 0
            or audit["capture_forwards"] != 48 or not audit["fixed_controls_reproduced"]
            or not audit["raw_and_normalized_vectors_reproduced"] or not audit["native_svec_vectors_reproduced"]
            or audit["outer_delivery_source_and_process_checks_still_required"]
            or manifest["run_id"] != CONSTRUCTION_ID or manifest["transport_sha256"] != PARENT_TRANSPORT_ID
            or manifest["terminal"] != audit["outer_terminal"]
            or manifest["terminal"]["process"] != {"returncode":0, "timed_out":False}
            or manifest["terminal"]["status"] != "EXPANDED_CONSTRUCTION_COMPLETE"
            or directions["program_sha256"] != identity(parent["program"])):
        raise ValueError("Construction is not the independently verified A10 outcome.")
    entries = {entry["path"]:entry for entry in manifest["files"]}
    if len(entries) != len(manifest["files"]) or len(entries) != audit["returned_files_verified"]:
        raise ValueError("Parent delivery inventory differs.")
    declared = set()
    for kind, layers in directions["directions"].items():
        if kind not in {"raw", "permuted", "random_1", "random_2", "random_3"} or set(layers) != {"14", "15"}:
            raise ValueError("Direction/control coverage differs.")
        for entry in layers.values():
            name = entry["path"]
            if Path(name).name != name or name in declared:
                raise ValueError("Unsafe or duplicate vector name.")
            declared.add(name)
            original = entries["attempt/capture/directions/" + name]
            raw = files["directions/" + name]
            if (original["sha256"] != entry["sha256"] or original["size_bytes"] != entry["size_bytes"]
                    or hashlib.sha256(raw).hexdigest() != entry["sha256"] or len(raw) != entry["size_bytes"]
                    or entry["shape"] != [1, 4096]):
                raise ValueError("Direction bytes differ from the audited construction.")
    if len(declared) != 10 or set(files) != set(PINNED) | {"directions/" + name for name in declared}:
        raise ValueError("Exactly ten verified vectors and all parent records are required.")
    return previous, parent, audit, directions


def draft_request(files, authority_sha256, reservation_sha256):
    previous, parent, audit, directions = checked_evidence(files)
    program = deepcopy(previous["program"])
    program["program_id"] = PROGRAM_ID
    # Update construction provenance without altering any calibration input,
    # condition, strength, runtime setting or behavioral selection criterion.
    program['cases']['construction_fit'] = deepcopy(parent['program']['cases']['construction_fit'])
    program['permuted_control'] = deepcopy(parent['program']['permuted_control'])
    program['construction_rule'] = deepcopy(parent['program']['construction_rule'])
    program['direction_sign'] = 'mutually_improving_offer_minus_acceptance'
    program['limits']['construction_generation_calls'] = 0
    program['limits']['construction_capture_forwards'] = 48
    program['limits']['construction_wall_seconds'] = 1200
    plan = phase_plan(program, "calibration", calibration_arms(program, directions["directions"]))
    return {"run_id":RUN_ID, "stage":"calibration", "program":program, "program_sha256":identity(program),
            "construction_request":parent, "construction_audit":audit,
            "construction_source":parent["construction_source"], "verified_direction_manifest":directions,
            "directions":directions["directions"], "source_sha256":dict(PINNED),
            "phase_plan_sha256":identity(plan), "model_reuse_policy":REUSE_POLICY, **LIMITS,
            "authorization_sha256":authority_sha256, "reservation_sha256":reservation_sha256,
            "changed":["verified_construction_vectors", "construction_provenance_metadata", "run_identity"],
            "automatic_retry":False, "held_out_result":False, "deployment_authorized":False}


def check_request(request, approval, *, evidence_files=None, root=ROOT):
    if evidence_files is None:
        names = list(PINNED) + ["directions/" + entry["path"]
            for values in request["directions"].values() for entry in values.values()]
        evidence_files = {name:(Path(root)/"request"/name).read_bytes() for name in names}
    if request != draft_request(evidence_files, request["authorization_sha256"], request["reservation_sha256"]):
        raise ValueError("Only the exact verified directions and unchanged calibration are admitted.")
    for key in ("authorization_sha256", "reservation_sha256"):
        value = request[key]
        if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
            raise ValueError("An authority or reservation digest is missing.")
    required = {"owner_authorized":True, "paid_phase_authorized":True, "request_sha256":identity(request),
                **LIMITS, "automatic_retry":False, "deployment_authorized":False}
    if any(approval.get(key) != value for key, value in required.items()) or not approval.get("owner_authorization_reference"):
        raise PermissionError("Exact bounded calibration authority is required.")
    plan = phase_plan(request["program"], "calibration", calibration_arms(request["program"], request["directions"]))
    if len(plan["trials"]) != 41 or identity(plan) != request["phase_plan_sha256"]:
        raise ValueError("The fixed 41-condition comparison differs.")
    return validate_plan(request["program"]["qualification_plan"])


def run(request, approval, snapshot, destination):
    contract = check_request(request, approval)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination/"started.json", {"request":request, "approval":approval})
    started = time.monotonic()
    session = None
    try:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
        plan = phase_plan(request["program"], "calibration", calibration_arms(request["program"], request["directions"]))
        admitted = []
        for trial in plan["trials"]:
            ids = tokenizer.apply_chat_template(trial["messages"], tokenize=True, return_dict=False,
                add_generation_prompt=True, enable_thinking=False)
            admitted.append({"trial_id":trial["trial_id"], "input_token_ids":ids, "sha256":identity(ids), "within_limit":len(ids)<=contract.max_input_tokens})
        save_new(destination/"input_admission.json", admitted)
        if not all(row["within_limit"] for row in admitted):
            raise ValueError("Input exceeds the unchanged allowance. No truncation or model load.")
        def loader(directory):
            model, tokenizer, unused = load_admitted_model(request["program"]["qualification_plan"], snapshot, directory)
            del unused
            return model, tokenizer
        session = SequentialModelSession(destination/"shared_model", loader,
            expected_weights_sha256=request["program"]["qualification_plan"]["model_weight_entries_sha256"], contract=contract)
        def connection(plan, supplied_contract, *, model_factory, direction_loader):
            if identity(asdict(supplied_contract)) != identity(asdict(contract)) or model_factory != session.acquire:
                raise ValueError("The generation connection differs from the admitted session.")
            return ReusedInspectGenerator(plan, contract, model_session=session, direction_loader=direction_loader)
        with calibration_diagnostic_connection(), typed_decision_parser():
            result = headroom_worker.run_calibration(request, approval["owner_authorization_reference"],
                destination, session.acquire, generator_class=connection)
        if (session.failed or session.loads != 1 or session.generation_attempts != result["generation_calls"]
                or session.completed_trials != result["generation_calls"]):
            raise RuntimeError("Session counts differ from the completed phase.")
    except BaseException as error:
        result = {"status":"FAILED_NO_RETRY", "error_type":type(error).__name__, "error":str(error)}
    result.update(run_id=request["run_id"], request_sha256=identity(request), elapsed_seconds=time.monotonic()-started,
        session=None if session is None else session.summary(), construction_repeated=False,
        automatic_retry=False, held_out_result=False, deployment=False)
    save_new(destination/"result.json", result)
    if result["status"] == "FAILED_NO_RETRY":
        raise SystemExit(1)
    return result


if __name__ == "__main__":
    request, approval, snapshot, destination = map(Path, sys.argv[1:])
    print(json.dumps(run(json.loads(request.read_text()), json.loads(approval.read_text()), snapshot, destination)), flush=True)
