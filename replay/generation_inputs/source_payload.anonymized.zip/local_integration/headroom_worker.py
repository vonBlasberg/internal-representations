"""One corrected calibration after A04; unchanged model route, early baseline stop."""
from copy import deepcopy
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

from . import preparatory_worker as base
from . import authored_worker as authored
from .construction_program import ROOT, phase_plan, phase_approval, calibration_arms
from .preparatory_phases import identity, save_new, validate_plan, validate_authority, scorer, summarize_calibration
from .calibration_selection import select

PROGRAM_ID = "negotiation-headroom-2026-10-30-A05"
PARENT_REQUEST_SHA256 = "2c6a90b53089928635adccd1d79521a2a5afd00488e191369806a7237e48cbc5"
CASE_SHA256 = "cf3a0608480d5628ee28c477cce8fc7307749a450d6e9204f99daf4e6a442c74"
GATE_PATH = "preparation/calibration_headroom_2026-10-30/headroom.py"
AMENDMENT_PATH = "preparation/calibration_headroom_2026-10-30/AMENDMENT.md"


def gate_module():
    spec = importlib.util.spec_from_file_location("calibration_headroom_gate", ROOT/GATE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_request(request, approval):
    parent = request["parent_calibration_request"]
    if identity(parent) != PARENT_REQUEST_SHA256:
        raise ValueError("Only the preserved A04 calibration may be the parent.")
    authored.check_request(parent, request["parent_calibration_approval"])
    if request["stage"] != "calibration" or request["run_id"] != PROGRAM_ID+"-calibration":
        raise ValueError("Only the single A05 calibration is admitted; no construction.")
    contract = base.check_request(request, approval)
    expected = deepcopy(parent["program"])
    expected["program_id"] = PROGRAM_ID
    variant, provenance = gate_module().prepare_variant(parent["program"]["cases"]["calibration"][0])
    expected["cases"]["calibration"] = [variant]
    if request["program"] != expected or variant["case_content_sha256"] != CASE_SHA256:
        raise ValueError("Only the declared one-field case amendment and run identifier may change.")
    inherited = set(parent) - {"run_id", "program", "program_sha256", "phase_plan_sha256"}
    if any(request[k] != parent[k] for k in inherited):
        raise ValueError("A construction, direction, qualification, stage or limit record changed.")
    if set(request) != set(parent) | {"parent_calibration_request", "parent_calibration_approval", "parent_completion", "headroom_amendment"}:
        raise ValueError("Unexpected request fields.")
    amendment = request["headroom_amendment"]
    hashes = {"gate_sha256": hashlib.sha256((ROOT/GATE_PATH).read_bytes()).hexdigest(),
              "amendment_sha256": hashlib.sha256((ROOT/AMENDMENT_PATH).read_bytes()).hexdigest()}
    if amendment != {**hashes, "provenance": provenance, "baseline_first": True,
            "no_automatic_case_replacement": True, "no_retry": True}:
        raise ValueError("The tested correction or baseline gate changed.")
    if (approval.get("ceiling_correction_authorized") is not True
            or approval.get("baseline_gate_required") is not True
            or approval.get("headroom_amendment_sha256") != identity(amendment)
            or approval.get("parent_completion_sha256") != identity(request["parent_completion"])):
        raise PermissionError("Exact prospective correction and completed parent need owner authority.")
    completed = request["parent_completion"]
    audit, terminal = completed["audit"], completed["terminal"]
    if (audit.get("status") != "CALIBRATION_VERIFIED" or audit.get("request_sha256") != PARENT_REQUEST_SHA256
            or audit.get("run_id") != parent["run_id"] or len(audit.get("rows", [])) != 41
            or audit.get("worker_result", {}).get("status") != "CALIBRATION_COMPLETE"
            or audit["worker_result"].get("generation_calls") != 41
            or audit["worker_result"].get("model_loads") != 41
            or terminal.get("status") != "CALIBRATION_COMPLETE" or terminal.get("run_id") != parent["run_id"]
            or terminal.get("process", {}).get("returncode") != 0
            or terminal["process"].get("timed_out") is not False
            or completed.get("retrieval", {}).get("status") != "ALL_COMMITTED_FILES_VERIFIED"
            or completed.get("preservation", {}).get("status") != "PASS"):
        raise PermissionError("A04 has not completed with independently verified delivery and preservation.")
    plan = phase_plan(expected, "calibration", calibration_arms(expected, request["directions"]))
    if identity(plan) != request["phase_plan_sha256"] or len(plan["trials"]) != 41:
        raise ValueError("Exact calibration plan differs.")
    return contract


def execute_with_gate(plan, cases, approval, runs_root, *, generate):
    """Preserve the existing phase record format; stop after an infeasible baseline.

    Unexecuted conditions use NOT_RUN_AFTER_FAILURE for compatibility with the
    unchanged scorer, plus an explicit skip_reason distinguishing this planned
    feasibility stop from a technical error. Baseline remains COMPLETED.
    """
    validate_plan(plan, cases)
    validate_authority(plan, approval)
    if (plan["phase"] != "calibration" or len(cases) != 1
            or plan["trials"][0]["kind"] != "unchanged"):
        raise ValueError("One baseline-first calibration case is required.")
    scoring = scorer()
    directory = Path(runs_root)/plan["run_id"]
    directory.mkdir(parents=True, exist_ok=False)
    save_new(directory/"started.json", {"plan": plan, "approval": approval,
        "executor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    records, failure, admission = [], None, None
    started = time.monotonic()
    for index, trial in enumerate(plan["trials"]):
        row = {"trial_id": trial["trial_id"], "case_id": trial["case_id"], "family_id": trial["family_id"],
            "arm_id": trial["arm_id"], "kind": trial["kind"], "phase": plan["phase"],
            "plan_sha256": identity(plan), "execution_status": "NOT_RUN_AFTER_FAILURE", "raw_response": None}
        if failure is None:
            location = directory/trial["trial_id"]
            location.mkdir(exist_ok=False)
            save_new(location/"trial.json", trial)
            try:
                if time.monotonic()-started >= plan["maximum_wall_seconds"]:
                    raise TimeoutError("Phase allowance exhausted; no next call.")
                output = generate(trial, location)
                if not isinstance(output, dict) or not isinstance(output.get("raw_response"), str):
                    raise ValueError("A completed generation must return exact text.")
                row.update(execution_status="COMPLETED", raw_response=output["raw_response"], source=output)
                save_new(location/"generation.json", row)
                row["score"] = scoring.score_response(cases[0], row["raw_response"])
                if index == 0:
                    admission = gate_module().admission(cases[0], row["raw_response"])
                    save_new(directory/"baseline_admission.json", admission)
                    if not admission["treatments_allowed_by_feasibility"]:
                        failure = {"trial_id": trial["trial_id"], "error_type": "BaselineFeasibilityStop",
                            "error": admission["status"], "technical_failure": False}
                        save_new(location/"stop.json", failure)
                elif not row["score"]["valid"] and plan["stop_on_invalid"]:
                    raise ValueError("Invalid response at declared stopping gate.")
                if time.monotonic()-started > plan["maximum_wall_seconds"]:
                    raise TimeoutError("Phase allowance exceeded after response preservation.")
            except Exception as error:
                failure = {"trial_id": trial["trial_id"], "error_type": type(error).__name__,
                    "error": str(error), "technical_failure": True}
                if row["execution_status"] != "COMPLETED":
                    row["execution_status"] = "TECHNICAL_FAILURE"
                    row["score"] = scoring.technical_failure_result(cases[0])
                save_new(location/"failure.json", failure)
        else:
            row["skip_reason"] = failure["error"]
        records.append(row)
        save_new(directory/f"record-{index:05d}.json", row)
    stopped = failure is not None and failure["error_type"] == "BaselineFeasibilityStop"
    result = {"artifact_type": "PREPARATORY_PHASE_RESULT", "schema_version": 1,
        "run_id": plan["run_id"], "phase": plan["phase"], "plan_sha256": identity(plan),
        "status": "STOPPED_BASELINE_FEASIBILITY" if stopped else "FAILED_NO_RETRY" if failure else "COMPLETE_NOT_SCIENTIFICALLY_QUALIFIED",
        "fixture_only": plan["fixture_only"], "records": records, "failure": failure,
        "baseline_admission": admission, "elapsed_seconds": time.monotonic()-started,
        "automatic_retry": False, "behavioral_qualification": False, "selection_authorized": False,
        "release_approved": False}
    save_new(directory/"result.json", result)
    return result


def run_calibration(request, reference, destination, model_factory, *, generator_class=base.InspectPhaseGenerator):
    import numpy as np
    import torch
    program, directions = request["program"], request["directions"]
    plan = phase_plan(program, "calibration", calibration_arms(program, directions))
    if identity(plan) != request["phase_plan_sha256"]:
        raise ValueError("Calibration plan changed.")
    def load_direction(edit, _):
        entries = [e for values in directions.values() for e in values.values() if e["sha256"] == edit["direction_sha256"]]
        if not entries:
            raise ValueError("Undeclared direction.")
        entry = entries[0]
        data = (ROOT/"request/directions"/entry["path"]).read_bytes()
        if len(data) != entry["size_bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError("Saved A04 direction bytes differ.")
        return torch.from_numpy(np.frombuffer(data, dtype="<f4").copy()).reshape(entry["shape"])
    connection = generator_class(plan, base.qualification_contract(program["qualification_plan"]),
        model_factory=model_factory, direction_loader=load_direction)
    baseline_receipt = None
    def generate(trial, directory):
        nonlocal baseline_receipt
        output = connection(trial, directory)
        receipt = json.loads((directory/"state_execution.json").read_text())["records"][-1]
        if trial["kind"] == "unchanged": baseline_receipt = receipt
        if trial["kind"] == "sham":
            keys = ("input_token_ids", "generated_token_ids", "processed_logit_steps")
            if baseline_receipt is None or any(receipt[k] != baseline_receipt[k] for k in keys):
                save_new(directory/"sham_failure_output.json", output)
                raise RuntimeError("Zero edit changed the baseline; stop calibration.")
        return output
    result = execute_with_gate(plan, program["cases"]["calibration"], phase_approval(plan, reference), destination/"phases", generate=generate)
    summary = summarize_calibration(plan, program["cases"]["calibration"], result)
    selection = select(plan, program["cases"]["calibration"], result)
    save_new(destination/"calibration_summary.json", summary)
    save_new(destination/"selection.json", selection)
    stopped = result["status"] == "STOPPED_BASELINE_FEASIBILITY"
    if result["failure"] and not stopped:
        raise RuntimeError("Calibration failed; all attempted and unattempted records retained.")
    return {"status": "CALIBRATION_STOPPED_BASELINE_FEASIBILITY" if stopped else "CALIBRATION_COMPLETE",
        "selection": selection, "baseline_admission": result["baseline_admission"],
        "generation_calls": sum(r["execution_status"] == "COMPLETED" for r in result["records"]),
        "planned_conditions": len(result["records"]), "skipped_conditions": sum(r["execution_status"] == "NOT_RUN_AFTER_FAILURE" for r in result["records"]),
        "held_out_result": False}


def main():
    request_path, approval_path, snapshot, destination = map(Path, sys.argv[1:])
    request, approval = (json.loads(p.read_text()) for p in (request_path, approval_path))
    contract = check_request(request, approval)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination/"started.json", {"request": request, "approval": approval})
    started, loads = time.monotonic(), 0
    def factory(directory):
        nonlocal loads
        if loads >= request["maximum_generation_calls"]:
            raise RuntimeError("Declared model-loading allowance exhausted.")
        loads += 1
        import torch
        gc.collect()
        torch.cuda.empty_cache()
        model, tokenizer, unused = base.load_admitted_model(request["program"]["qualification_plan"], snapshot, directory)
        del unused
        return model, tokenizer
    try:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
        plan = phase_plan(request["program"], "calibration", calibration_arms(request["program"], request["directions"]))
        admission = []
        for trial in plan["trials"]:
            ids = tokenizer.apply_chat_template(trial["messages"], tokenize=True, return_dict=False,
                add_generation_prompt=True, enable_thinking=False)
            admission.append({"trial_id": trial["trial_id"], "input_token_ids": ids, "sha256": identity(ids), "within_limit": len(ids) <= contract.max_input_tokens})
        save_new(destination/"input_admission.json", admission)
        if not all(row["within_limit"] for row in admission):
            raise ValueError("Input exceeds the unchanged allowance; no truncation.")
        result = run_calibration(request, approval["owner_authorization_reference"], destination, factory)
    except BaseException as error:
        result = {"status": "FAILED_NO_RETRY", "error_type": type(error).__name__, "error": str(error)}
    result.update(run_id=request["run_id"], request_sha256=identity(request),
        headroom_amendment_sha256=identity(request["headroom_amendment"]),
        parent_request_sha256=PARENT_REQUEST_SHA256, elapsed_seconds=time.monotonic()-started,
        model_loads=loads, construction_repeated=False, automatic_retry=False, f4_accessed=False, deployment=False)
    save_new(destination/"result.json", result)
    print(json.dumps(result), flush=True)
    if result["status"] == "FAILED_NO_RETRY": raise SystemExit(1)


if __name__ == "__main__": main()
