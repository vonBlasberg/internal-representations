from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from peft import PeftType, TaskType

from steerability.algorithms.core.base_args import BaseArgs


@dataclass
class TRLArgs(BaseArgs):
    """Arguments shared by the TRL-backed structural controls.

    `target_modules` selects the modules a LoRA adapter attaches to. A list of module-name suffixes
    (the default, `["q_proj", "v_proj"]`) is scoped at `steer()` to the decoder stack of the resolved
    model layout, so a multimodal wrapper's vision and audio towers are not adapted. A string is a
    PEFT full-match regex over module names and is passed through unchanged, which is how modules
    outside the decoder stack are targeted.

    `output_dir` (or a `training_args["output_dir"]` entry) is where the trained model or adapter
    is saved. When neither is set, `steer()` saves to a temporary directory created on the first
    `steer()` of the control.
    """

    # when the pipeline has no base model of its own, the structural control can load these.
    base_model_name_or_path: str | None = None
    tokenizer_name_or_path: str | None = None
    hf_model_kwargs: dict[str, Any] = field(default_factory=dict)
    trust_remote_code: bool = False

    # datasets / collators
    train_dataset: Any | None = None
    eval_dataset: Any | None = None
    data_collator: Any | None = None

    # training (forwarded to TRL configs)
    training_args: dict[str, Any] = field(default_factory=dict)
    output_dir: str | Path | None = None
    learning_rate: float = 2e-5
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 8
    per_device_eval_batch_size: int = 8
    gradient_accumulation_steps: int = 1
    warmup_steps: int | float = 0  # int = steps; float in [0, 1) = ratio of total steps (transformers v5)
    save_strategy: str = "no"
    load_best_model_at_end: bool = True
    bf16: bool | None = None
    fp16: bool = False
    logging_steps: int = 10
    report_to: str | None = None
    seed: int | None = None
    resume_from_checkpoint: str | None = None  # checkpoint directory passed to trainer.train(); unsupported by PPO

    # PEFT knobs
    use_peft: bool = False
    peft_type: PeftType = PeftType.LORA
    r: int = 16
    lora_alpha: int = 32
    target_modules: list[str] | str = field(default_factory=lambda: ["q_proj", "v_proj"])
    modules_to_save: list[str] | None = None
    lora_dropout: float = 0.05
    bias: str = "none"  # "none" | "all" | "lora_only"
    task_type: TaskType = TaskType.CAUSAL_LM
    init_lora_weights: str | None = None
    use_rslora: bool | None = None
    adapter_name: str | None = "sft"

    # optional in-place LoRA merge after training (no separate control); left False, the trained
    # adapter stays attached as a PeftModel and a state control listed after it hooks the adapted model
    merge_lora_after_train: bool = False
    merged_output_dir: str | Path | None = None  # where to save merged model/tokenizer

    # autofilled PEFT kwargs
    lora_kwargs: dict[str, Any] = field(init=False)

    def __post_init__(self) -> None:

        # an unset output directory stays None here; the trainer resolves a transient one at steer time
        self.output_dir = self.output_dir or self.training_args.get("output_dir")

        # compose training args
        base_training_args = {
            "output_dir": self.output_dir,
            "learning_rate": self.learning_rate,
            "num_train_epochs": self.num_train_epochs,
            "per_device_train_batch_size": self.per_device_train_batch_size,
            "per_device_eval_batch_size": self.per_device_eval_batch_size,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "warmup_steps": self.warmup_steps,
            "load_best_model_at_end": self.load_best_model_at_end,
            "save_strategy": self.save_strategy,
            "bf16": self.bf16 if self.bf16 is not None else False,  # None is filtered out downstream; TRL 1.x then auto-detects, which raises on CPU-only hosts
            "fp16": self.fp16,
            "logging_steps": self.logging_steps,
            "report_to": self.report_to,
            "seed": self.seed,
            "resume_from_checkpoint": self.resume_from_checkpoint,
            "remove_unused_columns": False,
        }
        self.training_args = {**base_training_args, **self.training_args}

        # validation
        if self.r <= 0:
            raise ValueError("LoRA `r` must be > 0.")
        if self.lora_alpha <= 0:
            raise ValueError("`lora_alpha` must be > 0.")
        if not (0 <= self.lora_dropout < 1):
            raise ValueError("`lora_dropout` must be in [0, 1).")
        if self.bias not in {"none", "all", "lora_only"}:
            raise ValueError(f"bias must be 'none'|'all'|'lora_only'; got {self.bias!r}")
        if isinstance(self.target_modules, (list, tuple)):
            self.target_modules = list(self.target_modules)
            valid_targets = bool(self.target_modules) and all(isinstance(name, str) for name in self.target_modules)
        else:
            valid_targets = isinstance(self.target_modules, str) and bool(self.target_modules)
        if not valid_targets:
            raise ValueError(
                "`target_modules` must be a non-empty list of module-name suffixes or a non-empty regex string; got "
                f"{self.target_modules!r}"
            )

        self.lora_kwargs = {
            "r": self.r,
            "lora_alpha": self.lora_alpha,
            "target_modules": self.target_modules,
            "lora_dropout": self.lora_dropout,
            "bias": self.bias,
            "modules_to_save": self.modules_to_save,
            "task_type": self.task_type,
        }
        if self.init_lora_weights is not None:
            self.lora_kwargs["init_lora_weights"] = self.init_lora_weights
        if self.use_rslora is not None:
            self.lora_kwargs["use_rslora"] = self.use_rslora
