"""One-use transport for capture only. Preparation never submits a GPU job."""
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
import tempfile
import time
import zipfile

from . import depth_run, qualification_transport as delivery
from .expanded_worker import RUN_ID, LIMITS, draft_request, check_request, PARENT_AUDIT, PARENT_MANIFEST
from .expanded_references import SOURCE
from .preparatory_phases import identity, save_new

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'records/expanded_construction_2026-10-31_A10'
DIRECTORY = BASE / 'construction'
BUDGET = ROOT / 'records/revised_intervention_2026-10-31_A06/budget.json'
WORKER = 'local_integration.expanded_worker'
PROTOCOL = 'preparation/expanded_construction_2026-10-31/CAPTURE_PROTOCOL.md'
EXTRA = tuple('local_integration/' + name for name in (
    'expanded_references.py', 'expanded_capture.py', 'expanded_worker.py',
    'expanded_audit.py', 'expanded_run.py', 'generation_sensitivity.py',
    'target_alignment_checks.py', 'buyer_matched_references.py')) + (SOURCE, PARENT_AUDIT, PARENT_MANIFEST, PROTOCOL)
SETTINGS = {'artifact_type': 'EXPANDED_CAPTURE_TRANSPORT', 'schema_version': 1, 'run_id': RUN_ID,
    'stage': 'expanded_construction', 'worker_module': WORKER, 'base_image_id': delivery.BASE_IMAGE,
    'gpu': 'L40S', 'cpu_limit': 8, 'memory_limit_mib': 65536, 'maximum_containers': 1,
    'maximum_generation_calls': 0, 'maximum_capture_forwards': 48, 'maximum_model_loads': 1,
    'process_tree_timeout_seconds': 1200, 'application_retries': 0, 'maximum_reserved_usd': 4.0,
    'aggregate_limit_usd': 100.0, 'checkpoint_download': False, 'deployment': False}


def read(path):
    return json.loads(Path(path).read_text())


def protected_inventory():
    result = {}
    for directory in (ROOT / 'records', ROOT / 'local_integration', ROOT / 'tests',
                      ROOT / 'negotiation-steering/analysis', ROOT / 'negotiation-steering/worker', ROOT / Path(PROTOCOL).parent):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and not path.is_symlink() and BASE not in path.parents and path != BUDGET and '__pycache__' not in path.parts:
                result[str(path.relative_to(ROOT))] = delivery.file_digest(path)
    return result


def build(request):
    _, _, _, payloads = depth_run.load()
    for name in EXTRA:
        payloads[name] = (ROOT / name).read_bytes()
    payloads['request/research.json'] = delivery.encoded(request)
    for name in ('AUTHORIZATION.md', 'reservation.json'):
        payloads['request/A10-' + name] = (BASE / name).read_bytes()
    inventory = [{'path': name, 'sha256': delivery.digest(raw), 'size_bytes': len(raw)} for name, raw in sorted(payloads.items())]
    package = {**SETTINGS, 'request_sha256': identity(request), 'files': inventory, 'inventory_sha256': identity(inventory)}
    return package, payloads


def approval_for(request, package):
    return {'owner_authorized': True, 'paid_phase_authorized': True,
        'request_sha256': identity(request), 'transport_sha256': identity(package), **LIMITS,
        'automatic_retry': False, 'calibration_authorized': False, 'deployment_authorized': False,
        'authorization_sha256': delivery.file_digest(BASE / 'AUTHORIZATION.md'),
        'reservation_sha256': delivery.file_digest(BASE / 'reservation.json'),
        'owner_authorization_reference': 'Owner: Yes expand. Construction-only expansion within active US$100 aggregate goal; calibration only after verified construction.'}


def verify(package, payloads, approval, *, local=False):
    if any(package.get(key) != value for key, value in SETTINGS.items()):
        raise ValueError('Capture transport settings changed.')
    inventory = {entry['path']: entry for entry in package['files']}
    if len(inventory) != len(package['files']) or set(inventory) != set(payloads) or identity(package['files']) != package['inventory_sha256']:
        raise ValueError('Capture transport inventory changed.')
    for name, entry in inventory.items():
        delivery.safe_relative(name)
        if delivery.digest(payloads[name]) != entry['sha256'] or len(payloads[name]) != entry['size_bytes']:
            raise ValueError('Capture source changed: ' + name)
    request = json.loads(payloads['request/research.json'])
    required = {'owner_authorized': True, 'paid_phase_authorized': True,
        'request_sha256': identity(request), 'transport_sha256': identity(package), **LIMITS,
        'automatic_retry': False, 'calibration_authorized': False, 'deployment_authorized': False}
    if any(approval.get(key) != value for key, value in required.items()) or package['request_sha256'] != identity(request):
        raise PermissionError('The exact bounded construction request is not approved.')
    for name, key in (('AUTHORIZATION.md', 'authorization_sha256'), ('reservation.json', 'reservation_sha256')):
        if delivery.digest(payloads['request/A10-' + name]) != approval[key]:
            raise ValueError('Authority or reservation record changed.')
    if local:
        with tempfile.TemporaryDirectory(prefix='buyer-exact-upload-') as temporary:
            root = Path(temporary)
            for name, raw in payloads.items(): delivery.write_new(root / name, raw)
            check_request(request, approval, root)
    return request


def require_a09_verified():
    path = ROOT / 'records/buyer_matched_construction_2026-10-31_A09/calibration/terminal_audit.json'
    report = read(path)
    if delivery.file_digest(path) != '9d1d0f1c3d911de215ae27883ba763276c0f8450cc2158fc4578ebc08ce44d0c':
        raise PermissionError('The completed A09 audit must remain exact.')
    return {'path': str(path.relative_to(ROOT)), 'sha256': delivery.file_digest(path)}


def verify_preflight(request, package):
    pointer = read(BASE / 'preflight.json')
    path = ROOT / delivery.safe_relative(pointer['report_path'])
    if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('Unsafe preflight report path.')
    report = read(path)
    if (delivery.file_digest(path) != pointer['report_sha256']
            or report.get('status') != 'PASS' or report.get('request_sha256') != identity(request)
            or report.get('transport_sha256') != identity(package) or not report.get('exact_upload_checked')
            or not report.get('independent_auditor_tested') or not report.get('review_findings_resolved')):
        raise PermissionError('Exact-upload, delivery and independent-audit preflight must pass first.')
    required = {'local_integration/expanded_' + name + '.py' for name in
                ('references', 'worker', 'capture', 'audit', 'run')}
    if not required.issubset(report['source_sha256']):
        raise PermissionError('Preflight must bind all five new source modules.')
    for name, wanted in report['source_sha256'].items():
        path = ROOT / delivery.safe_relative(name)
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()) or delivery.file_digest(path) != wanted:
            raise ValueError('Preflight source changed: ' + name)


def prepare():
    previous = require_a09_verified()
    request = draft_request()
    package, payloads = build(request)
    approval = approval_for(request, package)
    verify(package, payloads, approval, local=True)
    verify_preflight(request, package)
    approval.update(previous_a09_audit=previous, preflight_sha256=delivery.file_digest(BASE / 'preflight.json'))
    DIRECTORY.mkdir(exist_ok=False)
    inventory = protected_inventory()
    approval['preserved_inventory_sha256'] = identity(inventory)
    for name, value in (('request.json', request), ('approval.json', approval), ('transport.json', package), ('preserved_before.json', inventory)):
        save_new(DIRECTORY / name, value)
    with zipfile.ZipFile(DIRECTORY / 'source_payload.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name, raw in payloads.items(): archive.writestr(name, raw)
    save_new(DIRECTORY / 'source_archive.json', {'sha256': delivery.file_digest(DIRECTORY / 'source_payload.zip')})
    return {'status': 'PREPARED_NOT_SUBMITTED', 'files': len(payloads), 'request_sha256': identity(request)}


def load():
    request, approval, package = [read(DIRECTORY / name) for name in ('request.json', 'approval.json', 'transport.json')]
    if delivery.file_digest(DIRECTORY / 'source_payload.zip') != read(DIRECTORY / 'source_archive.json')['sha256']:
        raise ValueError('Frozen source archive changed.')
    with zipfile.ZipFile(DIRECTORY / 'source_payload.zip') as archive:
        if len(archive.namelist()) != len(set(archive.namelist())): raise ValueError('Duplicate archive path.')
        payloads = {name: archive.read(name) for name in archive.namelist()}
    if verify(package, payloads, approval, local=True) != request: raise ValueError('Saved request differs.')
    for name, raw in payloads.items():
        if not name.startswith('request/') and (ROOT / name).read_bytes() != raw: raise ValueError('Frozen source changed: ' + name)
    for name, key in (('AUTHORIZATION.md', 'authorization_sha256'), ('reservation.json', 'reservation_sha256'), ('preflight.json', 'preflight_sha256')):
        if delivery.file_digest(BASE / name) != approval[key]: raise ValueError('Frozen authority or preflight changed.')
    verify_preflight(request, package)
    previous = approval['previous_a09_audit']
    if delivery.file_digest(ROOT / previous['path']) != previous['sha256']: raise ValueError('Previous terminal audit changed.')
    inventory = read(DIRECTORY / 'preserved_before.json')
    if identity(inventory) != approval['preserved_inventory_sha256'] or any(delivery.file_digest(ROOT / name) != wanted for name, wanted in inventory.items()):
        raise ValueError('Protected originals changed.')
    return request, approval, package, payloads


def remote(approval, package, payloads, claim, commit):
    request = verify(package, payloads, approval)
    if not claim(RUN_ID, {'request_sha256': identity(request), 'claimed_at': time.time()}):
        return {'status': 'ALREADY_CLAIMED_NO_EXECUTION', 'run_id': RUN_ID, 'files': {}}
    outer = Path(delivery.MOUNT) / delivery.result_prefix(RUN_ID)
    outer.mkdir(parents=True, exist_ok=False)
    delivery.write_new(outer / 'claimed.json', delivery.encoded({'run_id': RUN_ID, 'request_sha256': identity(request)})); commit()
    try:
        root = Path(delivery.REMOTE)
        for name, raw in payloads.items(): delivery.write_new(root / delivery.safe_relative(name), raw)
        delivery.write_new(root / 'request/approval.json', delivery.encoded(approval))
        process = delivery.run_process([sys.executable, '-B', '-m', WORKER, str(root / 'request/research.json'),
            str(root / 'request/approval.json'), delivery.SNAPSHOT, str(outer / 'attempt')],
            root, outer / 'stdout.log', outer / 'stderr.log', 1200)
        result = read(outer / 'attempt/result.json') if (outer / 'attempt/result.json').is_file() else {}
        status = ('EXPANDED_CONSTRUCTION_COMPLETE' if process['returncode'] == 0 and not process.get('timed_out')
                  and result.get('status') == 'EXPANDED_CONSTRUCTION_COMPLETE' else 'FAILED_OR_INDETERMINATE_NO_RETRY')
        terminal = {'status': status, 'run_id': RUN_ID, 'request_sha256': identity(request), 'process': process,
                    'automatic_retry': False, 'calibration_authorized': False}
    except BaseException as error:
        terminal = {'status': 'FAILED_NO_RETRY', 'run_id': RUN_ID, 'request_sha256': identity(request),
                    'error_type': type(error).__name__, 'error': str(error), 'automatic_retry': False}
    delivery.write_new(outer / 'terminal.json', delivery.encoded(terminal))
    return delivery.publish_result(outer, terminal, package, commit)


def driver(package, payloads):
    import modal
    stage = Path(tempfile.mkdtemp(prefix='expanded-image-'))
    for name, raw in payloads.items(): delivery.write_new(stage / name, raw)
    requirements = [line.strip() for line in payloads[delivery.LOCK].decode().splitlines() if line.strip() and not line.startswith(('#', './upstream'))]
    image = (modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage), '/opt/preparatory-build', copy=True)
        .pip_install('/opt/preparatory-build/' + delivery.UPSTREAM, extra_options='--no-deps'))
    volume = modal.Volume.from_name(delivery.VOLUME, create_if_missing=False)
    app = modal.App('orgsci-expanded-capture-a10', include_source=False)
    @app.function(image=image, gpu='L40S', cpu=(8.0, 8.0), memory=(65536, 65536), volumes={delivery.MOUNT: volume},
                  timeout=1260, retries=0, max_containers=1, max_inputs=1, block_network=True,
                  serialized=True, include_source=False, env={'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
                  'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'})
    def execute(approval, package, payloads):
        import sys
        import modal
        sys.path.insert(0, '/opt/preparatory-build')
        from local_integration import expanded_run as run
        claims = modal.Dict.from_name('orgsci-revised-intervention-100usd-one-use', create_if_missing=True)
        volume = modal.Volume.from_name(run.delivery.VOLUME, create_if_missing=False)
        return run.remote(approval, package, payloads,
            lambda key, value: claims.put(key, value, skip_if_exists=True), volume.commit)
    return modal, app, execute


def budget_check(budget):
    rows = budget['planned_reservations']; other = budget['new_runs']
    amounts = [row['maximum_usd'] for row in rows] + [row['reserved_usd'] for row in other]
    ids = [row['run_id'] for row in rows + other]
    if (budget['aggregate_limit'] != 100 or len(ids) != len(set(ids))
            or any(type(value) not in (int, float) or not math.isfinite(value) or value <= 0 for value in amounts)
            or sum(amounts) > 100 or budget['unreserved_usd'] != 100 - sum(amounts)
            or not any(row['run_id'] == RUN_ID and row['maximum_usd'] == 4 and row['status'] == 'NOT_SUBMITTED' for row in rows)):
        raise PermissionError('No unused A10 reservation within the aggregate US$100 cap.')


def launch():
    request, approval, package, payloads = load()
    budget_check(read(BUDGET)); require_a09_verified()
    directory = DIRECTORY / 'launch'; directory.mkdir(exist_ok=False)
    save_new(directory / 'submission_claim.json', {'run_id': RUN_ID, 'request_sha256': identity(request),
        'transport_sha256': identity(package), 'reserved_usd': 4.0, 'automatic_retry': False})
    try:
        modal, app, function = driver(package, payloads)
        with modal.enable_output(), app.run(detach=True):
            call = function.spawn(approval, package, payloads)
            result = {'artifact_type': 'PACKAGE_QUALIFICATION_DETACHED_LAUNCH', 'run_id': RUN_ID,
                'modal_app_id': app.app_id, 'modal_function_call_id': call.object_id,
                'transport_sha256': identity(package), 'status': 'SUBMITTED_NOT_VERIFIED'}
            if not result['modal_app_id'] or not result['modal_function_call_id']: raise RuntimeError('No saved call identity; never resubmit.')
            save_new(directory / 'launch.json', result)
            return result
    except BaseException as error:
        save_new(directory / 'submission_error.json', {'status': 'ERROR_OR_INDETERMINATE_NO_RETRY',
            'error_type': type(error).__name__, 'error': str(error)})
        raise


if __name__ == '__main__':
    action = sys.argv[1]
    if action in {'launch', 'retrieve'}:
        sys.path.append(str(ROOT.parent / 'model-trace-observatory/.venv/lib/python3.12/site-packages'))
    if action == 'prepare': result = prepare()
    elif action == 'check':
        request, _, _, payloads = load(); result = {'status': 'A10_SOURCE_CHECK_PASS', 'files': len(payloads), 'request_sha256': identity(request)}
    elif action == 'launch': result = launch()
    elif action == 'retrieve': result = delivery.retrieve(DIRECTORY / 'launch')
    elif action == 'audit':
        from .expanded_audit import audit
        result = audit()
    else: raise ValueError('Unknown action; no execution occurs implicitly.')
    print(json.dumps(result), flush=True)
