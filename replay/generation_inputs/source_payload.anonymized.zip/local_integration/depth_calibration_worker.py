"""Prepared A06 calibration entry; no provider or launch action lives here.

Requires an exact one-use request bound to independently verified A06 construction.
The original baseline gate, 41 conditions, scorer and selector are retained.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time

from . import depth_worker, headroom_worker
from .construction_program import ROOT, phase_plan, calibration_arms
from .depth_diagnostics import typed_decision_parser
from .calibration_diagnostics import calibration_diagnostic_connection
from .package_qualification import validate_plan
from .preparatory_phases import identity, save_new
from .qualification_worker import load_admitted_model
from .reused_model import SequentialModelSession, ReusedInspectGenerator

RUN_ID = 'negotiation-depth-audit-2026-10-31-A06-calibration'
CONSTRUCTION_REQUEST = '60b01990c9ee2f88e61c3a5511f1ce3dd9ae0f9bd8b2a651cf249dbbc1e085d9'
REUSE_POLICY = 'same_admitted_weights_new_pipeline_and_dynamic_cache_per_trial'
CONSTRUCTION_TRANSPORT = '89d694c3eef1312b6a3fb2f3ef7dce58a81944d877d1a85e485aed4b7a18a215'


def check_evidence(request, files):
    """Bind the transported vectors to the independently checked parent bytes."""
    for name, key in (('parent-audit.json', 'construction_audit_file_sha256'),
                      ('parent-manifest.json', 'construction_manifest_file_sha256'),
                      ('parent-directions.json', 'direction_manifest_file_sha256')):
        if hashlib.sha256(files[name]).hexdigest() != request[key]:
            raise ValueError('Parent evidence bytes changed: ' + name)
    audit = json.loads(files['parent-audit.json'])
    manifest = json.loads(files['parent-manifest.json'])
    directions = json.loads(files['parent-directions.json'])
    if (audit != request['construction_audit'] or directions != request['verified_direction_manifest']
            or manifest['run_id'] != depth_worker.RUN_ID
            or manifest['transport_sha256'] != CONSTRUCTION_TRANSPORT
            or manifest['terminal']['request_sha256'] != CONSTRUCTION_REQUEST
            or manifest['terminal']['status'] != 'DEPTH_CONSTRUCTION_AND_MECHANICS_COMPLETE'
            or manifest['terminal']['process']['returncode'] != 0
            or manifest['terminal']['process'].get('timed_out') is not False):
        raise ValueError('Parent evidence is not the verified A06 outcome.')
    entries = {entry['path']: entry for entry in manifest['files']}
    if len(entries) != len(manifest['files']) or len(entries) != audit['returned_files_verified']:
        raise ValueError('The parent delivery inventory differs from its audit.')
    expected = entries['attempt/directions/directions.json']
    if (expected['sha256'] != request['direction_manifest_file_sha256']
            or expected['size_bytes'] != len(files['parent-directions.json'])):
        raise ValueError('Direction manifest is not the audited delivered file.')
    declared = {}
    for values in request['directions'].values():
        for entry in values.values():
            name = entry['path']
            if Path(name).name != name or name in declared:
                raise ValueError('Unsafe or duplicate direction name.')
            declared[name] = entry
            original = entries['attempt/directions/' + name]
            raw = files['directions/' + name]
            if (len(raw) != entry['size_bytes'] or original['size_bytes'] != len(raw)
                    or original['sha256'] != entry['sha256']
                    or hashlib.sha256(raw).hexdigest() != entry['sha256']):
                raise ValueError('Direction bytes are not the audited parent file: ' + name)
    if len(declared) != 10 or {n for n in files if n.startswith('directions/')} != {'directions/' + n for n in declared}:
        raise ValueError('The ten direction/control files must be complete and exact.')


def check_request(request, approval, *, evidence_files=None):
    parent = request['construction_request']
    if identity(parent) != CONSTRUCTION_REQUEST:
        raise ValueError('Only the admitted A06 construction may supply these directions.')
    depth_worker.check_request(parent, request['construction_approval'])
    if (request['run_id'] != RUN_ID or request['stage'] != 'calibration'
            or request['program'] != parent['program']
            or request['maximum_generation_calls'] != 41 or request['maximum_wall_seconds'] != 7200
            or request['model_reuse_policy'] != REUSE_POLICY):
        raise ValueError('The middle-depth program, 41-condition allowance or reuse policy changed.')
    required = {'owner_authorized': True, 'paid_phase_authorized': True,
        'request_sha256': identity(request), 'maximum_generation_calls': 41,
        'maximum_wall_seconds': 7200, 'maximum_reserved_usd': 12.0,
        'aggregate_limit_usd': 100.0, 'automatic_retry': False, 'deployment_authorized': False}
    if any(approval.get(k) != v for k, v in required.items()) or not approval.get('owner_authorization_reference'):
        raise PermissionError('Exact calibration authority and cost reservation are required.')
    audit = request['construction_audit']
    if (audit['status'] != 'A06_CONSTRUCTION_AND_MECHANICS_VERIFIED'
            or audit['request_sha256'] != CONSTRUCTION_REQUEST
            or not audit['fresh_process_restoration_exact'] or audit['behavioral_result']
            or audit['protected_files_unchanged'] != 1530
            or not all(audit['construction'][key] for key in (
                'authored_inputs_verified', 'capture_arithmetic_verified',
                'raw_and_normalized_directions_verified', 'controls_replayed_exactly'))
            or audit['construction']['pair_count'] != 4 or audit['construction']['capture_forwards'] != 8):
        raise PermissionError('Independently verified A06 construction and mechanics are required.')
    if identity(audit) != request['construction_audit_object_sha256']:
        raise ValueError('The independent construction audit changed.')
    if request['directions'] != request['verified_direction_manifest']['directions']:
        raise ValueError('Direction manifest substitution.')
    if request['verified_direction_manifest']['program_sha256'] != identity(request['program']):
        raise ValueError('Directions belong to another program.')
    plan = phase_plan(request['program'], 'calibration', calibration_arms(request['program'], request['directions']))
    if identity(plan) != request['phase_plan_sha256'] or len(plan['trials']) != 41:
        raise ValueError('The exact calibration plan differs.')
    if evidence_files is None:
        names = ['parent-audit.json', 'parent-manifest.json', 'parent-directions.json']
        names += ['directions/' + entry['path'] for values in request['directions'].values() for entry in values.values()]
        evidence_files = {name: (ROOT / 'request' / name).read_bytes() for name in names}
    check_evidence(request, evidence_files)
    return validate_plan(request['program']['qualification_plan'])


def run(request, approval, snapshot, destination):
    contract = check_request(request, approval)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination / 'started.json', {'request': request, 'approval': approval})
    started = time.monotonic()
    session = None
    try:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
        plan = phase_plan(request['program'], 'calibration', calibration_arms(request['program'], request['directions']))
        admitted = []
        for trial in plan['trials']:
            ids = tokenizer.apply_chat_template(trial['messages'], tokenize=True, return_dict=False,
                add_generation_prompt=True, enable_thinking=False)
            admitted.append({'trial_id': trial['trial_id'], 'input_token_ids': ids,
                'sha256': identity(ids), 'within_limit': len(ids) <= contract.max_input_tokens})
        save_new(destination / 'input_admission.json', admitted)
        if not all(row['within_limit'] for row in admitted):
            raise ValueError('An input exceeds the unchanged allowance; no truncation or model loading.')

        def loader(directory):
            model, tokenizer, unused = load_admitted_model(request['program']['qualification_plan'], snapshot, directory)
            del unused
            return model, tokenizer

        session = SequentialModelSession(destination / 'shared_model', loader,
            expected_weights_sha256=request['program']['qualification_plan']['model_weight_entries_sha256'],
            contract=contract)

        def connection(plan, supplied_contract, *, model_factory, direction_loader):
            if identity(asdict(supplied_contract)) != identity(asdict(contract)) or model_factory != session.acquire:
                raise ValueError('The calibration connection differs from the admitted session.')
            return ReusedInspectGenerator(plan, contract, model_session=session, direction_loader=direction_loader)

        with calibration_diagnostic_connection(), typed_decision_parser():
            result = headroom_worker.run_calibration(request, approval['owner_authorization_reference'],
                destination, session.acquire, generator_class=connection)
        if (session.failed or session.loads != 1 or session.generation_attempts != result['generation_calls']
                or session.completed_trials != result['generation_calls']):
            raise RuntimeError('Session counts do not match the completed phase.')
    except BaseException as error:
        result = {'status': 'FAILED_NO_RETRY', 'error_type': type(error).__name__, 'error': str(error)}
    result.update(run_id=request['run_id'], request_sha256=identity(request),
        elapsed_seconds=time.monotonic()-started,
        session=None if session is None else session.summary(),
        construction_repeated=False, automatic_retry=False, held_out_result=False, deployment=False)
    save_new(destination / 'result.json', result)
    print(json.dumps(result), flush=True)
    if result['status'] == 'FAILED_NO_RETRY':
        raise SystemExit(1)


if __name__ == '__main__':
    request_path, approval_path, snapshot, destination = map(Path, sys.argv[1:])
    run(json.loads(request_path.read_text()), json.loads(approval_path.read_text()), snapshot, destination)
