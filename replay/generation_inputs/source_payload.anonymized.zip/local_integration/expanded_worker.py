"""Separately admitted capture-only worker; no provider or automatic next phase."""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from . import expanded_references as references
from .expanded_capture import capture, sha
from .direction_construction import ConstructionSpec, input_hash
from .generation_sensitivity import verify_tokenizer_files
from .package_qualification import validate_plan
from .preparatory_phases import identity, save_new
from .qualification_worker import load_admitted_model, weight_fingerprint

ROOT = Path(__file__).resolve().parents[1]
RUN_ID = 'negotiation-expanded-2026-10-31-A10-construction'
PARENT_AUDIT = 'records/revised_intervention_2026-10-31_A06/construction/terminal_audit.json'
PARENT_AUDIT_SHA256 = '61c013c81bdf5413febf7c89671f678bd94341f8d8b89077476e6845023bbe85'
PARENT_MANIFEST = 'records/revised_intervention_2026-10-31_A06/construction/transport.json'
PARENT_MANIFEST_SHA256 = '89d694c3eef1312b6a3fb2f3ef7dce58a81944d877d1a85e485aed4b7a18a215'
LIMITS = {'maximum_generation_calls': 0, 'maximum_capture_forwards': references.FORWARD_COUNT,
          'maximum_model_loads': 1, 'maximum_wall_seconds': 1200,
          'maximum_reserved_usd': 4.0, 'aggregate_limit_usd': 100.0}
EXPECTED_WIDTH = 4096


def expected_program(root):
    raw = (Path(root) / references.SOURCE).read_bytes()
    if hashlib.sha256(raw).hexdigest() != references.SOURCE_SHA256:
        raise ValueError('The qualified original construction request changed.')
    parent = json.loads(raw)
    keys = ('qualification_plan', 'sites', 'pooling', 'accumulation_dtype', 'insertion_dtype',
            'stored_dtype', 'position_policy', 'family_partitions', 'random_controls', 'permuted_control')
    result = {key: deepcopy(parent['program'][key]) for key in keys}
    result['permuted_control']['swapped_pair_indices'] = list(range(1, references.PAIR_COUNT, 2))
    result['permuted_control']['method'] = 'Swap labels at odd zero-based indices, three of six pairs in each original family; average signed pair differences and match raw target L2 norm.'
    result.update(program_id=RUN_ID, cases={'construction_fit': references.load_fit_cases(root)},
                  construction_rule=deepcopy(references.RULE), automatic_retry=False,
                  calibration_authorized=False, development_authorized=False,
                  untouched_authorized=False, deployment_authorized=False)
    return result


def draft_request(root=ROOT):
    program = expected_program(root)
    return {'run_id': RUN_ID, 'stage': 'expanded_construction', 'program': program,
            'construction_source': {'references': references.build(program['cases']['construction_fit'])},
            'limits': dict(LIMITS), 'qualified_parent_request_sha256': references.SOURCE_SHA256,
            'qualified_parent_audit_sha256': PARENT_AUDIT_SHA256,
            'qualified_parent_transport_identity': PARENT_MANIFEST_SHA256,
            'changed': ['decision_aligned_authored_contrast', 'construction_fit_standing_contexts_4_to_24',
                        'prospectively_fixed_balanced_permuted_labels_for_24_pairs'],
            'reuses_previous_generation_qualification': True, 'automatic_retry': False,
            'calibration_authorized': False, 'behavioral_result': False}


def check_request(request, approval, root=ROOT):
    if request != draft_request(root):
        raise ValueError('Only the exact separately specified construction is admitted.')
    audit_raw = (Path(root) / PARENT_AUDIT).read_bytes()
    if hashlib.sha256(audit_raw).hexdigest() != PARENT_AUDIT_SHA256:
        raise ValueError('Original independent qualification audit changed.')
    audit = json.loads(audit_raw)
    if (audit['status'] != 'A06_CONSTRUCTION_AND_MECHANICS_VERIFIED'
            or audit['capture']['direct_sites_exact'] is not True
            or audit['fresh_process_restoration_exact'] is not True):
        raise ValueError('The unchanged capture sites and runtime are not qualified.')
    manifest = json.loads((Path(root) / PARENT_MANIFEST).read_text())
    if identity(manifest) != PARENT_MANIFEST_SHA256:
        raise ValueError('The qualified original transport identity changed.')
    for entry in manifest['files']:
        if entry['path'].startswith('request/'):
            continue
        path = Path(root) / entry['path']
        if not path.resolve().is_relative_to(Path(root).resolve()) or path.is_symlink() or sha(path) != entry['sha256']:
            raise ValueError('A qualified construction source changed: ' + entry['path'])
    required = {'owner_authorized': True, 'paid_phase_authorized': True,
                'request_sha256': identity(request), **LIMITS, 'automatic_retry': False,
                'deployment_authorized': False, 'calibration_authorized': False}
    if any(approval.get(key) != value for key, value in required.items()):
        raise PermissionError('A separate one-use request and reservation are required.')
    return validate_plan(request['program']['qualification_plan'])


def run(request, approval, snapshot, destination, *, root=ROOT):
    """One load, 48 forwards, no generated response; stop on any failure."""
    contract = check_request(request, approval, root)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination / 'started.json', {'run_id': RUN_ID, 'request': request,
             'approval': approval, 'request_sha256': identity(request), 'process_id': os.getpid()})
    started = time.monotonic()
    loads = 0
    counts = {}
    capture_entered = False
    try:
        program = request['program']
        qualification = program['qualification_plan']
        hashes = verify_tokenizer_files(qualification, snapshot, root)
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True,
                                                  trust_remote_code=False, use_fast=True)
        pairs, tokens = references.token_inputs(program['cases']['construction_fit'],
            request['construction_source']['references'], tokenizer, asdict(contract))
        save_new(destination / 'tokenizer_check.json', {'files': hashes, 'before_model_load': True})
        save_new(destination / 'authored_references.json', request['construction_source']['references'])
        save_new(destination / 'teacher_forcing_inputs.json', tokens)
        location = destination / 'capture_model'
        location.mkdir()
        if time.monotonic() - started >= LIMITS['maximum_wall_seconds']:
            raise TimeoutError('Allowance expired before model loading.')
        loads += 1
        model, loaded_tokenizer, _ = load_admitted_model(qualification, snapshot, location)
        loaded_pairs, loaded_tokens = references.token_inputs(program['cases']['construction_fit'],
            request['construction_source']['references'], loaded_tokenizer, asdict(contract))
        if loaded_pairs != pairs or loaded_tokens != tokens:
            raise ValueError('Loaded tokenizer differs from the pre-load attestation.')
        width = model.get_input_embeddings().weight.shape[1]
        if width != EXPECTED_WIDTH:
            raise ValueError('The admitted research-model hidden width changed.')
        spec = ConstructionSpec(contract.model_id, contract.model_revision, contract.model_type,
            tuple(tuple(site) for site in program['sites']), width, tuple(p.pair_id for p in pairs), input_hash(pairs),
            tuple(family for family, partition in program['family_partitions'].items() if partition != 'construction_fit'),
            program['pooling'], program['accumulation_dtype'], program['insertion_dtype'],
            contract.max_input_tokens + contract.max_new_tokens, contract.synthetic_test)
        remaining = LIMITS['maximum_wall_seconds'] - (time.monotonic() - started)
        capture_entered = True
        result = capture(model, pairs, spec, program, destination / 'capture', maximum_seconds=remaining,
                         execution_counts=counts)
        weights_after = weight_fingerprint(model)
        save_new(destination / 'weights_after.json', weights_after)
        if weights_after['entries_sha256'] != qualification['model_weight_entries_sha256']:
            raise ValueError('Model parameters or buffers changed during construction.')
        result['weights_unchanged'] = True
        if time.monotonic() - started > LIMITS['maximum_wall_seconds']:
            raise TimeoutError('The capture exceeded its total wall-time allowance.')
        result.update(status='EXPANDED_CONSTRUCTION_COMPLETE', model_load_attempts=loads)
    except BaseException as error:
        result = {'status': 'FAILED_NO_RETRY', 'error_type': type(error).__name__, 'error': str(error),
                  'model_load_attempts': loads, 'generation_calls': 0,
                  'calibration_started': False, 'candidate_selected': False, 'behavioral_result': False}
        result.update(capture_entered=capture_entered,
            attempted_forwards=counts.get('attempted_forwards', 0 if not capture_entered else None),
            capture_forwards=counts.get('completed_forwards', 0 if not capture_entered else None),
            retained_captures=counts.get('retained_captures', 0 if not capture_entered else None),
            counts_source='in_memory_forward_counter' if counts else 'capture_not_started_or_not_initialized')
        receipt = destination / 'capture/selected_states/receipt.json'
        if receipt.is_file():
            try:
                raw = receipt.read_bytes()
                result['capture_receipt_sha256'] = hashlib.sha256(raw).hexdigest()
                result['capture_receipt'] = json.loads(raw)
            except (OSError, ValueError, UnicodeError) as receipt_error:
                result['capture_receipt_parse_error'] = str(receipt_error)
        if error.__context__ is not None:
            result['preceding_error'] = {'type': type(error.__context__).__name__, 'message': str(error.__context__)}
    result.update(run_id=RUN_ID, request_sha256=identity(request),
                  elapsed_seconds=time.monotonic() - started, automatic_retry=False)
    save_new(destination / 'result.json', result)
    if result['status'] == 'FAILED_NO_RETRY':
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    request_path, approval_path, snapshot, destination = map(Path, sys.argv[1:])
    print(json.dumps(run(json.loads(request_path.read_text()), json.loads(approval_path.read_text()),
                         snapshot, destination)), flush=True)
