"""Convert preserved construction-fit generations into explicit paired tokens."""
from .direction_construction import ConstructionPair, ResponseTokens, input_hash
from .preparatory_phases import checked_scores, identity


def prepare_pairs(plan, cases, result, tokenizer, *, position_policy):
    """No forward pass. Neutral teacher-forced prefix is shared within each pair.

    Position policy must be selected before fitting. Neither supported policy is
    selected for the real study by this module or its synthetic tests.
    """
    if plan["phase"] != "construction_fit" or position_policy not in {"all_generated", "exclude_special_tokens"}:
        raise ValueError("Use construction-fit records and an explicit response-position policy.")
    scores = checked_scores(plan, cases, result)
    if result["failure"] is not None or any(score is None or not score["valid"] for score in scores.values()):
        raise ValueError("Preserve failed/invalid construction records; do not silently fit a selected subset.")
    if not isinstance(tokenizer.chat_template, str) or not tokenizer.chat_template:
        raise ValueError("Missing tokenizer template.")
    import hashlib
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != plan["generation_contract"]["chat_template_sha256"]:
        raise ValueError("Teacher-forcing tokenizer template differs from generation.")
    records = {(row["case_id"], row["kind"]): row for row in result["records"]}
    pairs = []
    special = set(tokenizer.all_special_ids)
    for case in cases:
        messages = [{"role": "system", "content": case["system_text"]}, {"role": "user", "content": case["user_text"]}]
        prefix = tuple(tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False, add_generation_prompt=True, enable_thinking=False))
        responses = []
        for kind in ("mutual_benefit", "own_surplus"):
            row = records[(case["case_id"], kind)]
            ids = tuple(row["source"]["generated_token_ids"])
            if not ids or any(type(t) is not int or t < 0 for t in ids):
                raise ValueError("Exact nonempty generated token IDs are required.")
            if tokenizer.decode(ids, skip_special_tokens=True) != row["raw_response"]:
                raise ValueError("Stored construction text and generated token IDs disagree.")
            selected = tuple(i for i, token in enumerate(ids) if position_policy == "all_generated" or token not in special)
            if not selected:
                raise ValueError("The response-position rule selects no tokens.")
            responses.append(ResponseTokens(prefix, ids, selected))
        pairs.append(ConstructionPair(case["case_id"], case["family_id"], *responses))
    values = tuple(pairs)
    return values, {"artifact_type": "CONSTRUCTION_TOKEN_INPUTS", "plan_sha256": identity(plan),
        "result_sha256": identity(result), "position_policy": position_policy,
        "construction_sha256": input_hash(values), "pair_count": len(values),
        "teacher_prefix": "Original case instructions without either construction-policy addition.",
        "generation_calls": 0, "capture_forwards": 0, "fit_authorized": False}
