"""Build A08 generation-only diagnostic inputs and summaries, without execution.

This module has no model loader, provider, worker, launcher or selector.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from .preparatory_phases import identity
from .target_alignment_checks import admitted_bank, INPUTS_SHA256, RENDERINGS

RUN_ID = 'negotiation-generation-sensitivity-2026-10-31-A08'
LIMITS = {'study_generations': 34, 'main_generations': 36, 'fresh_generations': 2,
          'maximum_generation_attempts': 38, 'maximum_model_load_attempts': 2,
          'maximum_wall_seconds': 3600, 'maximum_reserved_usd': 8.0,
          'aggregate_limit_usd': 100.0, 'automatic_retry': False}
PACKAGE_VERSIONS = {'steerability': '0.5.7', 'inspect-ai': '0.3.286'}


def snapshot_attestation(qualification, root):
    artifact = qualification['artifacts']['snapshot_attestation']
    path = Path(root) / artifact['path']
    if path.is_symlink() or not path.resolve().is_relative_to(Path(root).resolve()):
        raise ValueError('Unsafe snapshot attestation path.')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != artifact['sha256']:
        raise ValueError('Snapshot attestation changed.')
    value = json.loads(raw)
    contract = qualification['generation_contract']
    if (value['model_id'], value['model_revision']) != (contract['model_id'], contract['model_revision']):
        raise ValueError('Snapshot model identity differs.')
    return value


def verify_tokenizer_files(qualification, snapshot, root):
    """Bind the tokenizer before use, without reading or loading model weights."""
    attestation = snapshot_attestation(qualification, root)
    snapshot = Path(snapshot)
    if not snapshot.is_dir() or snapshot.is_symlink():
        raise ValueError('Missing or symlinked tokenizer snapshot.')
    entries = {entry['path']: entry for entry in attestation['files']}
    actual = {p.relative_to(snapshot).as_posix() for p in snapshot.rglob('*') if p.is_file() or p.is_symlink()}
    if len(entries) != len(attestation['files']) or actual != set(entries):
        raise ValueError('Snapshot filenames differ from the attested set.')
    checked = {}
    for name in ('tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja', 'config.json', 'merges.txt', 'vocab.json'):
        path, entry = snapshot / name, entries[name]
        if (path.is_symlink() or path.stat().st_size != entry['size_bytes']
                or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']):
            raise ValueError('Tokenizer file differs: ' + name)
        checked[name] = entry['sha256']
    return checked


def build_plan(raw_bank):
    bank = admitted_bank(raw_bank)
    unique = {}
    for rendering in RENDERINGS:
        case = next(r['case'] for r in bank['renderings'] if r['rendering_id'] == rendering)
        for condition in bank['conditions']:
            members = [t for t in bank['trials'] if t['rendering_id'] == rendering
                       and t['condition_id'] == condition['arm_id']]
            if len(members) != 4 or {t['response_id'] for t in members} != set('ATCR'):
                raise ValueError('Each generation requires the four exact source continuations.')
            source = members[0]
            fields = ('messages', 'messages_sha256', 'prefix_token_ids', 'kind', 'edit', 'case_id', 'family_id')
            if any(any(t[key] != source[key] for key in fields) for t in members):
                raise ValueError('Source continuations do not share an identical generation input.')
            if identity(source['messages']) != source['messages_sha256']:
                raise ValueError('Message identity differs.')
            trial = {key: deepcopy(source[key]) for key in fields}
            trial.update(trial_id='study--' + rendering + '--' + condition['arm_id'],
                         rendering_id=rendering, arm_id=condition['arm_id'], role='study',
                         case_content_sha256=case['case_content_sha256'], output_contract_version=2)
            unique[rendering, condition['arm_id']] = trial
    # Baseline and zero-edit checks precede the remaining fixed study bank.
    ordered = [unique[r, 'baseline'] for r in RENDERINGS]
    ordered += [unique[r, name] for r in RENDERINGS for name in ('sham-14-0', 'sham-15-0')]
    ordered += [unique[r, c['arm_id']] for r in RENDERINGS for c in bank['conditions']
                if c['arm_id'] not in ('baseline', 'sham-14-0', 'sham-15-0')]
    if len(ordered) != 34 or len({t['trial_id'] for t in ordered}) != 34:
        raise ValueError('Incomplete or duplicate study bank.')
    after, fresh = [], []
    for rendering in RENDERINGS:
        for role, destination in (('restoration_after', after), ('restoration_fresh', fresh)):
            trial = deepcopy(unique[rendering, 'baseline'])
            trial.update(trial_id=role + '--' + rendering + '--baseline', role=role)
            destination.append(trial)
    return {'artifact_type': 'FIXED_GENERATION_DIAGNOSTIC_PLAN', 'schema_version': 1,
            'run_id': RUN_ID, 'phase': 'generation_diagnostic', 'fixture_only': False,
            'source_bank_sha256': INPUTS_SHA256, 'generation_contract': deepcopy(bank['tokenizer_contract']),
            'model_id': bank['model_id'], 'model_revision': bank['model_revision'],
            'renderings': [{k: deepcopy(r[k]) for k in ('rendering_id', 'case', 'option_id_mapping', 'source_case_id')}
                           for r in bank['renderings']],
            'conditions': deepcopy(bank['conditions']), 'trials': ordered + after,
            'fresh_trials': fresh, 'limits': dict(LIMITS), 'case_families': 1,
            'candidate_selection': False, 'held_out_result': False,
            'source_partitions_unchanged': True, 'reference_responses_supplied_to_model': False}


def validate_plan(plan, raw_bank):
    if plan != build_plan(raw_bank):
        raise ValueError('The fixed diagnostic plan, order, inputs or limits changed.')


def fresh_plan(plan):
    result = deepcopy(plan)
    result['phase'] = 'generation_diagnostic_restoration'
    result['trials'] = deepcopy(plan['fresh_trials'])
    return result


def verify_token_inputs(plan, tokenizer):
    checks = []
    contract = plan['generation_contract']
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != contract['chat_template_sha256']:
        raise ValueError('The admitted chat template differs.')
    for trial in plan['trials'] + plan['fresh_trials']:
        ids = tokenizer.apply_chat_template(trial['messages'], tokenize=True, return_dict=False,
                                           add_generation_prompt=True, enable_thinking=False)
        if ids != trial['prefix_token_ids'] or not 0 < len(ids) <= contract['max_input_tokens']:
            raise ValueError('Generation input differs or exceeds the unchanged limit.')
        checks.append({'trial_id': trial['trial_id'], 'input_token_ids': ids, 'sha256': identity(ids)})
    return checks


def canonical_package(plan, rendering_id, package):
    if package is None:
        return None
    rendering = next(r for r in plan['renderings'] if r['rendering_id'] == rendering_id)
    mapping = rendering['option_id_mapping']
    if mapping is None:
        return deepcopy(package)
    return {issue: {alias: original for original, alias in mapping[issue].items()}[value]
            for issue, value in package.items()}


def summarize(plan, records):
    """Descriptive only: no candidate choice, significance test or criterion reset."""
    study = [row for row in records if row['role'] == 'study']
    expected = [trial for trial in plan['trials'] if trial['role'] == 'study']
    if [r['trial_id'] for r in study] != [t['trial_id'] for t in expected]:
        raise ValueError('All 34 study outcomes, including invalid answers, are required.')
    by_id = {r['trial_id']: r for r in study}
    rows = []
    for trial in expected:
        row = by_id[trial['trial_id']]
        score = row['score']
        baseline = by_id['study--' + trial['rendering_id'] + '--baseline']['score']
        comparable = bool(score['valid'] and baseline['valid'])
        fields = ('proposed_self_payoff', 'proposed_counterpart_payoff', 'proposed_joint_gain',
                  'agreement_adjusted_joint_gain')
        deltas = {key: score[key] - baseline[key] if comparable else None for key in fields}
        changed = ((score['decision'] != baseline['decision'] or score['package'] != baseline['package'])
                   if comparable else None)
        rows.append({'trial_id': trial['trial_id'], 'rendering_id': trial['rendering_id'],
                     'condition_id': trial['arm_id'], 'kind': trial['kind'], 'edit': trial['edit'],
                     'valid': score['valid'], 'decision_or_package_changed': changed,
                     'canonical_proposed_package': canonical_package(plan, trial['rendering_id'], score.get('package')),
                     'canonical_effective_package': canonical_package(plan, trial['rendering_id'], score.get('effective_package')),
                     'agreement_or_effective_package_changed': (
                         score['agreement'] != baseline['agreement'] or score['effective_package'] != baseline['effective_package']
                     ) if comparable else None,
                     'score': deepcopy(score), 'delta_from_same_rendering_baseline': deltas})
    return {'status': 'FIXED_GENERATION_DIAGNOSTIC_SUMMARY', 'run_id': plan['run_id'],
            'plan_sha256': identity(plan), 'rows': rows, 'case_families': 1, 'renderings': 2,
            'pool_renderings': False, 'candidate_selection': False, 'held_out_result': False,
            'interpretation': 'Local generated-response and identifier-encoding sensitivity, not general cooperation validation or a revised calibration result.',
            'automatic_followup': False}
