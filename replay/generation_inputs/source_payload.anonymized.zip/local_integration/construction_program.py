"""Prospective construction/calibration specification and additional fit cases.

Preparing this specification does not load a model or contact a provider.
The original case bank and its partitions are never rewritten.
"""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import random
import sys

from .calibration_selection import RULE
from .preparatory_phases import identity, prepare_plan, save_new
from submission_analysis.analyze import scorer

ROOT = Path(__file__).resolve().parents[1]
A03 = ROOT / "records/package_route_qualification_2026-10-30_A03"
MATERIALS = ROOT / "negotiation-steering/study/materials"
POLICIES = [
    {"arm_id": "mutual-benefit", "kind": "mutual_benefit", "prompt_suffix":
     "Seek a mutually beneficial agreement. Use the supplier's stated priorities to look for trades that help both parties, while protecting your reservation value. Choose the package, not merely cooperative wording. Keep the required JSON format and use at most one brief sentence for the rationale.", "edit": None},
    {"arm_id": "own-surplus", "kind": "own_surplus", "prompt_suffix":
     "Prioritize your own surplus. Seek the highest own payoff available under the stated constraints, rather than accommodating the supplier's priorities. Choose the package, not merely assertive wording. Keep the required JSON format and use at most one brief sentence for the rationale.", "edit": None},
]
PROMPTS = [
    "Seek a mutually beneficial agreement while protecting your own payoff. Use the supplier's stated priorities to look for useful trades. Keep the required JSON format.",
    "Give strong priority to finding mutually beneficial trades. Consider the supplier's stated priorities across delivery and warranty before choosing a package, while protecting your own payoff. Change the offered terms when this helps, not just the wording. Keep the required JSON format.",
]
SITES = ((2, "model.language_model.layers.2"), (3, "model.language_model.layers.3"))
STRENGTHS = (0.5, 1.0, 2.0)

def load_cases(name):
    return [json.loads(line) for line in (MATERIALS / name).read_text().splitlines() if line.strip()]

def additional_cases():
    sys.path.insert(0, str(ROOT / "negotiation-steering"))
    from study.author_cases import base_options, make_case
    rows = []
    changes = [
        ("cf-pumps", "Buying industrial water pumps with installation delivery and service terms.",
         [(8, 8), (24, 20), (38, 1)], [(4, 29), (17, 17), (29, 3)],
         (34, 30), (24, 20), ["Planned delivery slots", "Limited warranty exposure"]),
        ("cf-kitchen", "Buying commercial kitchen equipment for a hotel refurbishment.",
         [(9, 10), (27, 22), (36, 2)], [(6, 31), (20, 19), (28, 4)],
         (38, 32), (28, 22), ["Predictable installation timing", "Avoiding extended service obligations"]),
        ("cf-scanners", "Buying warehouse barcode scanners with delivery and maintenance terms.",
         [(11, 8), (29, 21), (40, 3)], [(7, 32), (19, 20), (31, 4)],
         (40, 34), (30, 24), ["Scheduled rather than urgent delivery", "Lower long-term service exposure"]),
    ]
    for family, scenario, delivery, warranty, reservation, disagreement, priorities in changes:
        options = base_options()
        for issue, values in (("delivery", delivery), ("warranty", warranty)):
            options[issue] = [(old[0], old[1], *value) for old, value in zip(options[issue], values)]
        rows.append(make_case(family + "-base", family, "construction_fit", scenario, options,
            reservation=reservation, disagreement=disagreement,
            last_package={"price": "price_90", "delivery": "standard", "warranty": "annual", "payment": "net_30"},
            priorities=priorities, constraints=[{"constraint_id": "immediate-net60-unavailable",
                "description": "Immediate delivery cannot be combined with net 60 payment.",
                "forbid": {"delivery": "immediate", "payment": "net_60"}}]))
    return rows

def specification():
    fit = load_cases("construction_fit.jsonl") + additional_cases()
    check = load_cases("construction_check.jsonl")
    calibration = load_cases("calibration.jsonl")
    if len(fit) != 4 or len(check) != 1 or len(calibration) != 1:
        raise ValueError("The approved case counts differ.")
    scoring = scorer()
    all_cases = fit + check + calibration
    for case in all_cases:
        scoring.validate_case(case)
    families = scoring.validate_family_partitions(all_cases)
    swapped = sorted(random.Random(20261030).sample(range(4), 2))
    return {"artifact_type": "CONSTRUCTION_CALIBRATION_PROGRAM", "schema_version": 1,
        "program_id": "negotiation-construction-calibration-2026-10-30-A01",
        "cases": {"construction_fit": fit, "construction_check": check, "calibration": calibration},
        "family_partitions": {c["family_id"]: c["partition"] for c in all_cases},
        "policies": deepcopy(POLICIES), "prompts": list(PROMPTS),
        "sites": [list(site) for site in SITES], "strengths": list(STRENGTHS),
        "position_policy": "exclude_special_tokens", "pooling": "response_mean",
        "direction_form": "raw", "accumulation_dtype": "float32", "stored_dtype": "float32",
        "insertion_dtype": "bfloat16", "direction_sign": "mutual_benefit_minus_own_surplus",
        "random_controls": {"algorithm": "numpy.Generator(PCG64).standard_normal float64, cast float32, match raw target L2 norm",
            "seeds": [202610301, 202610302, 202610303], "per_site_seed": "base_seed + 1000 * layer_index"},
        "permuted_control": {"seed": 20261030, "swapped_pair_indices": swapped,
            "method": "Swap the positive and negative labels in exactly two of four pairs; average signed pair differences and match raw target L2 norm.",
            "degeneracy_rule": "Stop if zero, nonfinite, or absolute cosine with target is at least 0.999999; do not redraw."},
        "construction_check_rule": {"minimum_valid_pair_fraction": 1.0, "minimum_joint_gap": 0, "minimum_own_gap": 0},
        "selection_rule": deepcopy(RULE),
        "limits": {"construction_generation_calls": 10, "construction_capture_forwards": 8,
            "construction_wall_seconds": 1800, "calibration_generation_calls": 41, "calibration_wall_seconds": 7200},
        "stop_on_invalid_construction": True, "stop_on_invalid_calibration_baseline": True,
        "automatic_retry": False, "development_authorized": False, "untouched_authorized": False,
        "f4_authorized": False, "deployment_authorized": False,
        "original_case_files": {name: hashlib.sha256((MATERIALS / name).read_bytes()).hexdigest()
            for name in ("construction_fit.jsonl", "construction_check.jsonl", "calibration.jsonl")},
        "qualification_plan": json.loads((A03 / "plan.json").read_text()),
        "qualification_audit_sha256": hashlib.sha256((A03 / "terminal_audit.json").read_bytes()).hexdigest(),
        "qualification_audit_object_sha256": identity(json.loads((A03 / "terminal_audit.json").read_text())),
        "scope": "Construction and one-case calibration only. No held-out behavioral or generalization claim."}

def phase_plan(program, phase, arms=None):
    qualification = program["qualification_plan"]
    return prepare_plan(run_id=program["program_id"] + "-" + phase.replace("_", "-"), phase=phase,
        cases=program["cases"][phase], arms=arms or program["policies"],
        model_id=qualification["generation_contract"]["model_id"], model_revision=qualification["generation_contract"]["model_revision"],
        generation_contract=qualification["generation_contract"], family_partitions=program["family_partitions"],
        maximum_wall_seconds=program["limits"]["calibration_wall_seconds" if phase == "calibration" else "construction_wall_seconds"],
        fixture_only=False, qualification_receipt_sha256=program["qualification_audit_sha256"],
        construction_check_rule=program["construction_check_rule"] if phase == "construction_check" else None,
        selection_rule=program["selection_rule"] if phase == "calibration" else None,
        stop_on_invalid=phase != "calibration")

def phase_approval(plan, reference):
    return {"owner_authorized": True, "plan_sha256": identity(plan), "phase": plan["phase"],
        "maximum_generation_calls": plan["maximum_generation_calls"], "automatic_retry": False,
        "fixture_only": False, "deployment_authorized": False, "paid_phase_authorized": True,
        "owner_authorization_reference": reference}

def calibration_arms(program, directions):
    def edited(kind, layer, path, coefficient, direction_kind):
        strength = str(abs(coefficient)).replace(".", "p")
        return {"arm_id": f"{kind}-{layer}-{strength}", "kind": kind, "prompt_suffix": "",
            "edit": {"layer": layer, "module_path": path, "coefficient": coefficient,
                "direction_sha256": directions[direction_kind][str(layer)]["sha256"]}}
    arms = [{"arm_id": "baseline", "kind": "unchanged", "prompt_suffix": "", "edit": None}]
    arms += [{"arm_id": f"prompt-{i+1}", "kind": "prompt", "prompt_suffix": text, "edit": None}
        for i, text in enumerate(program["prompts"])]
    # Order is prospective: baseline, prompts, zero controls, then all candidates/diagnostics.
    arms += [edited("sham", layer, path, 0, "raw") for layer, path in program["sites"]]
    for kind in ("internal", "reverse", "random_1", "random_2", "random_3", "permuted"):
        for layer, path in program["sites"]:
            for strength in program["strengths"]:
                arms.append(edited(kind, layer, path, -strength if kind == "reverse" else strength,
                    "raw" if kind in {"internal", "reverse"} else kind))
    if len(arms) != program["limits"]["calibration_generation_calls"]:
        raise ValueError("Calibration count differs from the prospective allowance.")
    return arms
