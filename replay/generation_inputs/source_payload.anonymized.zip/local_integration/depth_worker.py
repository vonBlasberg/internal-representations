"""A06 construction and new-site mechanics, with no calibration auto-launch."""
from copy import deepcopy
from dataclasses import asdict
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from . import authored_worker, preparatory_worker
from .direction_construction import ConstructionSpec, construct_directions, input_hash, isolated_capture
from .depth_diagnostics import DiagnosticPipeline
from .package_qualification import compare, validate_plan, source_inventory
from .qualification_worker import check_artifacts, load_admitted_model
from .preparatory_phases import identity, save_new
from .research_pipeline import EditSpec, _tensor
from .reference_construction import validate_bundle
from worker.adapter_base import Site
from worker.generation import generate_with_receipts
from worker.receipts import tensor_sha256

RUN_ID = "negotiation-depth-audit-2026-10-31-A06-construction"
SITES = ((14, "model.language_model.layers.14"), (15, "model.language_model.layers.15"))
PARENT_REQUEST = "c4bdff5fa41e5385c6d9da0162ce16b123f84d4b8c12dc728643a73d4ab6bc33"


def check_request(request, approval):
    parent = request["parent_request"]
    if identity(parent) != PARENT_REQUEST:
        raise ValueError("A06 requires the exact completed A05 source.")
    expected = deepcopy(parent["program"])
    expected["program_id"] = "negotiation-depth-audit-2026-10-31-A06"
    expected["sites"] = [list(x) for x in SITES]
    if request["program"] != expected or request["run_id"] != RUN_ID:
        raise ValueError("Only the predeclared depth pair may change the scientific program.")
    if request.get("stage") != "construction" or request.get("maximum_generation_calls") != 8 or request.get("maximum_wall_seconds") != 1800:
        raise ValueError("A06 requires its declared construction stage and execution limits.")
    required = {"owner_authorized": True, "request_sha256": identity(request),
        "maximum_generation_calls": 8, "maximum_wall_seconds": 1800,
        "maximum_reserved_usd": 12.0, "aggregate_limit_usd": 100.0,
        "automatic_retry": False, "deployment_authorized": False}
    if any(approval.get(k) != v for k,v in required.items()):
        raise PermissionError("Exact A06 authority and limits are required.")
    if request["construction_source"] != parent["construction_source"]:
        raise ValueError("The authored pairs must remain unchanged in the depth test.")
    if expected["qualification_plan"]["source_sha256"] != source_inventory():
        raise ValueError("The qualified generation/construction sources changed.")
    qualified = parent["qualification_audit"]
    if identity(qualified) != expected["qualification_audit_object_sha256"] or qualified.get("mechanical_qualification_verified") is not True or qualified.get("worker_terminal_status") != "PASS":
        raise ValueError("The preserved research-model qualification has not passed.")
    if request["capture_checks"] != {"direct_capture_exact":True,"cache_relative_l2_max":0.02,"cache_cosine_min":0.999,"first_cached_response_tokens":7}:
        raise ValueError("Capture tolerances were changed.")
    validate_bundle(expected["cases"]["construction_fit"], request["construction_source"]["references"],
        expected_case_ids=[c["case_id"] for c in expected["cases"]["construction_fit"]])
    check_artifacts(expected["qualification_plan"])
    return validate_plan(expected["qualification_plan"])


def capture_checks(model, response, sites, thresholds, artifact_directory=None):
    """Compare the exact raw sites, then matched-position cached/full prefixes."""
    import torch
    from steerability.algorithms.core.internals.capture import capture_hidden
    device=model.get_input_embeddings().weight.device
    ids=torch.tensor([response.input_ids],device=device)
    with isolated_capture(model), torch.inference_mode():
        states,_=capture_hidden({"input_ids":ids,"attention_mask":torch.ones_like(ids)},
            model=model,batch_size=1,location="layer_output")
    expected={layer:states[layer].detach().cpu().clone() for layer,_ in sites}
    del states
    actual={}; handles=[]
    try:
        for layer,path in sites:
            def record(module,args,output,layer=layer):
                actual[layer]=_tensor(output).detach().cpu().clone()
            handles.append(model.get_submodule(path).register_forward_hook(record))
        with torch.inference_mode():
            full=model(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=False,return_dict=True)
        del full
    finally:
        for handle in handles:handle.remove()
    exact={str(layer):bool(torch.equal(expected[layer],actual[layer])) for layer,_ in sites}
    if not all(exact.values()):raise RuntimeError("Capture helper does not match passive raw-site recording.")
    tensor_record=None
    if artifact_directory is not None:
        path=artifact_directory/"direct_capture_states.pt"
        with path.open("xb") as stream:
            torch.save({**{f"capture_{k}":v for k,v in expected.items()},
                        **{f"passive_{k}":v for k,v in actual.items()}},stream)
        tensor_record={"path":path.name,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
            "shape_by_layer":{str(k):list(v.shape) for k,v in actual.items()}}
    cached={}; handles=[]
    try:
        with torch.inference_mode():
            prefix=model(input_ids=ids[:,:-1],attention_mask=torch.ones_like(ids[:,:-1]),use_cache=True,return_dict=True)
        for layer,path in sites:
            def record(module,args,output,layer=layer):cached[layer]=_tensor(output)[:,-1,:].detach().cpu().float()
            handles.append(model.get_submodule(path).register_forward_hook(record))
        with torch.inference_mode():
            end=model(input_ids=ids[:,-1:],attention_mask=torch.ones_like(ids),
                past_key_values=prefix.past_key_values,use_cache=True,return_dict=True)
        del prefix,end
    finally:
        for handle in handles:handle.remove()
    rows=[]
    for layer,_ in sites:
        a,b=actual[layer][:,-1,:].float(),cached[layer]
        relative=float((a-b).norm()/a.norm())
        cosine=float(torch.nn.functional.cosine_similarity(a,b)[0])
        rows.append({"layer":layer,"logical_position":len(response.input_ids)-1,
            "comparison":"last_response_token","relative_l2":relative,"cosine":cosine,
            "full_state":a.flatten().tolist(),"cached_state":b.flatten().tolist()})
    # Teacher force seven successive response tokens after one cached prefill.
    # This is a declared short repeated-cache check, not a claim about every
    # possible history. Full helper/passive tensors above cover all positions.
    count=min(thresholds.get("first_cached_response_tokens",7),len(response.response_ids))
    handles=[]; observed={}
    try:
        with torch.inference_mode():
            prefix=model(input_ids=ids[:,:len(response.prefix_ids)],
                attention_mask=torch.ones_like(ids[:,:len(response.prefix_ids)]),use_cache=True,return_dict=True)
        cache=prefix.past_key_values;del prefix
        for layer,path in sites:
            def record(module,args,output,layer=layer):observed[layer]=_tensor(output)[:,-1,:].detach().cpu().float()
            handles.append(model.get_submodule(path).register_forward_hook(record))
        for offset in range(count):
            position=len(response.prefix_ids)+offset
            with torch.inference_mode():
                step=model(input_ids=ids[:,position:position+1],attention_mask=torch.ones_like(ids[:,:position+1]),
                    past_key_values=cache,use_cache=True,return_dict=True)
            cache=step.past_key_values;del step
            for layer,_ in sites:
                a,b=actual[layer][:,position,:].float(),observed[layer]
                rows.append({"layer":layer,"logical_position":position,"comparison":"successive_response_token",
                    "relative_l2":float((a-b).norm()/a.norm()),
                    "cosine":float(torch.nn.functional.cosine_similarity(a,b)[0]),
                    "full_state":a.flatten().tolist(),"cached_state":b.flatten().tolist()})
        del cache
    finally:
        for handle in handles:handle.remove()
    passed=all(x["relative_l2"]<=thresholds["cache_relative_l2_max"] and x["cosine"]>=thresholds["cache_cosine_min"] for x in rows)
    return {"direct_capture_exact":exact,"direct_capture_tensors":tensor_record,"cache_comparison":rows,"pass":passed,
        "forward_count":5+count,"thresholds":thresholds,"claim":"Same-site numerical compatibility on one declared construction response, not behavioral validity."}


def run(request, approval, snapshot, destination):
    import torch
    contract=check_request(request,approval)
    destination.mkdir(parents=True,exist_ok=False)
    save_new(destination/"started.json",{"request_sha256":identity(request),"pid":os.getpid(),"request":request,"approval":approval})
    started=time.monotonic(); calls=0; completed_calls=0; model=None
    program=request["program"]; qualification=program["qualification_plan"]
    try:
        location=destination/"capture_model";location.mkdir()
        model,tokenizer,instrument=load_admitted_model(qualification,snapshot,location)
        pairs,record=authored_worker.prepared_pairs(request,tokenizer)
        save_new(destination/"authored_references.json",request["construction_source"]["references"])
        save_new(destination/"teacher_forcing_inputs.json",record)
        checks=capture_checks(model,pairs[0].positive,SITES,request["capture_checks"],destination)
        save_new(destination/"capture_checks.json",checks)
        if not checks["pass"]:raise RuntimeError("Cached/full-prefix state compatibility failed; no calibration.")
        spec=ConstructionSpec(contract.model_id,contract.model_revision,contract.model_type,SITES,
            model.get_input_embeddings().weight.shape[1],tuple(p.pair_id for p in pairs),input_hash(pairs),
            tuple(f for f,p in program["family_partitions"].items() if p!="construction_fit"),
            program["pooling"],program["accumulation_dtype"],program["insertion_dtype"],
            contract.max_input_tokens+contract.max_new_tokens,False)
        save_new(destination/"construction_spec.json",asdict(spec))
        fitted=construct_directions(model,pairs,spec)
        fitted.save(destination/"constructed")
        directions=preparatory_worker.generate_control_files(program,fitted,destination/"directions")
        item=qualification["inputs"][1]
        ids=torch.tensor([item["input_token_ids"]],device=model.get_input_embeddings().weight.device)
        operations=[("native-baseline",None,0,"native"),
            ("zero-14",14,0,"package"),("native-14",14,1,"native"),("package-14",14,1,"package"),
            ("zero-15",15,0,"package"),("native-15",15,1,"native"),("package-15",15,1,"package")]
        results={}
        for name,layer,coefficient,route in operations:
            if calls>=7 or time.monotonic()-started>1500:raise TimeoutError("A06 allowance reached before next call.")
            output_dir=destination/name;output_dir.mkdir()
            direction=fitted.raw.directions[layer] if layer is not None else None
            path=dict(SITES).get(layer)
            calls+=1
            if route=="native":
                sites=None if layer is None else [Site(name,path,"linear_attention" if layer==14 else "full_attention",direction=direction.flatten(),coefficient=coefficient)]
                output=generate_with_receipts(model,{"input_ids":ids,"attention_mask":torch.ones_like(ids)},
                    trial_id=name,sites=sites,max_new_tokens=contract.max_new_tokens,
                    min_new_tokens=contract.min_new_tokens,eos_token_id=list(contract.eos_token_ids))
                receipt=output.receipt;del output
            else:
                edit=EditSpec(layer,path,coefficient,tensor_sha256(direction))
                pipeline=DiagnosticPipeline(model,tokenizer,contract,edit=edit,direction=direction,observe_sites=SITES)
                try:
                    with pipeline.trial(name,tuple(item["input_token_ids"])):
                        pipeline.generate(input_ids=ids,return_output=True)
                finally:
                    save_new(output_dir/"package_execution.json",pipeline.records)
                receipt=pipeline.records[-1];del pipeline
            save_new(output_dir/"execution.json",receipt)
            completed_calls+=1
            if name=="native-baseline":compare(item["native_reference"],receipt)
            elif coefficient==0:compare(results["native-baseline"],receipt)
            elif route=="package":compare(results[f"native-{layer}"],receipt)
            results[name]=receipt
            save_new(output_dir/"check.json",{"status":"PASS","kind":"mechanical_not_behavioral"})
        model=tokenizer=instrument=None;del ids;gc.collect();torch.cuda.empty_cache()
        command=[sys.executable,"-m","local_integration.depth_worker","restore",str(destination),str(snapshot)]
        calls+=1
        child=subprocess.run(command,cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,
            timeout=max(1,1800-int(time.monotonic()-started)),check=False)
        save_new(destination/"restore_process.json",{"returncode":child.returncode,"stdout":child.stdout,"stderr":child.stderr})
        if child.returncode:raise RuntimeError("Fresh process restoration failed.")
        restored=json.loads((destination/"restoration/execution.json").read_text())
        completed_calls+=1
        if restored["process_id"]==os.getpid():raise RuntimeError("Restoration was not in a fresh process.")
        compare(results["native-baseline"],restored)
        result={"status":"DEPTH_CONSTRUCTION_AND_MECHANICS_COMPLETE","directions":directions,
            "capture_forwards":checks["forward_count"]+fitted.record["capture_forward_count"],
            "generation_calls":calls,"completed_generation_records":completed_calls,"model_loads":2,
            "new_sites":[list(x) for x in SITES],"calibration_started":False,"behavioral_result":False}
    except BaseException as error:
        result={"status":"FAILED_NO_RETRY","error_type":type(error).__name__,"error":str(error),"generation_calls":calls,"completed_generation_records":completed_calls}
    result.update(run_id=RUN_ID,request_sha256=identity(request),elapsed_seconds=time.monotonic()-started,
        automatic_retry=False,calibration_authorized_by_this_result=False)
    save_new(destination/"result.json",result)
    print(json.dumps(result),flush=True)
    if result["status"]=="FAILED_NO_RETRY":raise SystemExit(1)


def restore(destination,snapshot):
    import torch
    parent=json.loads((destination/"started.json").read_text())
    if parent["pid"]!=os.getppid() or (destination/"result.json").exists():
        raise PermissionError("Restoration needs its exact active parent.")
    request=parent["request"];contract=check_request(request,parent["approval"])
    for name in ("native-baseline","zero-14","native-14","package-14","zero-15","native-15","package-15"):
        if json.loads((destination/name/"check.json").read_text())["status"]!="PASS":raise ValueError("Incomplete parent checks.")
    directory=destination/"restoration";directory.mkdir()
    plan=request["program"]["qualification_plan"]
    model,tokenizer,direction=load_admitted_model(plan,snapshot,directory)
    ids=torch.tensor([plan["inputs"][1]["input_token_ids"]],device=model.get_input_embeddings().weight.device)
    output=generate_with_receipts(model,{"input_ids":ids,"attention_mask":torch.ones_like(ids)},
        trial_id="fresh-restoration",max_new_tokens=contract.max_new_tokens,
        min_new_tokens=contract.min_new_tokens,eos_token_id=list(contract.eos_token_ids))
    output.receipt.update(process_id=os.getpid(),fresh_process=True)
    save_new(directory/"execution.json",output.receipt)


if __name__=="__main__":
    if sys.argv[1]=="restore":restore(Path(sys.argv[2]),Path(sys.argv[3]))
    else:
        request,approval,snapshot,destination=map(Path,sys.argv[1:])
        run(json.loads(request.read_text()),json.loads(approval.read_text()),snapshot,destination)
