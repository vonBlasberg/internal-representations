"""Check, launch once, retrieve and audit only the corrected A05 calibration."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import zipfile

from . import headroom_transport as transport
from . import authored_run as authored
from . import preparatory_run as previous
from . import qualification_transport as delivery
from .headroom_worker import ROOT, gate_module
from .construction_program import phase_plan, calibration_arms
from .preparatory_phases import identity, save_new, checked_scores, summarize_calibration
from .calibration_selection import select


def read(path): return json.loads(Path(path).read_text())


def load_request(directory):
    directory = Path(directory)
    request,package,approval = (read(directory/name) for name in ("request.json","transport.json","approval.json"))
    if delivery.file_digest(directory/"source_payload.zip") != read(directory/"source_archive.json")["sha256"]:
        raise ValueError("Saved source archive changed.")
    with zipfile.ZipFile(directory/"source_payload.zip") as archive:
        if len(archive.namelist()) != len(set(archive.namelist())): raise ValueError("Duplicate archive names.")
        payloads = {name:archive.read(name) for name in archive.namelist()}
    transport.verify(package,payloads,approval)
    if json.loads(payloads["request/research.json"]) != request: raise ValueError("Request differs from transport.")
    for name,data in payloads.items():
        if not name.startswith("request/") and (ROOT/name).read_bytes() != data:
            raise ValueError("A frozen source or artifact changed: "+name)
    return request,approval,package,payloads


def verify_outcome(request, evidence, *, tokenizer=None):
    """Replay the early-stop rule, all row scores, selection and technical records."""
    from inspect_ai.log import read_eval_log
    program = request["program"]
    case = program["cases"]["calibration"][0]
    plan = phase_plan(program,"calibration",calibration_arms(program,request["directions"]))
    directory = evidence/"phases"/plan["run_id"]
    result, terminal = read(evidence/"result.json"), read(evidence.parent/"terminal.json")
    phase = read(directory/"result.json")
    scores = checked_scores(plan,[case],phase)
    if (result.get("request_sha256") != identity(request) or result.get("run_id") != request["run_id"]
            or result.get("headroom_amendment_sha256") != identity(request["headroom_amendment"])):
        raise ValueError("Terminal identity mismatch.")
    if terminal.get("status") not in transport.TERMINAL or terminal.get("process",{}).get("returncode") != 0 or terminal["process"].get("timed_out") is not False:
        raise ValueError("Outer worker did not complete successfully; preserve failure without retry.")
    baseline = phase["records"][0]
    if baseline["execution_status"] != "COMPLETED": raise ValueError("No completed baseline to verify.")
    admission = gate_module().admission(case,baseline["raw_response"])
    if any(value != admission for value in (phase.get("baseline_admission"),result.get("baseline_admission"),read(directory/"baseline_admission.json"))):
        raise ValueError("Baseline feasibility differs on independent replay.")
    stopped = not admission["treatments_allowed_by_feasibility"]
    expected = "CALIBRATION_STOPPED_BASELINE_FEASIBILITY" if stopped else "CALIBRATION_COMPLETE"
    if result["status"] != expected or terminal["status"] != expected:
        raise ValueError("Worker ignored or misclassified its baseline gate.")
    count = 1 if stopped else 41
    if result.get("generation_calls") != count or result.get("model_loads") != count or result.get("skipped_conditions") != 41-count:
        raise ValueError("Generation, model-load or skip counts differ.")
    if stopped:
        if phase.get("failure",{}).get("error_type") != "BaselineFeasibilityStop":
            raise ValueError("Missing explicit feasibility stop.")
        for trial,row in zip(plan["trials"][1:],phase["records"][1:],strict=True):
            if row["execution_status"] != "NOT_RUN_AFTER_FAILURE" or row.get("skip_reason") != admission["status"] or (directory/trial["trial_id"]).exists():
                raise ValueError("A condition ran after the infeasible baseline.")
    elif phase["failure"] is not None or any(r["execution_status"] != "COMPLETED" for r in phase["records"]):
        raise ValueError("Incomplete calibration despite a feasible baseline.")
    if tokenizer is None:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(ROOT/"negotiation-steering/snapshots/qwen35-9b/c202236235762e1c871ad0ccb60c8ee5ba337b9a/verified-snapshot"),local_files_only=True)
    baseline_receipt = None
    for i,(trial,row) in enumerate(zip(plan["trials"],phase["records"],strict=True)):
        if read(directory/f"record-{i:05d}.json") != row: raise ValueError("Original row file differs.")
        if row["execution_status"] != "COMPLETED": continue
        if scores[trial["trial_id"]] != row["score"]: raise ValueError("Saved score differs.")
        location = directory/trial["trial_id"]
        source = row["source"]
        path = location/delivery.safe_relative(source["source_log_path"])
        if delivery.file_digest(path) != source["source_log_sha256"]: raise ValueError("Inspect log changed.")
        log = read_eval_log(str(path))
        if log.status != "success" or len(log.samples or []) != 1 or log.samples[0].output.completion != row["raw_response"]:
            raise ValueError("Inspect output mismatch.")
        metadata={"run_id":plan["run_id"],"phase":plan["phase"],"plan_sha256":identity(plan),
            "fixture_only":plan["fixture_only"],"model_id":plan["model_id"],"model_revision":plan["model_revision"],
            **{k:trial[k] for k in ("trial_id","case_id","family_id","arm_id","kind","edit","messages_sha256","case_content_sha256","output_contract_version")}}
        if (log.samples[0].id!=trial["trial_id"] or source.get("source_sample_id")!=trial["trial_id"]
                or source.get("metadata")!=metadata or log.samples[0].metadata.get("preparatory_trial")!=metadata):
            raise ValueError("Inspect source sample and exact trial metadata differ.")
        records = read(location/"state_execution.json")["records"]
        if len(records) != 1: raise ValueError("Unexpected generation count.")
        receipt = records[0]
        ids = tokenizer.apply_chat_template(trial["messages"],tokenize=True,return_dict=False,add_generation_prompt=True,enable_thinking=False)
        if (read(location/"input.json")["input_token_ids"] != ids or receipt["input_token_ids"] != ids
                or read(location/"input.json")["messages_sha256"] != trial["messages_sha256"]
                or receipt["generated_token_ids"] != source["generated_token_ids"]
                or tokenizer.decode(receipt["generated_token_ids"],skip_special_tokens=True) != row["raw_response"]
                or receipt["edit"] != trial["edit"] or receipt["status"] != "completed"
                or receipt["generation_call_count"] != 1 or receipt["retry_count"] != 0
                or not receipt["weights_unchanged"] or not receipt["hooks_restored"]
                or read(location/"loaded_model.json")["weights"]["entries_sha256"] != program["qualification_plan"]["model_weight_entries_sha256"]):
            raise ValueError("Input, response, model, edit or restoration receipt differs.")
        if i == 0: baseline_receipt = receipt
        if trial["kind"] == "sham" and any(receipt[k] != baseline_receipt[k] for k in ("input_token_ids","generated_token_ids","processed_logit_steps")):
            raise ValueError("Sham parity failed.")
    selection = select(plan,[case],phase)
    if selection != read(evidence/"selection.json") or result["selection"] != selection:
        raise ValueError("Selection differs on replay.")
    if summarize_calibration(plan,[case],phase) != read(evidence/"calibration_summary.json"):
        raise ValueError("Calibration summary differs on replay.")
    return {"status":"BASELINE_STOP_VERIFIED" if stopped else "CALIBRATION_VERIFIED", "baseline_admission":admission,
        "selection":selection,"completed_generations":count,"unrun_conditions":41-count,
        "worker_result":result,"outer_terminal":terminal,"rows":phase["records"],
        "held_out_result":False,"further_execution_authorized":False}


def audit(directory):
    directory=Path(directory)
    request,approval,package,payloads=load_request(directory)
    evidence,manifest=authored.verified_delivery(directory,request,approval)
    report=verify_outcome(request,evidence)
    report.update(run_id=request["run_id"],request_sha256=identity(request),returned_files_verified=len(manifest["files"]),
        checked_at_utc=datetime.now(timezone.utc).isoformat(),research_model_loaded=False,f4_accessed=False,retry_performed=False)
    save_new(directory/"terminal_audit.json",report)
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("check","launch","retrieve","audit"))
    parser.add_argument("directory",type=Path)
    args=parser.parse_args()
    if args.action=="audit":
        report=audit(args.directory)
        result={k:report[k] for k in ("status","baseline_admission","selection","completed_generations","unrun_conditions")}
    elif args.action=="check":
        request,_,_,payloads=load_request(args.directory)
        result={"status":"HEADROOM_REQUEST_PASS","run_id":request["run_id"],"files":len(payloads),"provider_contacted":False}
    else:
        sys.path.append(str(ROOT.parent/"model-trace-observatory/.venv/lib/python3.12/site-packages"))
        if args.action=="retrieve": result=delivery.retrieve(args.directory/"launch")
        else:
            request,approval,package,payloads=load_request(args.directory)
            result=transport.launch(request,approval,package,payloads,args.directory/"launch")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__": main()
