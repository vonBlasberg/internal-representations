"""Prepare a separate buyer-matched construction contrast. No execution route."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from submission_analysis.analyze import scorer
from .preparatory_phases import identity
from .reference_construction import response_text

SOURCE = 'records/revised_intervention_2026-10-31_A06/construction/request.json'
SOURCE_SHA256 = '64f246749ba4c85d1656f84e75184013b3c5cde374656ef979e184c307dc484f'
CASE_IDS = ('cf-machining-base', 'cf-pumps-base', 'cf-kitchen-base', 'cf-scanners-base')
CASE_HASHES = (
    'e57acb345762c071b4eb7f19aac311ffeddc9e42c93c240483c6e2424a89d727',
    '4410bf3a20cbd78d373836e51b481518bfcc8c42a77d354def92ef7e13cb924f',
    '65a87f907d654f39ffd997487cc733bcd4049bbe974974f2f400ea9653da76de',
    'ddddfb3f8b427a278b245b9a28f5ecbf7f0f923e6e269a4f7f94662a82e7aa3f',
)
RULE = {
    'target': 'Higher proposed joint payoff at equal buyer payoff among accepted offers.',
    'eligible_pair': 'Both offers valid and accepted under the unchanged simulated agreement rule; equal buyer payoff; positive joint payoff strictly higher.',
    'order': ['fewest_changed_issues', 'highest_positive_joint_payoff', 'highest_shared_buyer_payoff',
              'smallest_positive_joint_gap', 'ascending_positive_package_key', 'ascending_negative_package_key'],
    'source': 'algorithmically_authored_buyer_matched_references',
    'failure': 'Stop if any original fit case lacks a pair. Never omit, substitute or revise a case.',
}


def load_fit_cases(root):
    raw = (Path(root) / SOURCE).read_bytes()
    if hashlib.sha256(raw).hexdigest() != SOURCE_SHA256:
        raise ValueError('Original construction request changed.')
    # No construction-check, calibration, development or evaluation values are used.
    return deepcopy(json.loads(raw)['program']['cases']['construction_fit'])


def ranking(module, positive, negative):
    changed = sum(positive['package'][key] != value for key, value in negative['package'].items())
    return (changed, -positive['proposed_joint_gain'], -positive['proposed_self_payoff'],
            positive['proposed_joint_gain'] - negative['proposed_joint_gain'],
            module.package_key(positive['package']), module.package_key(negative['package']))


def build(cases):
    if (tuple(c['case_id'] for c in cases) != CASE_IDS
            or len({c['family_id'] for c in cases}) != 4
            or any(c['partition'] != 'construction_fit' or c.get('output_contract_version') != 2 for c in cases)):
        raise ValueError('Use all four original construction-fit cases in their declared order.')
    module = scorer()
    rows = []
    for case, expected_hash in zip(cases, CASE_HASHES, strict=True):
        module.validate_case(case)
        if case['case_content_sha256'] != expected_hash or module.case_content_sha256(case) != expected_hash:
            raise ValueError('Original case content changed.')
        packages = module.enumerate_packages(case)
        scores = [module.score_response(case, response_text(package)) for package in packages]
        if len(scores) != 72 or any(not value['valid'] for value in scores):
            raise ValueError('Original feasible package set differs.')
        pairs = [(p, n) for p in scores for n in scores if p['agreement'] and n['agreement']
                 and p['proposed_self_payoff'] == n['proposed_self_payoff']
                 and p['proposed_joint_gain'] > n['proposed_joint_gain']]
        if not pairs:
            raise ValueError('No buyer-matched accepted pair for ' + case['case_id'])
        positive, negative = min(pairs, key=lambda pair: ranking(module, *pair))
        rows.append({'case_id': case['case_id'], 'family_id': case['family_id'],
            'case_content_sha256': case['case_content_sha256'], 'packages_enumerated': len(packages),
            'eligible_ordered_pairs': len(pairs), 'changed_issues': ranking(module, positive, negative)[0],
            'positive_text': response_text(positive['package']), 'negative_text': response_text(negative['package']),
            'author_only_scores': {'positive': positive, 'negative': negative},
            'buyer_delta': positive['proposed_self_payoff'] - negative['proposed_self_payoff'],
            'supplier_delta': positive['proposed_counterpart_payoff'] - negative['proposed_counterpart_payoff'],
            'joint_delta': positive['proposed_joint_gain'] - negative['proposed_joint_gain']})
    return {'artifact_type': 'BUYER_MATCHED_CONSTRUCTION_PREPARATION', 'schema_version': 1,
        'source_request': SOURCE, 'source_request_sha256': SOURCE_SHA256, 'cases_sha256': identity(cases),
        'rule': deepcopy(RULE), 'pairs': rows, 'private_payoffs_used_for_authoring': True,
        'private_payoffs_added_to_model_input': False, 'model_generated_examples': False,
        'research_model_loaded': False, 'model_calls': 0, 'capture_forwards': 0,
        'direction_constructed': False, 'calibration_changed': False, 'execution_authorized': False,
        'behavioral_result': False, 'automatic_retry': False}


def token_inputs(cases, bundle, tokenizer, contract):
    """Prepare common-prefix response captures, without running a model."""
    from .direction_construction import ConstructionPair, ResponseTokens, input_hash
    if bundle != build(cases):
        raise ValueError('Prepared contrast, source or ordering changed.')
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != contract['chat_template_sha256']:
        raise ValueError('Wrong tokenizer template.')
    special = set(tokenizer.all_special_ids)
    pairs, records = [], []
    for case, row in zip(cases, bundle['pairs'], strict=True):
        messages = [{'role': 'system', 'content': case['system_text']}, {'role': 'user', 'content': case['user_text']}]
        prefix = tuple(tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False,
                                                     add_generation_prompt=True, enable_thinking=False))
        if not prefix or len(prefix) > contract['max_input_tokens']:
            raise ValueError('Input exceeds the unchanged token allowance.')
        responses = []
        for name in ('positive_text', 'negative_text'):
            text = row[name]
            ids = tuple(tokenizer.encode(text, add_special_tokens=False))
            if (not ids or len(ids) > contract['max_new_tokens'] or any(t in special for t in ids)
                    or tokenizer.decode(ids, skip_special_tokens=True) != text):
                raise ValueError('Reference token identity or allowance differs.')
            responses.append(ResponseTokens(prefix, ids, tuple(range(len(ids)))))
        if responses[0].response_ids == responses[1].response_ids:
            raise ValueError('Identical reference tokens cannot define the contrast.')
        pairs.append(ConstructionPair(case['case_id'], case['family_id'], *responses))
        records.append({'case_id': case['case_id'], 'messages': messages, 'prefix_token_ids': list(prefix),
                        'positive_response_token_ids': list(responses[0].response_ids),
                        'negative_response_token_ids': list(responses[1].response_ids)})
    return tuple(pairs), {'artifact_type': 'BUYER_MATCHED_REFERENCE_TOKEN_INPUTS',
        'references_sha256': identity(bundle), 'construction_sha256': input_hash(tuple(pairs)),
        'position_policy': 'exclude_special_tokens', 'pooling': 'response_mean', 'records': records,
        'model_generated_examples': False, 'model_calls': 0, 'capture_forwards': 0,
        'execution_authorized': False, 'a08_changed': False}
