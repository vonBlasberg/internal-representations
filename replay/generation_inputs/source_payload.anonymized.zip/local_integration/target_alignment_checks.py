"""Fixed scoring checks and descriptive output. No model, provider or selection."""
from copy import deepcopy
import hashlib
import math

INPUTS_SHA256 = "378450959711cb20997ab70977ab440ff9a4cb1cb5c0e8ba6da0f52d3431e67b"
LIMITS = {"maximum_forward_attempts": 1221, "maximum_model_loads": 2,
          "maximum_free_generations": 0, "maximum_wall_seconds": 2400,
          "max_token_logprob_difference_nats": 0.05,
          "max_sequence_logscore_difference_nats": 0.25,
          "fp32_reconstruction_atol": 1e-6, "fp32_reconstruction_rtol": 1e-6}
RENDERINGS = ("original", "option-id-alias")
QUALIFICATION_A = ("baseline", "sham-14-0", "sham-15-0", "internal-14-1p0",
                   "internal-15-1p0", "reverse-14-1p0", "reverse-15-1p0")


def admitted_bank(raw):
    import json
    if hashlib.sha256(raw).hexdigest() != INPUTS_SHA256:
        raise ValueError("The prospectively fixed A07 input bank changed.")
    bank = json.loads(raw)
    if len(bank["trials"]) != 136 or len({x["trial_id"] for x in bank["trials"]}) != 136:
        raise ValueError("Incomplete or duplicate input bank.")
    return bank


def qualification_trials(bank):
    result = []
    lookup = {(t["rendering_id"], t["condition_id"], t["response_id"]): t for t in bank["trials"]}
    for rendering in RENDERINGS:
        result.extend(lookup[rendering, arm, "A"] for arm in QUALIFICATION_A)
        result.extend(lookup[rendering, arm, "T"] for arm in ("baseline", "prompt-2"))
    if len(result) != 18 or sum(t["reference_length"] for t in result) != 1055:
        raise ValueError("Qualification forward accounting changed.")
    return result


def qualification_plan(bank):
    trials = qualification_trials(bank)
    return {"limits": dict(LIMITS), "full_and_cached_trials": [t["trial_id"] for t in trials],
            "qualification_package_forwards": 18, "qualification_cached_forwards": 1055,
            "raw_before_forwards": 2, "causal_suffix_forwards": 4, "one_token_forwards": 2,
            "study_forwards": 136, "raw_after_forwards": 2, "fresh_process_forwards": 2,
            "total_forward_ceiling": 1221, "free_generations": 0,
            "scope": "Fixed sentinel checks, not cached/full equivalence of all 136 study scores."}


def verify_score_record(record):
    if (record["status"] != "completed" or record["free_generations"] != 0 or record["retry_count"] != 0
            or not all(record[k] for k in ("hooks_restored", "forward_restored", "configuration_unchanged",
                                          "parameter_signature_unchanged"))):
        raise ValueError("Incomplete or unrestored scoring record.")
    values = record["log_probabilities_fp32"]
    if (len(values) != len(record["reference_token_ids"]) or not values
            or not all(math.isfinite(x) and x <= 0 for x in values)
            or math.fsum(values) != record["prefix_log_score"] or record["eos_scored"]):
        raise ValueError("Invalid token-prefix score.")
    for value, target, normalizer in zip(values, record["centered_selected_logits_fp32"],
                                         record["centered_log_normalizers_fp32"], strict=True):
        if not math.isclose(value, target-normalizer, abs_tol=LIMITS["fp32_reconstruction_atol"],
                            rel_tol=LIMITS["fp32_reconstruction_rtol"]):
            raise ValueError("Recorded FP32 score does not reconstruct.")


def compare_cached(full, cached):
    verify_score_record(full)
    verify_score_record(cached)
    if (full["prefix_token_ids"] != cached["prefix_token_ids"]
            or full["reference_token_ids"] != cached["reference_token_ids"]
            or full["edit"] != cached["edit"] or full["route"] != "package"
            or cached["route"] != "native_cached"):
        raise ValueError("Full and cached routes do not describe the same supplied history/edit.")
    maximum = max(abs(a-b) for a,b in zip(full["log_probabilities_fp32"], cached["log_probabilities_fp32"], strict=True))
    sequence = abs(full["prefix_log_score"] - cached["prefix_log_score"])
    return {"full_trial": full["trial_id"], "cached_trial": cached["trial_id"],
            "max_token_difference_nats": maximum, "sequence_difference_nats": sequence,
            "pass": maximum <= LIMITS["max_token_logprob_difference_nats"]
                    and sequence <= LIMITS["max_sequence_logscore_difference_nats"]}


def summarize(bank, records):
    if len(records) != 136:
        raise ValueError("Every fixed diagnostic sequence is required; no selection or exclusion.")
    lookup = {}
    for trial, record in zip(bank["trials"], records, strict=True):
        verify_score_record(record)
        if (record["trial_id"] != "study--"+trial["trial_id"]
                or record["prefix_token_ids"] != trial["prefix_token_ids"]
                or record["reference_token_ids"] != trial["reference_token_ids"]
                or record["edit"] != trial["edit"] or record["route"] != "package"):
            raise ValueError("Study records are not the complete prospectively fixed sequence.")
        lookup[trial["rendering_id"], trial["condition_id"], trial["response_id"]] = record
    rows = []
    for rendering in RENDERINGS:
        baseline = {r: lookup[rendering, "baseline", r]["prefix_log_score"] for r in "ATCR"}
        for condition in bank["conditions"]:
            key = condition["arm_id"]
            scores = {r: lookup[rendering, key, r]["prefix_log_score"] for r in "ATCR"}
            groups = {}
            for response in "ATCR":
                trial = next(t for t in bank["trials"] if (t["rendering_id"],t["condition_id"],t["response_id"]) == (rendering,key,response))
                values = lookup[rendering,key,response]["log_probabilities_fp32"]
                groups[response] = {group: math.fsum(value for value,label in zip(values,trial["token_report_groups"],strict=True) if label==group)
                                    for group in ("price","delivery","warranty","payment","other")}
            rows.append({"rendering_id": rendering, "condition_id": key, "kind": condition["kind"],
                "edit": deepcopy(condition["edit"]), "prefix_log_scores": scores,
                "baseline_adjusted_contrasts_nats": {"A_minus_"+r: (scores["A"]-scores[r])-(baseline["A"]-baseline[r]) for r in "TCR"},
                "token_group_contributions": groups,
                "trial_ids": [lookup[rendering,key,r]["trial_id"] for r in "ATCR"]})
    return {"status": "SCORES_COMPLETE_PENDING_RESTORATION_AND_AUDIT", "rows": rows, "sequence_count": 136,
            "row_count": 34, "case_families": 1, "encodings_pooled": False,
            "candidate_selection_performed": False, "free_generations": 0,
            "generated_decision_or_payoff_result": False,
            "meaning": "Canonical authored offer-prefix scores under teacher forcing. Not total action probabilities or evidence of changed generated offers.",
            "does_not_test": ["offer versus accept choice", "general cooperation", "held-out robustness", "human negotiation outcomes"]}
