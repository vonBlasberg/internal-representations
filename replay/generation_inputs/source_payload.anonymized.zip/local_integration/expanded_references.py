"""Construction-only, decision-aligned references; no model or provider calls."""
from collections import Counter
from copy import deepcopy
import hashlib
import json

from submission_analysis.analyze import scorer
from .buyer_matched_references import load_fit_cases as originals, CASE_IDS, CASE_HASHES, SOURCE, SOURCE_SHA256
from .preparatory_phases import identity

PAIR_COUNT = 24
FORWARD_COUNT = 48
PER_FAMILY = 6
RULE = {
    'target': 'Making a mutually improving counteroffer rather than accepting the standing package.',
    'negative': 'Accept a valid standing package satisfying the existing supplier agreement rule.',
    'positive': 'Offer a different valid, accepted package, strictly increasing joint payoff without reducing either party payoff.',
    'positive_order': ['fewest_changed_issues', 'highest_joint_payoff', 'ascending_package_key'],
    'contexts': 'Keep each of four original cases exactly; add five standing-package contexts per original family, preserving all other substantive fields.',
    'context_order': ['least_used_changed_issue_set', 'least_used_issue_transitions', 'greatest_minimum_standing_package_distance', 'ascending_standing_package_key'],
    'weights': 'Equal pair weights, six pairs per original family; four families, not 24 independent families.',
    'permuted_control': 'Prospectively fixed swaps at odd zero-based indices in each six-pair family; preserve the half-swapped control, not the old four-pair indices [1,2]; no redraw.',
    'failure': 'Stop if any original or required context fails; no omission, substitution or post-result adjustment.',
    'interpretation': 'Authored examples of improving a negotiation offer, not evidence of a general cooperation trait or behavioral transfer.',
}


def text_response(decision, package):
    return json.dumps({'decision': decision, 'package': {key: package[key] for key in
        ('price', 'delivery', 'warranty', 'payment')}}, indent=2)


def _checked_originals(cases):
    m = scorer()
    if tuple(c['case_id'] for c in cases) != CASE_IDS or len({c['family_id'] for c in cases}) != 4:
        raise ValueError('All four original construction families are required in their original order.')
    for c, wanted in zip(cases, CASE_HASHES, strict=True):
        m.validate_case(c)
        if c['partition'] != 'construction_fit' or c['case_content_sha256'] != wanted:
            raise ValueError('Original construction case changed.')
    return m


def _package_scores(case, m):
    """Table arithmetic for authoring; final reference responses use the full scorer."""
    scores = []
    for package in m.enumerate_packages(case):
        buyer, supplier = m.payoffs(case, package)
        threshold = case['reservation_values']['counterpart']
        agreement = supplier >= threshold if case['counterpart_rule']['on_tie'] == 'accept' else supplier > threshold
        scores.append({'package': package, 'valid': True, 'agreement': agreement,
            'proposed_self_payoff': buyer, 'proposed_counterpart_payoff': supplier,
            'proposed_joint_gain': buyer + supplier})
    return scores


def _family_contexts(original, m):
    scores = _package_scores(original, m)
    if len(scores) != 72 or not all(s['valid'] for s in scores):
        raise ValueError('Original permissible package set differs.')
    candidates = []
    for n in scores:
        if not n['agreement']:
            continue
        positives = [p for p in scores if p['agreement'] and p['proposed_joint_gain'] > n['proposed_joint_gain']
            and p['proposed_self_payoff'] >= n['proposed_self_payoff']
            and p['proposed_counterpart_payoff'] >= n['proposed_counterpart_payoff']]
        if not positives:
            continue
        p = min(positives, key=lambda p: (sum(p['package'][k] != v for k, v in n['package'].items()),
            -p['proposed_joint_gain'], m.package_key(p['package'])))
        changes = tuple(k for k in m.ISSUE_IDS if p['package'][k] != n['package'][k])
        transitions = tuple((k, n['package'][k], p['package'][k]) for k in changes)
        candidates.append({'positive': p, 'negative': n, 'changes': changes, 'transitions': transitions})
    initial = [r for r in candidates if r['negative']['package'] == original['counterpart_last_package']]
    if len(initial) != 1 or len(candidates) < PER_FAMILY:
        raise ValueError('Original case or required extra contexts lack eligible references.')
    chosen = [initial[0]]
    while len(chosen) < PER_FAMILY:
        patterns = Counter(r['changes'] for r in chosen)
        transitions = Counter(t for r in chosen for t in r['transitions'])
        remaining = [r for r in candidates if r not in chosen]
        def rank(r):
            distance = min(sum(r['negative']['package'][k] != c['negative']['package'][k]
                               for k in m.ISSUE_IDS) for c in chosen)
            return (patterns[r['changes']], sum(transitions[t] for t in r['transitions']),
                    -distance, m.package_key(r['negative']['package']))
        chosen.append(min(remaining, key=rank))
    contexts = []
    for index, row in enumerate(chosen):
        case = deepcopy(original)
        if index:
            case['case_id'] = original['case_id'] + '-standing-' + str(index + 1)
            case['variant_id'] = case['case_id']
            case['variant_of'] = case['case_id']
            case['variant_kind'] = 'base'
            case['counterpart_last_package'] = deepcopy(row['negative']['package'])
            case['system_text'], case['user_text'] = m.render_prompt(case)
            case['case_content_sha256'] = m.case_content_sha256(case)
        m.validate_case(case)
        contexts.append(case)
    return contexts


def expand(cases):
    m = _checked_originals(cases)
    return [context for original in cases for context in _family_contexts(original, m)]


def load_fit_cases(root):
    # Only the construction_fit slice is read, never any calibration outcome.
    return expand(originals(root))


def build(cases):
    if len(cases) != PAIR_COUNT:
        raise ValueError('Exactly 24 declared construction pairs are required.')
    original = [cases[i] for i in range(0, PAIR_COUNT, PER_FAMILY)]
    m = _checked_originals(original)
    if cases != expand(original):
        raise ValueError('Expanded construction cases or their deterministic order changed.')
    rows = []
    for case in cases:
        negative = m.score_response(case, text_response('accept', case['counterpart_last_package']))
        scores = _package_scores(case, m)
        eligible = [p for p in scores if p['valid'] and p['agreement']
            and p['proposed_joint_gain'] > negative['proposed_joint_gain']
            and p['proposed_self_payoff'] >= negative['proposed_self_payoff']
            and p['proposed_counterpart_payoff'] >= negative['proposed_counterpart_payoff']]
        if not negative['valid'] or not negative['agreement'] or not eligible:
            raise ValueError('Invalid or non-improving authored pair.')
        positive = min(eligible, key=lambda p: (sum(p['package'][k] != v for k, v in negative['package'].items()),
            -p['proposed_joint_gain'], m.package_key(p['package'])))
        expected = positive
        positive = m.score_response(case, text_response('offer', expected['package']))
        if any(positive[key] != value for key, value in expected.items()):
            raise ValueError('Authoring arithmetic and frozen response scorer disagree.')
        rows.append({'case_id': case['case_id'], 'family_id': case['family_id'],
            'case_content_sha256': case['case_content_sha256'], 'packages_enumerated': len(scores),
            'positive_text': text_response('offer', positive['package']),
            'negative_text': text_response('accept', negative['package']),
            'changed_issues': [k for k in m.ISSUE_IDS if positive['package'][k] != negative['package'][k]],
            'author_only_scores': {'positive': positive, 'negative': negative},
            'buyer_delta': positive['proposed_self_payoff'] - negative['proposed_self_payoff'],
            'supplier_delta': positive['proposed_counterpart_payoff'] - negative['proposed_counterpart_payoff'],
            'joint_delta': positive['proposed_joint_gain'] - negative['proposed_joint_gain']})
    return {'artifact_type': 'EXPANDED_CONSTRUCTION_PREPARATION', 'schema_version': 1,
        'source_request': SOURCE, 'source_request_sha256': SOURCE_SHA256, 'cases_sha256': identity(cases),
        'rule': deepcopy(RULE), 'pairs': rows, 'original_cases': 4, 'construction_families': 4,
        'pair_count': PAIR_COUNT, 'pairs_per_family': PER_FAMILY,
        'private_payoffs_used_for_authoring': True, 'private_payoffs_added_to_model_input': False,
        'model_generated_examples': False, 'research_model_loaded': False, 'model_calls': 0,
        'capture_forwards': 0, 'direction_constructed': False, 'calibration_changed': False,
        'execution_authorized': False, 'behavioral_result': False, 'automatic_retry': False}


def token_inputs(cases, bundle, tokenizer, contract):
    from .direction_construction import ConstructionPair, ResponseTokens, input_hash
    if bundle != build(cases):
        raise ValueError('Prepared construction bundle changed.')
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != contract['chat_template_sha256']:
        raise ValueError('Wrong tokenizer template.')
    pairs, records = [], []
    special = set(tokenizer.all_special_ids)
    for case, row in zip(cases, bundle['pairs'], strict=True):
        messages = [{'role': 'system', 'content': case['system_text']}, {'role': 'user', 'content': case['user_text']}]
        prefix = tuple(tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False,
            add_generation_prompt=True, enable_thinking=False))
        if not prefix or len(prefix) > contract['max_input_tokens']:
            raise ValueError('Input exceeds the unchanged token allowance.')
        responses = []
        for name in ('positive_text', 'negative_text'):
            text = row[name]
            ids = tuple(tokenizer.encode(text, add_special_tokens=False))
            if (not ids or len(ids) > contract['max_new_tokens'] or any(t in special for t in ids)
                    or tokenizer.decode(ids, skip_special_tokens=True) != text):
                raise ValueError('Reference token identity or allowance differs.')
            responses.append(ResponseTokens(prefix, ids, tuple(range(len(ids)))))
        if responses[0].response_ids == responses[1].response_ids:
            raise ValueError('Identical reference responses.')
        pairs.append(ConstructionPair(case['case_id'], case['family_id'], *responses))
        records.append({'case_id': case['case_id'], 'messages': messages, 'prefix_token_ids': list(prefix),
            'positive_response_token_ids': list(responses[0].response_ids),
            'negative_response_token_ids': list(responses[1].response_ids)})
    return tuple(pairs), {'artifact_type': 'EXPANDED_REFERENCE_TOKEN_INPUTS', 'references_sha256': identity(bundle),
        'construction_sha256': input_hash(tuple(pairs)), 'position_policy': 'exclude_special_tokens',
        'pooling': 'response_mean', 'records': records, 'model_generated_examples': False,
        'model_calls': 0, 'capture_forwards': 0, 'execution_authorized': False, 'calibration_changed': False}
