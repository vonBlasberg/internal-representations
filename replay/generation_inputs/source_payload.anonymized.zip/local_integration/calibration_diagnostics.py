"""Passive prefill recording for independently replayable calibration edits."""
import base64
from contextlib import contextmanager
from unittest.mock import patch

import torch

from .depth_diagnostics import DiagnosticPipeline
from .research_pipeline import _tensor


class CalibrationPipeline(DiagnosticPipeline):
    def generate(self, *args, **kwargs):
        native = self.research_model.generate
        prefill = []

        def observed_native(*positional, **call):
            handle = None
            try:
                if self.edit is not None:
                    def before(module, inputs, output):
                        if prefill:
                            return
                        value = _tensor(output).detach().clone()
                        if tuple(value.shape[:2]) != (1, call['input_ids'].shape[1]) or value.dtype != torch.bfloat16:
                            raise ValueError('Expected one complete BF16 prefill at the edited site.')
                        prefill.append({'layer': self.edit.layer, 'module_path': self.edit.module_path,
                            'shape': list(value.shape), 'dtype': str(value.dtype),
                            'before': base64.b64encode(value.contiguous().view(torch.uint8).cpu().numpy().tobytes()).decode('ascii')})
                    handle = self.research_model.get_submodule(self.edit.module_path).register_forward_hook(before, prepend=True)
                return native(*positional, **call)
            finally:
                if handle is not None:
                    handle.remove()

        try:
            with patch.object(self.research_model, 'generate', new=observed_native):
                return super().generate(*args, **kwargs)
        finally:
            if self.records:
                self.records[-1]['calibration_prefill'] = prefill


@contextmanager
def calibration_diagnostic_connection():
    from . import preparatory_inspect
    with patch.object(preparatory_inspect, 'RecordedSteeringPipeline', CalibrationPipeline):
        yield
