"""Author and validate construction examples without asking a model to generate them.

This prospective, local-only adapter has no model loader, worker, provider or
launch entry point. It does not grant research execution or calibration authority.
It never reads case files: callers supply construction-fit cases explicitly.
"""
from copy import deepcopy
import hashlib
import json

from submission_analysis.analyze import scorer
from .preparatory_phases import identity


RULE = {
    "version": 1,
    "feasible_set": "All packages allowed by the existing hard constraints; no added counterpart-acceptance constraint.",
    "positive": "Maximize proposed joint payoff, then own payoff, then ascending canonical package key.",
    "negative": "Maximize proposed own payoff, then joint payoff, then ascending canonical package key.",
    "contrast": "Positive joint payoff strictly exceeds negative; negative own payoff strictly exceeds positive.",
    "decision": "offer",
    "format": "Decision-only JSON, indent=2, canonical issue order, no rationale or payoff claim.",
    "source": "algorithmically_authored_reference",
    "failure": "Stop the complete preparation; never drop, replace or relabel a case.",
}


def response_text(package):
    return json.dumps({"decision": "offer", "package": scorer().canonical_package(package)}, indent=2)


def check_pair(case, positive_text, negative_text):
    """Validate realized payoff labels, not merely the name of an instruction."""
    score = scorer()
    positive = score.score_response(case, positive_text)
    negative = score.score_response(case, negative_text)
    if not positive["valid"] or not negative["valid"]:
        raise ValueError("Both construction responses must pass the unchanged scorer.")
    if positive["package"] == negative["package"]:
        raise ValueError("Identical decision packages cannot define this contrast.")
    joint_gap = positive["proposed_joint_gain"] - negative["proposed_joint_gain"]
    own_gap = negative["proposed_self_payoff"] - positive["proposed_self_payoff"]
    if joint_gap <= 0 or own_gap <= 0:
        raise ValueError("Construction responses do not satisfy both declared payoff contrasts.")
    return {"positive": positive, "negative": negative,
            "positive_joint_advantage": joint_gap, "negative_own_advantage": own_gap}


def build_bundle(cases, *, expected_case_ids):
    """Choose fixed references using payoffs only, never model or calibration results."""
    score = scorer()
    if (not cases or [c["case_id"] for c in cases] != list(expected_case_ids)
            or len(set(expected_case_ids)) != len(expected_case_ids)):
        raise ValueError("Retain every declared construction case in its original order.")
    if len({c["family_id"] for c in cases}) != len(cases):
        raise ValueError("Each reference pair must belong to a distinct construction family.")
    rows = []
    for case in cases:
        if case["partition"] != "construction_fit" or case.get("output_contract_version") != 2:
            raise ValueError("Only declared decision-only construction-fit cases are allowed.")
        score.validate_case(case)
        packages = score.enumerate_packages(case)
        positive_package = min(packages, key=lambda p: (
            -sum(score.payoffs(case, p)), -score.payoffs(case, p)[0], score.package_key(p)))
        negative_package = min(packages, key=lambda p: (
            -score.payoffs(case, p)[0], -sum(score.payoffs(case, p)), score.package_key(p)))
        positive_text, negative_text = response_text(positive_package), response_text(negative_package)
        checked = check_pair(case, positive_text, negative_text)
        rows.append({
            "case_id": case["case_id"], "family_id": case["family_id"],
            "case_content_sha256": case["case_content_sha256"],
            "feasible_packages_enumerated": len(packages),
            "positive": {"label": "higher_proposed_joint_payoff", "text": positive_text},
            "negative": {"label": "higher_proposed_own_payoff", "text": negative_text},
            "author_only_scores": checked,
        })
    return {"artifact_type": "AUTHORED_CONSTRUCTION_REFERENCES", "schema_version": 1,
        "rule": deepcopy(RULE), "source": RULE["source"], "cases_sha256": identity(cases),
        "case_ids": list(expected_case_ids), "pairs": rows,
        "private_payoffs_used_for_authoring": True, "private_payoffs_added_to_model_input": False,
        "labels_describe": "Proposed-package payoffs, not realized gains, accepted agreements or a general cooperation trait.",
        "model_generated_examples": False, "behavioral_steering_result": False,
        "research_execution_authorized": False, "calibration_authorized": False,
        "automatic_retry": False, "f4_accessed": False}


def validate_bundle(cases, bundle, *, expected_case_ids):
    if bundle != build_bundle(cases, expected_case_ids=expected_case_ids):
        raise ValueError("Reference texts, payoff labels, rule, order or provenance changed.")


def prepare_reference_tokens(cases, bundle, tokenizer, generation_contract):
    """Return common-prefix teacher-forcing inputs, with truthful authored provenance.

    No generation receipt or Inspect sample is invented. The response IDs are
    encoded from saved reference text, not claimed to have been generated.
    """
    from .direction_construction import ConstructionPair, ResponseTokens, input_hash
    validate_bundle(cases, bundle, expected_case_ids=[c["case_id"] for c in cases])
    if (not isinstance(tokenizer.chat_template, str)
            or hashlib.sha256(tokenizer.chat_template.encode()).hexdigest()
            != generation_contract["chat_template_sha256"]):
        raise ValueError("Tokenizer template differs from the qualified generation contract.")
    special = set(tokenizer.all_special_ids)
    pairs, records = [], []
    for case, row in zip(cases, bundle["pairs"], strict=True):
        messages = [{"role": "system", "content": case["system_text"]},
                    {"role": "user", "content": case["user_text"]}]
        prefix = tuple(tokenizer.apply_chat_template(messages, tokenize=True, return_dict=False,
            add_generation_prompt=True, enable_thinking=False))
        if not prefix or len(prefix) > generation_contract["max_input_tokens"]:
            raise ValueError("Reference prefix exceeds the original allowance; no truncation.")
        responses, lengths = [], {}
        for label in ("positive", "negative"):
            text = row[label]["text"]
            ids = tuple(tokenizer.encode(text, add_special_tokens=False))
            if not ids or len(ids) > generation_contract["max_new_tokens"]:
                raise ValueError("Reference response exceeds the original allowance; no truncation.")
            if tokenizer.decode(ids, skip_special_tokens=True) != text:
                raise ValueError("Reference text does not round-trip through the exact tokenizer.")
            if any(type(t) is not int or t < 0 for t in prefix + ids):
                raise ValueError("Malformed reference token IDs.")
            if any(token in special for token in ids):
                raise ValueError("Reference text unexpectedly contains a special token.")
            selected = tuple(i for i, token in enumerate(ids) if token not in special)
            responses.append(ResponseTokens(prefix, ids, selected))
            lengths[label] = len(ids)
        if responses[0].response_ids == responses[1].response_ids:
            raise ValueError("Reference responses tokenize identically.")
        pairs.append(ConstructionPair(case["case_id"], case["family_id"], *responses))
        records.append({"case_id": case["case_id"], "messages_sha256": identity(messages),
            "prefix_length": len(prefix), "response_lengths": lengths,
            "neutral_prefix_unchanged": True, "same_prefix_within_pair": True})
    values = tuple(pairs)
    return values, {"artifact_type": "AUTHORED_REFERENCE_TOKEN_INPUTS",
        "source": RULE["source"], "reference_bundle_sha256": identity(bundle),
        "construction_sha256": input_hash(values), "pair_count": len(values), "records": records,
        "position_policy": "exclude_special_tokens", "pooling": "response_mean",
        "research_model_loaded": False, "model_generation_calls": 0, "capture_forwards": 0,
        "research_execution_authorized": False, "calibration_authorized": False,
        "behavioral_steering_result": False, "f4_accessed": False}
