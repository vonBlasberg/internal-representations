"""Independent local replay; reuse the original full state/score/selection checks."""
from datetime import datetime, timezone
import json
from pathlib import Path

from . import expanded_calibration_run as run
from .expanded_audit import verify_delivery
from .depth_calibration_audit import verify_outcome
from .preparatory_phases import identity, save_new

def read(path):
    return json.loads(Path(path).read_bytes())

def audit():
    request,approval,package,payloads = run.load()
    returned = run.DIRECTORY/"launch/returned"
    terminal,count = verify_delivery(returned,request,package)
    if (terminal["status"] not in run.TERMINAL or terminal["process"]!={"returncode":0,"timed_out":False}):
        raise ValueError("Calibration failed or is indeterminate. Preserve diagnostics; do not retry.")
    evidence = returned/"evidence/attempt"
    if read(evidence/"started.json") != {"request":request,"approval":approval}:
        raise ValueError("The worker started with different input or authority.")
    from .generation_sensitivity import verify_tokenizer_files
    from transformers import AutoTokenizer
    qualification = request["program"]["qualification_plan"]
    snapshot = run.ROOT/"negotiation-steering/snapshots/qwen35-9b"/qualification["generation_contract"]["model_revision"]/"verified-snapshot"
    verify_tokenizer_files(qualification,snapshot,run.ROOT)
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot),local_files_only=True,trust_remote_code=False,use_fast=True)
    vectors = {name.removeprefix("request/directions/"):raw for name,raw in payloads.items() if name.startswith("request/directions/")}
    report = verify_outcome(request,evidence,tokenizer=tokenizer,direction_files=vectors)
    report.update(run_id=request["run_id"],request_sha256=identity(request),returned_files_verified=count,
                  checked_at_utc=datetime.now(timezone.utc).isoformat(),research_model_loaded=False,
                  model_generations=0,provider_contact=False,retry_performed=False,
                  protected_originals_unchanged=len(read(run.DIRECTORY/"preserved_before.json")))
    save_new(run.DIRECTORY/"terminal_audit.json",report)
    return report
