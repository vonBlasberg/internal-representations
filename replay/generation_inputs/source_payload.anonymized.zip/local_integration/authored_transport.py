"""One-use transport for the separately approved authored-reference amendment."""
import json
import os
from pathlib import Path
import sys
import tempfile
import time

from . import preparatory_transport as base
from . import qualification_transport as delivery
from .preparatory_phases import identity
from .authored_worker import check_request

ROOT = Path(__file__).resolve().parents[1]
CLAIMS = base.CLAIMS
EXTRA = ("local_integration/reference_construction.py", "local_integration/authored_worker.py",
    "local_integration/authored_transport.py", "local_integration/authored_run.py")


def build_package(request, direction_files=None):
    package, payloads = base.build_package(request, direction_files)
    for name in EXTRA:
        path = ROOT / name
        if path.is_symlink():
            raise ValueError("Source symlink refused.")
        payloads[name] = path.read_bytes()
    inventory = [{"path": name, "sha256": delivery.digest(data), "size_bytes": len(data)} for name, data in sorted(payloads.items())]
    package.update(files=inventory, inventory_sha256=identity(inventory),
        worker_module="local_integration.authored_worker",
        construction_source_sha256=identity(request["construction_source"]))
    return package, payloads


def verify(package, payloads, approval):
    request = base.verify(package, payloads, approval)
    if (package.get("worker_module") != "local_integration.authored_worker"
            or package.get("construction_source_sha256") != identity(request["construction_source"])
            or any(name not in payloads for name in EXTRA)):
        raise ValueError("Authored worker or source binding differs.")
    check_request(request, approval)
    return request


def remote_execute(approval, package, payloads, claim, commit):
    # The remote caller validates payload/authority first. Qualified artifact
    # files are checked by the child after materialization, before model loading.
    request = base.verify(package, payloads, approval)
    if (package.get("worker_module") != "local_integration.authored_worker"
            or package.get("construction_source_sha256") != identity(request["construction_source"])
            or approval.get("construction_source_sha256") != identity(request["construction_source"])
            or approval.get("authored_reference_amendment_authorized") is not True):
        raise PermissionError("Authored worker execution is not bound to this authority.")
    if not claim(request["run_id"], {"request_sha256": identity(request), "claimed_at": time.time()}):
        return {"status": "ALREADY_CLAIMED_NO_EXECUTION", "run_id": request["run_id"]}
    outer = Path(delivery.MOUNT) / delivery.result_prefix(request["run_id"])
    outer.mkdir(parents=True, exist_ok=False)
    delivery.write_new(outer / "claimed.json", delivery.encoded({"run_id": request["run_id"],
        "request_sha256": identity(request), "process_id": os.getpid()}))
    commit()
    try:
        root = Path(delivery.REMOTE)
        for name, data in payloads.items():
            delivery.write_new(root / delivery.safe_relative(name), data)
        delivery.write_new(root / "request/approval.json", delivery.encoded(approval))
        command = [sys.executable, "-m", "local_integration.authored_worker",
            str(root / "request/research.json"), str(root / "request/approval.json"), delivery.SNAPSHOT, str(outer / "attempt")]
        process = delivery.run_process(command, root, outer / "stdout.log", outer / "stderr.log", package["process_tree_timeout_seconds"])
        path = outer / "attempt/result.json"
        expected = request["stage"].upper() + "_COMPLETE"
        status = expected if process["returncode"] == 0 and path.is_file() and json.loads(path.read_text()).get("status") == expected else "FAILED_OR_INDETERMINATE_NO_RETRY"
        terminal = {"status": status, "run_id": request["run_id"], "stage": request["stage"], "process": process,
            "automatic_retry": False, "held_out_result": False, "f4_accessed": False, "deployment": False}
    except BaseException as error:
        terminal = {"status": "FAILED_NO_RETRY", "run_id": request["run_id"], "error_type": type(error).__name__, "error": str(error)}
    delivery.write_new(outer / "terminal.json", delivery.encoded(terminal))
    return delivery.publish_result(outer, terminal, package, commit)


def modal_driver(package, payloads):
    import modal
    requirements = [line.strip() for line in payloads[delivery.LOCK].decode().splitlines()
        if line.strip() and not line.startswith("#") and not line.startswith("./upstream")]
    stage = Path(tempfile.mkdtemp(prefix="orgsci-authored-image-"))
    for name, data in payloads.items():
        delivery.write_new(stage / name, data)
    image = (modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage), "/opt/preparatory-build", copy=True)
        .pip_install("/opt/preparatory-build/" + delivery.UPSTREAM, extra_options="--no-deps"))
    volume = modal.Volume.from_name(delivery.VOLUME, create_if_missing=False)
    app = modal.App("orgsci-authored-construction-calibration", include_source=False)

    @app.function(image=image, gpu="L40S", cpu=8.0, memory=65536, volumes={delivery.MOUNT: volume},
        timeout=package["process_tree_timeout_seconds"] + 60, retries=0, max_containers=1, max_inputs=1,
        block_network=True, serialized=True, include_source=False,
        env={"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
             "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false", "DO_NOT_TRACK": "1",
             "PYTHONDONTWRITEBYTECODE": "1", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
    def run(approval, package, payloads):
        import sys
        import modal
        sys.path.insert(0, "/opt/preparatory-build")
        from local_integration import authored_transport as transport
        claims = modal.Dict.from_name(transport.CLAIMS, create_if_missing=True)
        volume = modal.Volume.from_name(transport.delivery.VOLUME, create_if_missing=False)
        return transport.remote_execute(approval, package, payloads,
            lambda key, value: claims.put(key, value, skip_if_exists=True), volume.commit)
    return modal, app, run


def launch(request, approval, package, payloads, directory, *, driver=modal_driver):
    verify(package, payloads, approval)
    return base.launch(request, approval, package, payloads, directory, driver=driver)
