"""Check, launch once, retrieve and independently verify the authored amendment."""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import tempfile
import zipfile

from . import preparatory_run as previous
from . import qualification_transport as delivery
from . import authored_transport as transport
from .authored_worker import check_request, prepared_pairs
from .construction_program import ROOT, phase_plan
from .preparatory_phases import identity, save_new, checked_scores, check_construction_labels


def read(path):
    return json.loads(Path(path).read_text())


def load_request(directory):
    directory = Path(directory)
    request, package, approval = (read(directory / name) for name in ("request.json", "transport.json", "approval.json"))
    if delivery.file_digest(directory / "source_payload.zip") != read(directory / "source_archive.json")["sha256"]:
        raise ValueError("Saved source archive changed.")
    with zipfile.ZipFile(directory / "source_payload.zip") as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError("Duplicate archive names.")
        payloads = {name: archive.read(name) for name in archive.namelist()}
    transport.verify(package, payloads, approval)
    if json.loads(payloads["request/research.json"]) != request:
        raise ValueError("Local and transported request differ.")
    for name, data in payloads.items():
        if not name.startswith("request/") and (ROOT / name).read_bytes() != data:
            raise ValueError("A frozen source or artifact changed: " + name)
    return request, approval, package, payloads


def verified_delivery(directory, request, approval):
    returned = directory / "launch/returned"
    if read(returned / "retrieval.json")["status"] != "ALL_COMMITTED_FILES_VERIFIED":
        raise ValueError("Delivery was not fully verified.")
    manifest = read(returned / "manifest.json")
    for row in manifest["files"]:
        path = returned / "evidence" / delivery.safe_relative(row["path"])
        if path.stat().st_size != row["size_bytes"] or delivery.file_digest(path) != row["sha256"]:
            raise ValueError("A delivered file changed: " + row["path"])
    evidence = returned / "evidence/attempt"
    if (evidence / "started.json").exists():
        started = read(evidence / "started.json")
        if started != {"request": request, "approval": approval}:
            raise ValueError("Worker start record differs from the exact request and authority.")
    return evidence, manifest


def verify_capture(program, source, evidence, pairs, token_record):
    """Replay arithmetic, identities and controls without loading model weights."""
    import torch
    from steerability.algorithms.state_control.common.steering_vector import SteeringVector
    from .direction_construction import ConstructedDirections, ConstructionSpec, input_hash
    from .preparatory_worker import generate_control_files
    from .package_qualification import validate_plan

    if read(evidence / "authored_references.json") != source["references"]:
        raise ValueError("Captured reference provenance differs.")
    if read(evidence / "teacher_forcing_inputs.json") != token_record:
        raise ValueError("Captured authored inputs differ.")
    header = read(evidence / "constructed/construction.json")
    spec = read(evidence / "construction_spec.json")
    contract = validate_plan(program["qualification_plan"])
    expected = ConstructionSpec(contract.model_id, contract.model_revision, contract.model_type,
        tuple(tuple(s) for s in program["sites"]), spec["hidden_width"], tuple(p.pair_id for p in pairs), input_hash(pairs),
        tuple(f for f,p in program["family_partitions"].items() if p != "construction_fit"),
        program["pooling"], program["accumulation_dtype"], program["insertion_dtype"],
        contract.max_input_tokens + contract.max_new_tokens, False)
    if (identity(spec) != identity(asdict(expected)) or header["construction_spec"] != spec
            or header["construction_spec_sha256"] != identity(spec)):
        raise ValueError("Construction specification differs from the approved input/settings.")
    for key, value in {"pair_count": 4, "capture_forward_count": 8, "generation_calls": 0,
            "synthetic_test": False, "scientific_finding": False, "hooks_after": 0,
            "capture_cache": False, "capture_dtype": "bfloat16", "batch_size": 1,
            "estimator": "equal_pair_mean_positive_minus_negative"}.items():
        if header.get(key) != value:
            raise ValueError("Unexpected construction receipt: " + key)
    loaded = read(evidence / "capture_model/loaded_model.json")
    if (loaded["weights"]["entries_sha256"] != program["qualification_plan"]["model_weight_entries_sha256"]
            or loaded["admitted_model_id"] != contract.model_id
            or loaded["admitted_model_revision"] != contract.model_revision):
        raise ValueError("Captured model identity differs from qualification.")
    for pair, row in zip(pairs, header["pairs"], strict=True):
        if row["pair_id"] != pair.pair_id or row["family_id"] != pair.family_id:
            raise ValueError("Captured pair identity differs.")
        for label in ("positive", "negative"):
            response, saved = getattr(pair, label), row["responses"][label]
            required = {"prefix_ids": list(response.prefix_ids), "response_ids": list(response.response_ids),
                "selected_response_positions": list(response.selected_response_positions),
                "absolute_positions": [len(response.prefix_ids)+i for i in response.selected_response_positions]}
            if any(saved[k] != v for k,v in required.items()):
                raise ValueError("Captured response tokens/positions differ from authored inputs.")
    for name, row in header["files"].items():
        path = evidence / "constructed" / delivery.safe_relative(name)
        if path.stat().st_size != row["bytes"] or delivery.file_digest(path) != row["sha256"]:
            raise ValueError("Saved direction artifact changed.")
    raw = {}
    for layer, _ in program["sites"]:
        differences = []
        for row in header["pairs"]:
            positive, negative = [torch.tensor(row["responses"][label]["pooled_states"][str(layer)], dtype=torch.float32)
                for label in ("positive", "negative")]
            if positive.shape != (spec["hidden_width"],) or negative.shape != positive.shape:
                raise ValueError("Recorded state width differs.")
            differences.append(positive-negative)
        raw[layer] = (sum(differences, torch.zeros_like(differences[0])) / len(differences)).reshape(1,-1)
        if not torch.isfinite(raw[layer]).all() or not torch.isfinite(raw[layer].norm()) or raw[layer].norm() <= 0:
            raise ValueError("Zero or nonfinite reconstructed direction.")
        if raw[layer].numpy().astype("<f4").tobytes() != (evidence/"constructed"/f"layer-{layer}-raw.f32le").read_bytes():
            raise ValueError("Saved raw direction does not equal the recorded paired-state estimator.")
    vector = SteeringVector(model_type="qwen3_5", directions=raw)
    normalized = vector.normalized()
    for layer in raw:
        if normalized.directions[layer].numpy().astype("<f4").tobytes() != (evidence/"constructed"/f"layer-{layer}-normalized.f32le").read_bytes():
            raise ValueError("Saved normalized direction differs.")
    with tempfile.TemporaryDirectory() as location:
        replay_dir = Path(location)/"controls"
        generate_control_files(program, ConstructedDirections(vector, normalized, header), replay_dir)
        if read(replay_dir/"directions.json") != read(evidence/"directions/directions.json"):
            raise ValueError("Independent control manifest differs.")
        for path in replay_dir.iterdir():
            if path.read_bytes() != (evidence/"directions"/path.name).read_bytes():
                raise ValueError("Independent control bytes differ.")
    return {"authored_inputs_verified": True, "capture_arithmetic_verified": True,
        "raw_and_normalized_directions_verified": True, "controls_replayed_exactly": True,
        "pair_count": len(pairs), "generation_count": 2, "capture_forwards": 8}


def audit(directory):
    directory = Path(directory)
    request, approval, package, payloads = load_request(directory)
    evidence, manifest = verified_delivery(directory, request, approval)
    result = read(evidence/"result.json") if (evidence/"result.json").exists() else None
    if result is not None and (result.get("request_sha256") != identity(request)
            or result.get("run_id") != request["run_id"]
            or result.get("construction_source_sha256") != identity(request["construction_source"])):
        raise ValueError("Terminal result belongs to another request or construction source.")
    if request["stage"] == "calibration":
        return previous.audit(directory)
    program = request["program"]
    from transformers import AutoTokenizer
    snapshot = ROOT / "negotiation-steering/snapshots/qwen35-9b/c202236235762e1c871ad0ccb60c8ee5ba337b9a/verified-snapshot"
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False)
    pairs, token_record = prepared_pairs(request, tokenizer)
    plan = phase_plan(program, "construction_check")
    phase_path = evidence/"phases"/plan["run_id"]/"result.json"
    rows, checks = [], {}
    if phase_path.exists():
        phase = read(phase_path)
        scores = checked_scores(plan, program["cases"]["construction_check"], phase)
        from inspect_ai.log import read_eval_log
        for trial, row in zip(plan["trials"], phase["records"], strict=True):
            score = scores[row["trial_id"]]
            rows.append({"phase": "construction_check", "case_id": row["case_id"], "arm_id": row["arm_id"],
                "execution_status": row["execution_status"], "raw_response": row["raw_response"], "score": score})
            if row["execution_status"] != "COMPLETED":
                continue
            if score != row["score"]:
                raise ValueError("Independent separate-check score differs.")
            location, source = phase_path.parent/trial["trial_id"], row["source"]
            log_path = location/source["source_log_path"]
            if delivery.file_digest(log_path) != source["source_log_sha256"]:
                raise ValueError("Inspect source log changed.")
            log = read_eval_log(str(log_path))
            if log.status != "success" or len(log.samples or []) != 1 or log.samples[0].output.completion != row["raw_response"]:
                raise ValueError("Original Inspect log and recorded answer differ.")
            execution = read(location/"state_execution.json")["records"]
            ids = tokenizer.apply_chat_template(trial["messages"], tokenize=True, return_dict=False,
                add_generation_prompt=True, enable_thinking=False)
            inputs = read(location/"input.json")
            if (len(execution) != 1 or execution[0]["input_token_ids"] != ids or inputs["input_token_ids"] != ids
                    or execution[0]["generated_token_ids"] != source["generated_token_ids"]
                    or inputs["messages_sha256"] != trial["messages_sha256"]):
                raise ValueError("Actual generation/input records differ from the approved messages.")
            if read(location/"loaded_model.json")["weights"]["entries_sha256"] != program["qualification_plan"]["model_weight_entries_sha256"]:
                raise ValueError("Separate-check loaded weights differ.")
        checks["construction_check"] = check_construction_labels(plan, program["cases"]["construction_check"], phase)
        if read(evidence/"construction_check.json") != checks["construction_check"]:
            raise ValueError("Separate check differs on independent replay.")
    complete = result is not None and result.get("status") == "CONSTRUCTION_COMPLETE"
    if complete:
        terminal = read(evidence.parent/"terminal.json")
        if (terminal["status"] != "CONSTRUCTION_COMPLETE" or terminal["process"]["returncode"] != 0
                or terminal["process"].get("timed_out") is not False
                or checks.get("construction_check", {}).get("status") != "PASS"
                or result.get("generation_calls") != 2 or result.get("capture_forwards") != 8
                or result.get("authored_reference_count") != 8 or result.get("model_loads") != 3):
            raise ValueError("Successful outcome has inconsistent terminal gates or counts.")
        if (evidence/"phases"/phase_plan(program, "construction_fit")["run_id"]).exists():
            raise ValueError("Unexpected generated construction-fit phase.")
        checks.update(verify_capture(program, request["construction_source"], evidence, pairs, token_record))
    report = {"status": "CONSTRUCTION_AND_CONTROLS_VERIFIED" if complete else "STOPPED_NO_RETRY_RECORDS_VERIFIED",
        "run_id": request["run_id"], "request_sha256": identity(request),
        "construction_source_sha256": identity(request["construction_source"]),
        "worker_result": result, "checks": checks, "rows": rows,
        "returned_files_verified": len(manifest["files"]), "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "research_model_loaded": False, "f4_accessed": False, "retry_performed": False,
        "held_out_result": False, "further_execution_authorized": False}
    save_new(directory/"terminal_audit.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "launch", "retrieve", "audit"))
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    if args.action == "audit":
        report = audit(args.directory)
        result = {"status": report["status"], "checks": report["checks"], "completed_rows": len(report["rows"])}
    elif args.action == "check":
        request, _, _, payloads = load_request(args.directory)
        result = {"status": "AUTHORED_REQUEST_CHECK_PASS", "stage": request["stage"], "files": len(payloads), "provider_contacted": False}
    else:
        sys.path.append(str(ROOT.parent/"model-trace-observatory/.venv/lib/python3.12/site-packages"))
        if args.action == "retrieve":
            result = delivery.retrieve(args.directory/"launch")
        else:
            request, approval, package, payloads = load_request(args.directory)
            result = transport.launch(request, approval, package, payloads, args.directory/"launch")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
