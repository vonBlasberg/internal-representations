"""Fail-closed WP3 preparation and execution; preflight never loads a model.

The default inspection path is offline and read-only. Research execution requires a
final manifest, a separate exact-hash approval, a provisioned/attested worker, a
qualified orchestration route (or linked native-only amendment), and an approved
local snapshot attestation. This module never downloads a checkpoint.
"""
from __future__ import annotations

import datetime as dt
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import tempfile
import time
from typing import Any

from analysis.negotiation import score_response, validate_case
from worker.generation import (
    ExecutionResult,
    assert_exact_generation_parity,
    capture_only_with_receipts,
    generate_with_receipts,
    weight_free_hook_receipt,
)
from worker.qwen35_sites import ALL_DECODER_PATHS, PROBE_PATHS, SiteInventoryError, sites_for_paths, validate_site_inventory
from worker.receipts import summarize_cache, weight_fingerprint
from worker.transformers_native import resolve_module

ROOT = Path(__file__).resolve().parents[1]
MATERIALS = ROOT / "study" / "materials"
SHA256_HEX = frozenset("0123456789abcdef")


class WP3Error(RuntimeError):
    """Base class for controlled WP3 failures."""


class AuthorizationError(WP3Error):
    """Execution is not bound to an exact, complete, current approval."""


class ManifestError(WP3Error):
    """A manifest, snapshot, or referenced artifact is invalid."""


class GateFailure(WP3Error):
    """A declared mechanical gate failed; dependent work must stop."""

    def __init__(self, gate_id: str, message: str, *, technical: bool = False) -> None:
        super().__init__(message)
        self.gate_id = gate_id
        self.technical = technical


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ManifestError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_no_duplicate_keys)
    if not isinstance(value, dict):
        raise ManifestError(f"Expected a JSON object: {path}")
    return value


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def write_immutable_json(path: Path, value: Any) -> str:
    """Exclusively create one new evidence file; never overwrite an attempt."""
    encoded = _json_bytes(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError as exc:
        raise FileExistsError(f"Refusing to overwrite an evidence artifact: {path}") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    return hashlib.sha256(encoded).hexdigest()


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and set(value) <= SHA256_HEX


def _nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _token_id_set(value: Any) -> frozenset[int]:
    values = value if isinstance(value, list) else [value]
    if not values or any(isinstance(item, bool) or not isinstance(item, int) or item < 0 for item in values):
        raise ManifestError(f"Expected nonnegative integer token IDs, got {value!r}")
    return frozenset(values)


def verify_terminal_reason(generated_token_ids: list[int], eos_token_ids: Any, max_new_tokens: int) -> str:
    """Verify EOS/max-token termination; never infer an early stop from length alone."""
    if isinstance(max_new_tokens, bool) or not isinstance(max_new_tokens, int) or max_new_tokens < 1:
        raise ManifestError("max_new_tokens must be a positive integer.")
    if not generated_token_ids:
        raise GateFailure("RAW_OUTPUT", "Generation returned no new tokens.", technical=True)
    if any(isinstance(item, bool) or not isinstance(item, int) or item < 0 for item in generated_token_ids):
        raise GateFailure("RAW_OUTPUT", "Generated token IDs are invalid.", technical=True)
    if len(generated_token_ids) > max_new_tokens:
        raise GateFailure("RESOURCES", "Generation exceeded max_new_tokens.", technical=True)
    eos = _token_id_set(eos_token_ids)
    eos_positions = [index for index, token in enumerate(generated_token_ids) if token in eos]
    if eos_positions and eos_positions[-1] != len(generated_token_ids) - 1:
        raise GateFailure("RAW_OUTPUT", "An EOS token occurred before the final generated token.", technical=True)
    if generated_token_ids[-1] in eos:
        return "eos"
    if len(generated_token_ids) == max_new_tokens:
        return "max_new_tokens"
    raise GateFailure("RAW_OUTPUT", "Generation stopped early without a terminal EOS token; the stop reason is not established.", technical=True)


def parser_token_ids(generated_token_ids: list[int], terminal_reason: str) -> list[int]:
    """Remove exactly one terminal EOS token, leaving every other token untouched."""
    if terminal_reason == "eos":
        if not generated_token_ids:
            raise ManifestError("Cannot remove EOS from an empty output.")
        return generated_token_ids[:-1]
    if terminal_reason == "max_new_tokens":
        return list(generated_token_ids)
    raise ManifestError(f"Unsupported verified terminal reason: {terminal_reason!r}")


def validate_trace_schedule(
    receipt: dict[str, Any],
    *,
    expected_site_ids: list[str],
    new_token_count: int | None = None,
    expected_phase: str | None = None,
    coefficient: float | None = None,
    nonzero_edit: bool | None = None,
) -> dict[str, Any]:
    """Check site/call/phase coverage and bounded realized-edit receipts."""
    trace = receipt.get("trace") or {}
    captures = trace.get("captures")
    if not isinstance(captures, list):
        raise GateFailure("CAPTURE_CONTRACT", "Missing bounded capture list.", technical=True)
    if trace.get("raw_full_hidden_states_retained") is not False or trace.get("hook_registry_restored") is not True:
        raise GateFailure("ISOLATION", "Trace retention or hook-restoration contract failed.")
    grouped = {site_id: [] for site_id in expected_site_ids}
    for capture in captures:
        site_id = capture.get("site_id")
        if site_id not in grouped:
            raise GateFailure("CAPTURE_CONTRACT", f"Unexpected capture site: {site_id}")
        grouped[site_id].append(capture)
        if capture.get("selected_value_count", 4097) > 4096 or capture.get("raw_state_retained") is not False:
            raise GateFailure("CAPTURE_CONTRACT", "Capture exceeds its bounded selected-state contract.")
        if capture.get("finite") is not True:
            raise GateFailure("CAPTURE_CONTRACT", "Nonfinite captured state or edit.")
        if coefficient is not None and capture.get("coefficient") != coefficient:
            raise GateFailure("CAPTURE_CONTRACT", "Capture coefficient differs from the manifest.")
        if nonzero_edit is not None and capture.get("nonzero_edit") is not nonzero_edit:
            raise GateFailure("CAPTURE_CONTRACT", "Capture nonzero-edit flag differs from the operation.")
        if nonzero_edit is False and (capture.get("realized_max_abs") != 0.0 or capture.get("pre_sha256") != capture.get("post_sha256")):
            raise GateFailure("QG-04_ZERO_EDIT_EQUIVALENCE", "A recording/zero edit was not an exact no-op.")
        if nonzero_edit is True and (capture.get("realized_max_abs", 0.0) <= 0.0 or capture.get("realized_l2", 0.0) <= 0.0):
            raise GateFailure("REALIZED_EDIT", "A requested nonzero edit was not realized after insertion-dtype casting.")
    if new_token_count is not None:
        # Prefill produces token 1; only subsequent tokens require decode forwards.
        expected_calls = new_token_count
        if len(captures) != len(expected_site_ids) * expected_calls:
            raise GateFailure("CAPTURE_CONTRACT", "Generation trace does not cover prefill plus every decode step at every declared site.")
        for site_id, selected in grouped.items():
            if len(selected) != expected_calls:
                raise GateFailure("CAPTURE_CONTRACT", f"Incomplete generation trace at {site_id}.")
            if [item.get("call_index") for item in selected] != list(range(expected_calls)):
                raise GateFailure("CAPTURE_CONTRACT", f"Nonsequential call indices at {site_id}.")
            if [item.get("prefill_or_decode") for item in selected] != ["prefill"] + ["decode"] * (new_token_count - 1):
                raise GateFailure("CAPTURE_CONTRACT", f"Wrong prefill/decode schedule at {site_id}.")
    elif expected_phase is not None:
        if len(captures) != len(expected_site_ids):
            raise GateFailure("CAPTURE_CONTRACT", "Capture-only operation has the wrong number of traces.")
        for site_id, selected in grouped.items():
            if len(selected) != 1 or selected[0].get("call_index") != 0 or selected[0].get("prefill_or_decode") != expected_phase:
                raise GateFailure("CAPTURE_CONTRACT", f"Wrong {expected_phase} capture at {site_id}.")
    else:
        raise ManifestError("Trace validation requires a generation length or capture-only phase.")
    for selected in grouped.values():
        for capture in selected:
            positions = capture.get("logical_token_positions")
            attestation = capture.get("position_metadata_attestation", {})
            if not isinstance(positions, list) or not positions or attestation.get("selected_values_verified_from_metadata") is not True or attestation.get("local_index_fallback_forbidden") is not True:
                raise GateFailure("CAPTURE_CONTRACT", "Logical positions were not verified from actual metadata.")
    return {"status": "PASS", "capture_count": len(captures), "site_ids": expected_site_ids, "new_token_count": new_token_count, "phase": expected_phase}


def _state_kind_counts(value: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    def walk(item: Any) -> None:
        if isinstance(item, dict):
            kind = item.get("state_kind")
            if isinstance(kind, str) and item.get("kind") == "tensor_native_byte_summary":
                counts[kind] = counts.get(kind, 0) + 1
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
    walk(value)
    return counts


class WP3Runner:
    """One approved WP3 workload; no retries and no implicit network access."""

    def __init__(
        self,
        *,
        manifest_path: Path,
        approval_path: Path | None = None,
        snapshot_root: Path | None = None,
        snapshot_attestation_path: Path | None = None,
        output_root: Path | None = None,
        run_id: str | None = None,
    ) -> None:
        self.manifest_path = Path(manifest_path).resolve()
        self.approval_path = Path(approval_path).resolve() if approval_path else None
        self.snapshot_root = Path(snapshot_root).resolve() if snapshot_root else None
        self.snapshot_attestation_path = Path(snapshot_attestation_path).resolve() if snapshot_attestation_path else None
        self.output_root = Path(output_root).resolve() if output_root else ROOT / "verification" / "wp3_runs" / "unassigned"
        self.manifest = load_json(self.manifest_path)
        self.manifest_sha256 = file_sha256(self.manifest_path)
        self.approval = load_json(self.approval_path) if self.approval_path and self.approval_path.is_file() else None
        self.run_id = run_id
        self.model = None
        self.tokenizer = None
        self.direction = None
        self.current_operation: str | None = None
        self.completed: set[str] = set()
        self.receipts: dict[str, dict[str, Any]] = {}
        self.scores: dict[str, dict[str, Any]] = {}
        self.raw_hashes: dict[str, str] = {}
        self.gates: dict[str, dict[str, Any]] = {}
        self.cpu_inputs: dict[str, dict[str, Any]] = {}
        self.input_receipt_paths: dict[str, Path] = {}
        self.cases: dict[str, dict[str, Any]] = {}
        self.total_generation_calls = 0
        self.total_new_tokens = 0
        self.total_capture_operations = 0
        self.total_supporting_prefills = 0
        self.gpu_seconds = 0.0
        self.model_load_count = 0
        self.reference_weight_entries_sha256: str | None = None
        self.expected_generation_call: dict[str, Any] | None = None
        self.snapshot_report: dict[str, Any] | None = None
        self.identity_report: dict[str, Any] | None = None
        self.qf01_receipt: dict[str, Any] | None = None
        self.qf02_receipt: dict[str, Any] | None = None
        self.started_monotonic = 0.0

    def _referenced(self, key: str) -> Path:
        reference = self.manifest.get("references", {}).get(key)
        if not isinstance(reference, dict) or not isinstance(reference.get("path"), str):
            raise ManifestError(f"Missing safe reference: {key}")
        path = (ROOT / reference["path"]).resolve()
        if ROOT.resolve() not in path.parents or not path.is_file():
            raise ManifestError(f"Reference is missing or escapes the package: {key}")
        if not _is_sha256(reference.get("sha256")) or file_sha256(path) != reference["sha256"]:
            raise ManifestError(f"Reference hash mismatch: {key}")
        return path

    def _authorization_errors(self) -> list[str]:
        errors: list[str] = []
        def require(condition: bool, label: str) -> None:
            if not condition:
                errors.append(label)
        m = self.manifest
        require(m.get("artifact_type") == "WP3_MECHANICAL_QUALIFICATION_MANIFEST", "wrong manifest artifact type")
        require(m.get("status") == "FINAL_PENDING_EXTERNAL_EXECUTION_APPROVAL", "manifest is not finalized for external execution approval")
        require(m.get("execution_status") == "PENDING_EXTERNAL_EXECUTION_APPROVAL", "manifest execution status is not the immutable external-approval state")
        require(m.get("phase") == "qualification", "manifest phase is not qualification")
        require(m.get("execution_authorized") is False, "manifest must not activate its own execution")
        require(m.get("provider_job_contact_authorized") is False, "manifest must not activate provider contact without the external approval")
        require(m.get("deployment_authorized") is False, "deployment must remain unauthorized")
        require(m.get("research_model_execution") is False and m.get("model_execution") is False, "manifest must describe a not-yet-run qualification")
        require(m.get("scientific_evidence") is False and m.get("qualification_status") == "NOT_RUN", "manifest cannot begin with a scientific or qualification claim")
        model = m.get("model", {})
        require(model.get("model_id") == "Qwen/Qwen3.5-9B", "unexpected model ID")
        require(model.get("revision") == "c202236235762e1c871ad0ccb60c8ee5ba337b9a", "unexpected model revision")
        require(model.get("model_dtype") == "bfloat16" and model.get("trust_remote_code") is False, "BF16/no-remote-code route is not fixed")
        require(model.get("route") == "text_only" and model.get("thinking_disabled") is True and model.get("substitution_allowed") is False, "model route or substitution policy changed")
        snapshot = m.get("model_snapshot", {})
        require(snapshot.get("status") == "ATTESTED" and _is_sha256(snapshot.get("attestation_sha256")), "approved local snapshot attestation is not bound into the manifest")
        generation = m.get("generation", {})
        try:
            _token_id_set(generation.get("pad_token_id"))
            checkpoint_eos = _token_id_set(generation.get("eos_token_id_from_checkpoint_config"))
            tokenizer_eos = _token_id_set(generation.get("tokenizer_eos_token_id"))
            effective_eos = _token_id_set(generation.get("generation_eos_token_ids"))
            require(effective_eos == checkpoint_eos | tokenizer_eos, "effective generation EOS IDs must equal the explicitly declared checkpoint/tokenizer union")
        except (ManifestError, TypeError):
            errors.append("tokenizer pad/checkpoint/effective EOS IDs remain unresolved")
        require(m.get("effective_generation_configuration", {}).get("status") == "ATTEST_ON_APPROVED_LOAD_BEFORE_GENERATION", "effective-generation load-time attestation is not finalized")
        runtime = m.get("runtime", {})
        require(runtime.get("status") == "LOCKED_AND_ATTESTED", "worker runtime is not locked and attested")
        for key in ("selected_transformers_version", "selected_pytorch_version", "selected_cuda_version", "selected_python_version", "container_image_id", "container_image_id_kind", "container_image_recipe_sha256"):
            require(_nonempty(runtime.get(key)), f"runtime field unresolved: {key}")
        routes = runtime.get("selected_kernel_versions_and_routes", {})
        require(isinstance(routes, dict) and routes.get("status") == "ATTESTED_ON_LOCKED_WORKER", "actual kernel versions/routes are not attested on the locked worker")
        require(_is_sha256(runtime.get("transitive_requirements_lock_sha256")), "transitive runtime lock hash unresolved")
        require(runtime.get("authoritative_backend") == "native_pytorch_transformers" and runtime.get("attn_implementation") == "eager", "authoritative backend/eager attention changed")
        require(runtime.get("runtime_hub_kernel_downloads_allowed") is False and runtime.get("network_during_execution_after_approved_download") is False, "execution network policy changed")
        worker = m.get("worker", {})
        require(worker.get("selection_status") == "PROVISIONED_ATTESTED", "worker is not provisioned and attested")
        require(_nonempty(worker.get("instance_id")) and _nonempty(worker.get("driver_version")), "actual instance/driver unresolved")
        require(worker.get("provider") == "Modal" and worker.get("actual_gpu_name") == "NVIDIA L40S", "actual worker is not the approved Modal NVIDIA L40S")
        require(_number(worker.get("actual_usable_vram_gib")) and worker.get("actual_usable_vram_gib") > 0, "actual VRAM unresolved")
        require(_number(worker.get("actual_host_ram_gb")) and worker.get("actual_host_ram_gb") >= 64, "actual host RAM is unresolved or below the declared minimum")
        require(worker.get("actual_availability_verified") is True, "actual worker availability is not attested")
        require(_is_sha256(worker.get("worker_profile_sha256")), "actual worker-profile hash unresolved")
        require(_nonempty(worker.get("provisioning_approval_id")), "separate provisioning approval ID unresolved")
        orchestration = m.get("orchestration", {})
        steer_qualified = orchestration.get("status") == "QUALIFIED" and orchestration.get("selected_route") == "steerability" and _nonempty(orchestration.get("qualified_source_revision")) and _is_sha256(orchestration.get("qualification_receipt_sha256"))
        native_linked = orchestration.get("selected_route") == "native_only" and _nonempty(orchestration.get("native_fallback_amendment_path")) and _is_sha256(orchestration.get("native_fallback_amendment_sha256"))
        native_pending = native_linked and orchestration.get("status") == "NATIVE_ONLY_AMENDMENT_PENDING_EXTERNAL_EXECUTION_APPROVAL"
        native_approved = native_linked and orchestration.get("status") == "NATIVE_ONLY_AMENDMENT_APPROVED"
        require(steer_qualified or native_pending or native_approved, "orchestration is neither qualified nor covered by a linked native-only amendment")
        caps = m.get("workload_hard_caps", {})
        require(caps.get("maximum_generation_calls") == 7 and caps.get("maximum_total_new_tokens") == 1120, "generation workload caps changed")
        require(caps.get("maximum_cost") == 100.0 and caps.get("cost_currency") == "EUR", "WP3 cap must remain EUR 100")
        require(caps.get("automatic_paid_overage") is False and caps.get("hidden_or_outcome_dependent_retries") is False, "overage/retry prohibition changed")
        require(self.approval is not None, "separate research-execution approval document is missing")
        if self.approval is not None:
            a = self.approval
            require(a.get("artifact_type") == "WP3_RESEARCH_EXECUTION_APPROVAL", "wrong approval artifact type")
            require(a.get("execution_authorized") is True and a.get("research_model_execution_authorized") is True, "external approval does not authorize qualification execution")
            require(a.get("research_checkpoint_download_authorized") is False, "execution approval must not reopen or authorize checkpoint downloads")
            require(a.get("provider_job_contact_authorized") is True and a.get("deployment_authorized") is False, "approval provider/deployment scope is invalid")
            require(a.get("approved_by") == "Anonymous owner" and a.get("payer") == "Anonymous owner" and a.get("release_authority") == "Anonymous owner", "Anonymous owner must be approver, payer, and release authority")
            require(_nonempty(a.get("approved_at_utc")), "external approval timestamp is missing")
            require(a.get("phase") == "qualification", "approval phase mismatch")
            require(a.get("model_id") == model.get("model_id") and a.get("model_revision") == model.get("revision"), "approval model identity mismatch")
            require(a.get("worker_name") == worker.get("worker_name") and a.get("provider") == worker.get("provider"), "approval worker/provider mismatch")
            require(a.get("maximum_cost") == 100.0 and a.get("cost_currency") == "EUR", "approval numeric cap/currency mismatch")
            require(a.get("manifest_sha256_bound_by_approval") == self.manifest_sha256, "approval is not bound to the exact manifest file SHA-256")
            require(a.get("runtime_lock_sha256") == runtime.get("transitive_requirements_lock_sha256"), "approval runtime-lock hash mismatch")
            require(a.get("worker_profile_sha256") == worker.get("worker_profile_sha256"), "approval worker-profile hash mismatch")
            require(a.get("snapshot_attestation_sha256") == snapshot.get("attestation_sha256"), "approval snapshot-attestation hash mismatch")
            require(a.get("provisioning_approval_id") == worker.get("provisioning_approval_id"), "approval does not reference the same separate provisioning approval")
            if native_pending:
                require(a.get("orchestration_route") == "native_only", "external approval does not activate the native-only route")
                require(a.get("native_fallback_amendment_path") == orchestration.get("native_fallback_amendment_path"), "approval native amendment path mismatch")
                require(a.get("native_fallback_amendment_sha256") == orchestration.get("native_fallback_amendment_sha256"), "approval native amendment hash mismatch")
            manifest_approval = m.get("approval_required", {})
            require(manifest_approval.get("manifest_sha256_bound_by_approval") is None, "manifest must not embed a self-referential file hash; use the external approval binding")
            require(manifest_approval.get("approved_at_utc") is None, "manifest must remain unchanged; record approval time only in the external approval")
            for key in ("approval_id", "approved_by", "phase", "worker_name", "provider", "payer", "release_authority", "maximum_cost", "cost_currency", "runtime_lock_sha256", "worker_profile_sha256"):
                require(manifest_approval.get(key) is not None and manifest_approval.get(key) == a.get(key), f"manifest/approval field mismatch: {key}")
        for key in ("model_source_inventory", "module_state_cache_map", "adapter_contract", "resource_authorization", "m0_tiny_model_qualification", "m0_independent_validation"):
            try:
                self._referenced(key)
            except (ManifestError, OSError) as exc:
                errors.append(f"reference {key}: {exc}")
        return errors

    def verify_execution_authorization(self) -> dict[str, Any]:
        errors = self._authorization_errors()
        if errors:
            raise AuthorizationError("WP3 execution refused: " + "; ".join(errors))
        return {
            "status": "EXACT_EXECUTION_APPROVAL_VERIFIED",
            "approval_id": self.approval["approval_id"],
            "provisioning_approval_id": self.approval["provisioning_approval_id"],
            "manifest_sha256": self.manifest_sha256,
            "model_revision": self.manifest["model"]["revision"],
            "worker_profile_sha256": self.manifest["worker"]["worker_profile_sha256"],
            "runtime_lock_sha256": self.manifest["runtime"]["transitive_requirements_lock_sha256"],
            "maximum_cost": 100.0,
            "cost_currency": "EUR",
            "research_model_execution_performed_by_this_check": False,
        }

    def preflight(self) -> dict[str, Any]:
        """Read-only offline report; never imports PyTorch/Transformers or writes output."""
        errors = self._authorization_errors()
        site_report: dict[str, Any] | None = None
        try:
            module_map = load_json(self._referenced("module_state_cache_map"))
            site_report = validate_site_inventory(self.manifest, module_map)
        except (ManifestError, SiteInventoryError, OSError) as exc:
            errors.append(f"site inventory: {exc}")
        return {
            "artifact_type": "WP3_OFFLINE_PREFLIGHT",
            "status": "READY_ONLY_IF_SEPARATELY_AUTHORIZED" if not errors else "BLOCKED_NOT_EXECUTABLE",
            "execution_ready": not errors,
            "blockers": errors,
            "manifest_sha256": self.manifest_sha256,
            "site_inventory": site_report,
            "offline_preflight_only": True,
            "output_written": False,
            "provider_contacted": False,
            "research_weights_downloaded": False,
            "research_model_execution": False,
            "model_execution": False,
            "scientific_evidence": False,
        }

    def verify_snapshot(self) -> dict[str, Any]:
        """Hash an approved local snapshot; never call a Hub or download API."""
        if self.snapshot_root is None or self.snapshot_attestation_path is None:
            raise ManifestError("An explicit local snapshot and snapshot attestation are required.")
        if not self.snapshot_root.is_dir() or not self.snapshot_attestation_path.is_file():
            raise ManifestError("Approved local snapshot or attestation is missing.")
        attestation_sha256 = file_sha256(self.snapshot_attestation_path)
        if attestation_sha256 != self.manifest.get("model_snapshot", {}).get("attestation_sha256"):
            raise ManifestError("Snapshot attestation differs from the hash bound into the manifest and external approval.")
        attestation = load_json(self.snapshot_attestation_path)
        if attestation.get("artifact_type") != "WP3_MODEL_SNAPSHOT_ATTESTATION":
            raise ManifestError("Wrong snapshot-attestation artifact type.")
        if attestation.get("model_id") != self.manifest["model"]["model_id"] or attestation.get("model_revision") != self.manifest["model"]["revision"]:
            raise ManifestError("Snapshot model/revision differs from the approved manifest.")
        records = attestation.get("files")
        if not isinstance(records, list) or not records:
            raise ManifestError("Snapshot attestation has no file inventory.")
        expected: dict[str, dict[str, Any]] = {}
        total_bytes = 0
        for record in records:
            name = record.get("path")
            if not isinstance(name, str) or not name or name.startswith("/") or ".." in Path(name).parts:
                raise ManifestError(f"Unsafe snapshot path: {name!r}")
            if name in expected or not _is_sha256(record.get("sha256")):
                raise ManifestError(f"Duplicate or unhashed snapshot file: {name}")
            path = self.snapshot_root / name
            if not path.is_file():
                raise ManifestError(f"Approved snapshot file is missing: {name}")
            size = path.stat().st_size
            if size != record.get("size_bytes") or file_sha256(path) != record["sha256"]:
                raise ManifestError(f"Snapshot identity mismatch: {name}")
            expected[name] = record
            total_bytes += size
        actual = {path.relative_to(self.snapshot_root).as_posix() for path in self.snapshot_root.rglob("*") if path.is_file()}
        if actual != set(expected):
            raise ManifestError(f"Snapshot file set differs from attestation; unlisted={sorted(actual-set(expected))}, missing={sorted(set(expected)-actual)}")
        if total_bytes != attestation.get("total_bytes"):
            raise ManifestError("Snapshot attestation byte total mismatch.")
        maximum_bytes = int(self.manifest["workload_hard_caps"]["maximum_model_download_gib"] * (1024 ** 3))
        if total_bytes > maximum_bytes:
            raise GateFailure("RESOURCES", "Approved snapshot exceeds the model-download byte cap.")
        self.snapshot_report = {
            "status": "EXACT_LOCAL_SNAPSHOT_VERIFIED",
            "snapshot_attestation_sha256": attestation_sha256,
            "snapshot_inventory_sha256": canonical_sha256(records),
            "model_id": attestation["model_id"],
            "model_revision": attestation["model_revision"],
            "file_count": len(records),
            "total_bytes": total_bytes,
            "download_performed_by_runner": False,
            "network_used": False,
        }
        return self.snapshot_report


    def _check_wall_clock(self) -> None:
        if self.started_monotonic:
            elapsed = time.monotonic() - self.started_monotonic
            if elapsed > self.manifest["workload_hard_caps"]["maximum_wall_hours"] * 3600:
                raise GateFailure("RESOURCES", "WP3 wall-clock cap exceeded; no retry or overage is permitted.")

    def _resource_usage(self, started: float) -> dict[str, Any]:
        import torch
        elapsed = time.monotonic() - started
        self.gpu_seconds += elapsed
        usage = {
            "elapsed_seconds": elapsed,
            "host_max_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) * 1024,
            "gpu_peak_allocated_bytes": int(torch.cuda.max_memory_allocated(0)),
            "gpu_peak_reserved_bytes": int(torch.cuda.max_memory_reserved(0)),
            "gpu_time_cap_exceeded": self.gpu_seconds > self.manifest["workload_hard_caps"]["maximum_gpu_hours"] * 3600,
            "provider_cost_eur_measured_by_runtime": None,
            "provider_cost_reconciliation_required": True,
        }
        return usage

    def _load_tokenizer(self) -> None:
        """Load only text tokenizer state; never initialize a multimodal processor."""
        if self.tokenizer is not None:
            return
        from transformers import AutoTokenizer
        common = {"local_files_only": True, "trust_remote_code": False}
        self.tokenizer = AutoTokenizer.from_pretrained(str(self.snapshot_root), use_fast=True, **common)
        self.tokenizer.padding_side = "left"

    def _load_model(self) -> None:
        if self.model is not None:
            return
        import torch
        from transformers import Qwen3_5ForConditionalGeneration
        if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
            raise GateFailure("IDENTITY", "The approved worker must expose exactly one usable CUDA GPU.", technical=True)
        if not torch.cuda.is_bf16_supported():
            raise GateFailure("IDENTITY", "The actual GPU does not report BF16 support.", technical=True)
        self.model = Qwen3_5ForConditionalGeneration.from_pretrained(
            str(self.snapshot_root),
            local_files_only=True,
            trust_remote_code=False,
            dtype=torch.bfloat16,
            attn_implementation="eager",
        )
        generation = self.manifest["generation"]
        self.model.generation_config.pad_token_id = generation["pad_token_id"]
        self.model.generation_config.eos_token_id = list(generation["generation_eos_token_ids"])
        self.model.to("cuda:0")
        self.model.eval()
        self.model.set_attn_implementation("eager")
        self.model_load_count += 1

    def _reload_model(self) -> None:
        import torch
        self.model = None
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(0)
        self._load_model()

    def _resolved_generation_call(self) -> dict[str, Any]:
        generation = self.manifest["generation"]
        return {
            "do_sample": False,
            "num_beams": 1,
            "num_return_sequences": 1,
            "use_cache": True,
            "cache_implementation": "dynamic",
            "max_new_tokens": generation["max_new_tokens"],
            "min_new_tokens": generation["min_new_tokens"],
            "return_dict_in_generate": True,
            "output_scores": True,
            "output_hidden_states": False,
            "output_attentions": False,
            "eos_token_id": generation["generation_eos_token_ids"],
        }

    def _attest_identity(self) -> dict[str, Any]:
        """Attest the actual loaded object before any generation or capture."""
        import importlib.util
        import torch
        import transformers
        runtime = self.manifest["runtime"]
        worker = self.manifest["worker"]
        actual_versions = {
            "python": platform.python_version(),
            "pytorch": torch.__version__,
            "transformers": transformers.__version__,
            "cuda": torch.version.cuda,
        }
        expected_versions = {
            "python": runtime["selected_python_version"],
            "pytorch": runtime["selected_pytorch_version"],
            "transformers": runtime["selected_transformers_version"],
            "cuda": runtime["selected_cuda_version"],
        }
        if actual_versions != expected_versions:
            raise GateFailure("IDENTITY", f"Loaded runtime differs from approval: {actual_versions} != {expected_versions}", technical=True)
        gpu_name = torch.cuda.get_device_name(0)
        if gpu_name != worker["actual_gpu_name"]:
            raise GateFailure("IDENTITY", f"Actual GPU {gpu_name!r} differs from approved {worker['actual_gpu_name']!r}.", technical=True)
        total_gib = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
        if not math.isclose(total_gib, worker["actual_usable_vram_gib"], rel_tol=0.0, abs_tol=0.1):
            raise GateFailure("IDENTITY", "Actual GPU memory differs from the worker-profile attestation.", technical=True)
        try:
            driver = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                text=True, timeout=30,
            ).strip()
        except (OSError, subprocess.SubprocessError) as exc:
            raise GateFailure("IDENTITY", f"Cannot attest the actual NVIDIA driver: {exc}", technical=True) from exc
        if driver != worker["driver_version"]:
            raise GateFailure("IDENTITY", "Actual NVIDIA driver differs from the approved worker profile.", technical=True)
        if self.model.dtype != torch.bfloat16 or getattr(self.model.config, "_attn_implementation", None) != "eager":
            raise GateFailure("IDENTITY", "Loaded model is not BF16 with eager attention.", technical=True)
        if self.model.config.architectures != [self.manifest["model"]["architecture"]]:
            raise GateFailure("IDENTITY", "Loaded architecture differs from the manifest.", technical=True)
        generation = self.manifest["generation"]
        checkpoint_eos = _token_id_set(generation["eos_token_id_from_checkpoint_config"])
        declared_tokenizer_eos = _token_id_set(generation["tokenizer_eos_token_id"])
        effective_eos = _token_id_set(generation["generation_eos_token_ids"])
        tokenizer_eos = _token_id_set(self.tokenizer.eos_token_id)
        model_eos = _token_id_set(self.model.generation_config.eos_token_id)
        config_eos = _token_id_set(self.model.config.text_config.eos_token_id)
        if effective_eos != checkpoint_eos | declared_tokenizer_eos:
            raise GateFailure("IDENTITY", "Declared effective EOS IDs are not the approved checkpoint/tokenizer union.", technical=True)
        if tokenizer_eos != declared_tokenizer_eos or model_eos != effective_eos or config_eos != checkpoint_eos:
            raise GateFailure("IDENTITY", f"EOS source/effective mismatch requires STOP_AND_AMEND_MANIFEST: checkpoint={sorted(checkpoint_eos)}, declared_tokenizer={sorted(declared_tokenizer_eos)}, effective={sorted(effective_eos)}, loaded_tokenizer={sorted(tokenizer_eos)}, generation_config={sorted(model_eos)}, text_config={sorted(config_eos)}")
        manifest_pad = _token_id_set(generation["pad_token_id"])
        tokenizer_pad = _token_id_set(self.tokenizer.pad_token_id)
        model_pad = _token_id_set(self.model.generation_config.pad_token_id)
        if tokenizer_pad != manifest_pad or model_pad != manifest_pad:
            raise GateFailure("IDENTITY", f"PAD mismatch requires STOP_AND_AMEND_MANIFEST: manifest={sorted(manifest_pad)}, tokenizer={sorted(tokenizer_pad)}, generation_config={sorted(model_pad)}")
        if self.tokenizer.padding_side != "left":
            raise GateFailure("IDENTITY", "Tokenizer padding side is not left.")
        template = getattr(self.tokenizer, "chat_template", None)
        if not isinstance(template, str) or not template:
            raise GateFailure("IDENTITY", "Loaded tokenizer has no chat template.", technical=True)
        template_path = self.snapshot_root / "chat_template.jinja"
        if not template_path.is_file() or template.encode("utf-8") != template_path.read_bytes():
            raise GateFailure("IDENTITY", "Loaded chat template differs from the approved local template bytes.", technical=True)
        if file_sha256(template_path) != self.manifest["input_preparation"]["chat_template_sha256"]:
            raise GateFailure("IDENTITY", "Chat-template SHA-256 differs from the manifest.", technical=True)
        loaded_generation = self.model.generation_config.to_dict()
        self.expected_generation_call = self._resolved_generation_call()
        resolved_generation = {**loaded_generation, **self.expected_generation_call}
        for key, expected in self.expected_generation_call.items():
            if resolved_generation.get(key) != expected:
                raise GateFailure("IDENTITY", f"Resolved generation field {key} differs from the approved call.", technical=True)
        if resolved_generation.get("do_sample") is not False or resolved_generation.get("num_beams") != 1:
            raise GateFailure("IDENTITY", "Effective decoding is not greedy single-sequence generation.")
        module_map = load_json(self._referenced("module_state_cache_map"))
        modules = []
        for index, path in enumerate(ALL_DECODER_PATHS):
            module = resolve_module(self.model, path)
            expected_kind = module_map["layers"][index]["block_type"]
            if type(module).__name__ != "Qwen3_5DecoderLayer" or getattr(module, "block_type", None) != expected_kind:
                raise GateFailure("IDENTITY", f"Research module/block-type mismatch at {path}.", technical=True)
            modules.append({"path": path, "class": type(module).__name__, "block_type": module.block_type})
        weights = weight_fingerprint(self.model)
        self.reference_weight_entries_sha256 = weights["entries_sha256"]
        self.identity_report = {
            "artifact_type": "WP3_LOADED_IDENTITY_AND_EFFECTIVE_CONFIG",
            "status": "ATTESTED_ON_ACTUAL_WORKER",
            "manifest_sha256": self.manifest_sha256,
            "model_id": self.manifest["model"]["model_id"],
            "model_revision": self.manifest["model"]["revision"],
            "snapshot": self.snapshot_report,
            "actual_runtime_versions": actual_versions,
            "actual_gpu": {"name": gpu_name, "total_memory_gib": total_gib, "driver_version": driver, "bf16_supported": True},
            "kernel_route_attestation": runtime["selected_kernel_versions_and_routes"],
            "optional_kernel_module_visibility": {name: importlib.util.find_spec(name) is not None for name in ("causal_conv1d", "fla", "triton")},
            "tokenizer": {
                "class": type(self.tokenizer).__name__,
                "padding_side": self.tokenizer.padding_side,
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
                "chat_template_sha256": file_sha256(template_path),
            },
            "input_route": {
                "mode": "text_only",
                "tokenizer_only": True,
                "multimodal_processor_loaded": False,
                "images_or_videos": False,
            },
            "loaded_generation_config": loaded_generation,
            "loaded_generation_config_sha256": canonical_sha256(loaded_generation),
            "resolved_call_time_generation_config": resolved_generation,
            "resolved_call_time_generation_config_sha256": canonical_sha256(resolved_generation),
            "resolved_decoder_modules": modules,
            "research_runtime_module_count": len(modules),
            "model_weight_entries_sha256": weights["entries_sha256"],
            "research_checkpoint_used": True,
            "research_model_execution": True,
            "scientific_evidence": False,
        }
        return self.identity_report

    def _load_cases(self) -> None:
        declared = {item["case_id"]: item for item in self.manifest["input_preparation"]["cases"]}
        found = {}
        with (MATERIALS / "quality.jsonl").open(encoding="utf-8") as handle:
            for line in handle:
                case = json.loads(line, object_pairs_hook=_no_duplicate_keys)
                if case["case_id"] in declared:
                    validate_case(case)
                    if case["case_content_sha256"] != declared[case["case_id"]]["case_content_sha256"] or case["partition"] != "quality":
                        raise GateFailure("IDENTITY", f"Qualification case identity mismatch: {case['case_id']}")
                    found[case["case_id"]] = case
        if set(found) != set(declared):
            raise GateFailure("IDENTITY", "The two declared qualification cases are not both available.")
        self.cases = found

    def _render_case_input(self, case_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
        import torch
        case = self.cases[case_id]
        messages = [
            {"role": "system", "content": case["system_text"]},
            {"role": "user", "content": case["user_text"]},
        ]
        rendered = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        expected_suffix = "<|im_start|>assistant\n<think>\n\n</think>\n\n"
        if not isinstance(rendered, str) or not rendered.endswith(expected_suffix):
            raise GateFailure("IDENTITY", "Rendered prompt does not have the declared generation prompt and empty non-thinking block.")
        encoded = self.tokenizer(
            rendered,
            add_special_tokens=False,
            truncation=False,
            return_attention_mask=True,
            return_tensors="pt",
        )
        inputs = {"input_ids": encoded["input_ids"], "attention_mask": encoded["attention_mask"]}
        if inputs["input_ids"].ndim != 2 or inputs["input_ids"].shape[0] != 1:
            raise GateFailure("IDENTITY", "Tokenization did not produce one batch-1 input.", technical=True)
        length = int(inputs["input_ids"].shape[1])
        if length < 1 or length > self.manifest["input_preparation"]["max_input_tokens_per_trial"]:
            raise GateFailure("IDENTITY", "Qualification input exceeds its token cap; no truncation or retry is allowed.")
        if not torch.equal(inputs["attention_mask"], torch.ones_like(inputs["attention_mask"])):
            raise GateFailure("IDENTITY", "Batch-1 qualification input contains padding.")
        token_ids = inputs["input_ids"][0].tolist()
        receipt = {
            "artifact_type": "WP3_RENDERED_INPUT",
            "manifest_sha256": self.manifest_sha256,
            "run_id": self.run_id,
            "case_id": case_id,
            "case_content_sha256": case["case_content_sha256"],
            "messages": messages,
            "rendered_prompt_text": rendered,
            "rendered_prompt_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
            "chat_template_kwargs": {"enable_thinking": False},
            "add_generation_prompt": True,
            "empty_think_block_verified": True,
            "input_token_ids": token_ids,
            "input_token_ids_sha256": canonical_sha256(token_ids),
            "input_token_count": length,
            "padding_token_count": 0,
            "images_or_videos": False,
            "truncated": False,
        }
        return inputs, receipt

    def _prepare_inputs(self) -> None:
        for declared in self.manifest["input_preparation"]["cases"]:
            case_id = declared["case_id"]
            inputs, receipt = self._render_case_input(case_id)
            path = self.output_root / f"input_{case_id}.json"
            write_immutable_json(path, receipt)
            self.cpu_inputs[case_id] = inputs
            self.input_receipt_paths[case_id] = path

    def _load_child_input(self, input_receipt_path: Path) -> None:
        receipt = load_json(input_receipt_path)
        if receipt.get("artifact_type") != "WP3_RENDERED_INPUT" or receipt.get("manifest_sha256") != self.manifest_sha256 or receipt.get("run_id") != self.run_id:
            raise ManifestError("Fresh-restoration input is not bound to this manifest and run.")
        case_id = receipt.get("case_id")
        if case_id != "quality-tie-base":
            raise ManifestError("QG-07 must restore the original QG-02 quality-tie-base input.")
        inputs, regenerated = self._render_case_input(case_id)
        for key in ("rendered_prompt_text", "rendered_prompt_sha256", "input_token_ids", "input_token_ids_sha256", "case_content_sha256"):
            if regenerated[key] != receipt[key]:
                raise ManifestError(f"Fresh-restoration input mismatch: {key}")
        self.cpu_inputs[case_id] = inputs
        self.input_receipt_paths[case_id] = Path(input_receipt_path)

    def _load_direction(self) -> Any:
        import torch
        if self.direction is not None:
            return self.direction
        metadata = self.manifest["sites_and_direction"]["direction"]
        path = ROOT / metadata["artifact"]
        if not path.is_file() or file_sha256(path) != metadata["sha256"]:
            raise GateFailure("IDENTITY", "Synthetic instrumentation direction identity mismatch.")
        raw = path.read_bytes()
        if len(raw) != metadata["size_bytes"] or metadata["width"] != 4096 or metadata["dtype"] != "float32" or metadata["byte_order"] != "little_endian":
            raise GateFailure("IDENTITY", "Synthetic direction width/dtype/byte order mismatch.")
        self.direction = torch.frombuffer(bytearray(raw), dtype=torch.float32).detach().clone()
        if self.direction.numel() != 4096 or not bool(torch.isfinite(self.direction).all().item()):
            raise GateFailure("IDENTITY", "Synthetic direction is not finite float32 width 4096.")
        return self.direction

    def _sites(self, paths: list[str] | tuple[str, ...], *, with_direction: bool, coefficient: float) -> list[Any]:
        return sites_for_paths(paths, direction=self._load_direction() if with_direction else None, coefficient=coefficient)

    def _annotate_receipt(self, receipt: dict[str, Any], *, trial: dict[str, Any] | None = None) -> dict[str, Any]:
        receipt.update({
            "research_checkpoint_used": True,
            "research_model_execution": True,
            "model_execution": True,
            "execution_authorized": True,
            "scientific_evidence": False,
            "qualification_only_not_behavioral_evidence": True,
            "manifest_sha256": self.manifest_sha256,
            "approval_id": self.approval["approval_id"],
            "model_id": self.manifest["model"]["model_id"],
            "model_revision": self.manifest["model"]["revision"],
            "worker_name": self.manifest["worker"]["worker_name"],
            "worker_profile_sha256": self.manifest["worker"]["worker_profile_sha256"],
            "runtime_lock_sha256": self.manifest["runtime"]["transitive_requirements_lock_sha256"],
            "run_id": self.run_id,
        })
        if trial is not None:
            receipt["adapter_operation"] = receipt.get("operation")
            receipt["operation"] = trial["operation"]
            receipt["fresh_model_instance"] = True
            receipt["fresh_cache"] = True
            receipt["fresh_process"] = bool(trial.get("fresh_process", False))
            receipt["process_id"] = os.getpid()
            receipt["parent_process_id"] = os.getppid()
        return receipt

    def _check_model_identity_for_trial(self, receipt: dict[str, Any]) -> None:
        if receipt.get("weights_before", {}).get("entries_sha256") != self.reference_weight_entries_sha256:
            raise GateFailure("ISOLATION", "Fresh model instance does not reproduce the approved weight/buffer fingerprint.", technical=True)
        if receipt.get("weights_unchanged") is not True or receipt.get("hook_registry_restored") is not True or receipt.get("hooks_after", {}).get("active_hook_count") != 0:
            raise GateFailure("ISOLATION", "Weight or hook isolation failed.")


    def _generate_trial(self, trial: dict[str, Any], *, sites: list[Any] | None = None) -> dict[str, Any]:
        import torch
        trial_id = trial["trial_id"]
        self.current_operation = trial_id
        self._check_wall_clock()
        self._reload_model()
        inputs = {name: value.to("cuda:0") for name, value in self.cpu_inputs[trial["case_id"]].items()}
        started = time.monotonic()
        result = generate_with_receipts(
            self.model,
            inputs,
            trial_id=trial_id,
            sites=sites,
            max_new_tokens=trial["max_new_tokens"],
            min_new_tokens=self.manifest["generation"]["min_new_tokens"],
            eos_token_id=self.manifest["generation"]["generation_eos_token_ids"],
        )
        usage = self._resource_usage(started)
        self.total_generation_calls += 1
        generated = list(result.receipt["generated_token_ids"])
        self.total_new_tokens += len(generated)
        receipt = self._annotate_receipt(result.receipt, trial=trial)
        receipt["resource_usage"] = usage
        terminal_error = None
        parser_ids = None
        try:
            receipt["terminal_reason"] = verify_terminal_reason(generated, self.manifest["generation"]["generation_eos_token_ids"], trial["max_new_tokens"])
            parser_ids = parser_token_ids(generated, receipt["terminal_reason"])
            receipt["terminal_reason_verified_from_token_ids_and_length"] = True
        except GateFailure as exc:
            terminal_error = exc
            receipt["terminal_reason"] = "UNVERIFIED_STOP"
            receipt["terminal_reason_verified_from_token_ids_and_length"] = False
            receipt["terminal_verification_error"] = str(exc)
        raw_text = self.tokenizer.decode(generated, skip_special_tokens=False, clean_up_tokenization_spaces=False)
        parser_text = self.tokenizer.decode(parser_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False) if parser_ids is not None else None
        raw_record = {
            "artifact_type": "WP3_RAW_GENERATION_ATTEMPT",
            "schema_version": 1,
            "trial_id": trial_id,
            "case_id": trial["case_id"],
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "input_receipt": {
                "path": self.input_receipt_paths[trial["case_id"]].name,
                "sha256": file_sha256(self.input_receipt_paths[trial["case_id"]]),
            },
            "raw_output_text": raw_text,
            "raw_output_sha256": hashlib.sha256(raw_text.encode("utf-8")).hexdigest(),
            "parser_input_text": parser_text,
            "parser_input_transform": "Decode all generated tokens with special tokens preserved for raw output; for parsing only, remove exactly one terminal EOS token ID when the verified stop reason is eos. No other filtering.",
            "raw_output_committed_before_parsing_or_scoring": True,
            "technical_failure": False,
            "receipt": receipt,
        }
        raw_hash = write_immutable_json(self.output_root / f"{trial_id}.raw.json", raw_record)
        self.receipts[trial_id] = receipt
        self.raw_hashes[trial_id] = raw_hash
        self.completed.add(trial_id)
        result.sequences = None
        result.cache = None
        if terminal_error is not None:
            raise terminal_error
        if receipt["generation_call"] != self.expected_generation_call:
            raise GateFailure("IDENTITY", "Actual generation-call overrides differ from the approved resolved call.", technical=True)
        self._check_model_identity_for_trial(receipt)
        if self.total_generation_calls > 7 or self.total_new_tokens > 1120 or self.gpu_seconds > self.manifest["workload_hard_caps"]["maximum_gpu_hours"] * 3600:
            raise GateFailure("RESOURCES", "A measured generation/resource cap was exceeded.")
        self._check_wall_clock()
        return raw_record

    def _score_generation(self, trial: dict[str, Any], raw_record: dict[str, Any]) -> dict[str, Any]:
        self.current_operation = trial["trial_id"]
        score = score_response(self.cases[trial["case_id"]], raw_record["parser_input_text"])
        record = {
            "artifact_type": "WP3_INDEPENDENT_DETERMINISTIC_SCORE",
            "trial_id": trial["trial_id"],
            "case_id": trial["case_id"],
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "raw_artifact": f"{trial['trial_id']}.raw.json",
            "raw_artifact_sha256": self.raw_hashes[trial["trial_id"]],
            "raw_output_committed_before_parsing_or_scoring": True,
            "scorer": "analysis.negotiation.score_response",
            "score": score,
            "scientific_evidence": False,
            "scope": "Two-case mechanical baseline competence only" if trial["trial_id"] in {"QG-01", "QG-02"} else "No behavioral interpretation licensed",
        }
        write_immutable_json(self.output_root / f"{trial['trial_id']}.score.json", record)
        self.scores[trial["trial_id"]] = score
        return score

    def _capture_qf01(self, operation: dict[str, Any]) -> dict[str, Any]:
        self.current_operation = "QF-01"
        self._check_wall_clock()
        self._reload_model()
        inputs = {name: value.to("cuda:0") for name, value in self.cpu_inputs[operation["case_id"]].items()}
        started = time.monotonic()
        result = capture_only_with_receipts(
            self.model,
            inputs,
            trial_id="QF-01",
            sites=self._sites(ALL_DECODER_PATHS, with_direction=False, coefficient=0.0),
        )
        result.receipt["resource_usage"] = self._resource_usage(started)
        self.total_capture_operations += 1
        receipt = self._annotate_receipt(result.receipt)
        receipt["fresh_model_instance"] = True
        receipt["fresh_cache"] = True
        record = {
            "artifact_type": "WP3_CAPTURE_ONLY_ATTEMPT",
            "operation_id": "QF-01",
            "case_id": operation["case_id"],
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "receipt": receipt,
            "generated_answer": False,
            "scientific_evidence": False,
        }
        write_immutable_json(self.output_root / "QF-01.capture.json", record)
        if self.gpu_seconds > self.manifest["workload_hard_caps"]["maximum_gpu_hours"] * 3600:
            raise GateFailure("RESOURCES", "WP3 GPU-time cap exceeded; the raw capture was committed and no retry or overage is permitted.")
        self.qf01_receipt = receipt
        self.completed.add("QF-01")
        result.cache = None
        validate_trace_schedule(receipt, expected_site_ids=[f"layer-{i}-block-output" for i in range(32)], expected_phase="prefill", coefficient=0.0, nonzero_edit=False)
        if receipt.get("generation_call_count") != 0 or receipt.get("generated_answer") is not False:
            raise GateFailure("CAPTURE_CONTRACT", "QF-01 generated an answer.")
        return receipt

    def _capture_qf02(self, operation: dict[str, Any]) -> dict[str, Any]:
        import torch
        self.current_operation = "QF-02"
        self._check_wall_clock()
        if "QG-02" not in self.receipts or not self.receipts["QG-02"]["generated_token_ids"]:
            raise GateFailure("CAPTURE_CONTRACT", "QF-02 lacks the saved first QG-02 token.")
        inputs = {name: value.to("cuda:0") for name, value in self.cpu_inputs[operation["case_id"]].items()}
        weights_before = weight_fingerprint(self.model)
        hooks_before = weight_free_hook_receipt(self.model)
        was_training = self.model.training
        self.model.eval()
        started = time.monotonic()
        try:
            with torch.inference_mode():
                supporting_output = self.model(**inputs, use_cache=True, return_dict=True)
        finally:
            self.model.train(was_training)
        if weight_fingerprint(self.model) != weights_before or weight_free_hook_receipt(self.model) != hooks_before:
            raise GateFailure("ISOLATION", "Supporting prefill mutated weights or hooks.", technical=True)
        supporting_cache = supporting_output.past_key_values
        supporting_receipt = self._annotate_receipt({
            "receipt_kind": "NATIVE_UNRECORDED_SUPPORTING_PREFILL",
            "trial_id": "QF-02-supporting-prefill",
            "generation_call_count": 0,
            "generated_answer": False,
            "operation": "supporting_unrecorded_prefill",
            "weights_unchanged": True,
            "hook_registry_restored": True,
            "cache_state": summarize_cache(supporting_cache, model=self.model),
            "scientific_evidence": False,
        })
        first_token = self.receipts["QG-02"]["generated_token_ids"][0]
        input_length = inputs["input_ids"].shape[1]
        cached_inputs = {
            "input_ids": torch.tensor([[first_token]], dtype=torch.long, device="cuda:0"),
            "attention_mask": torch.ones((1, input_length + 1), dtype=torch.long, device="cuda:0"),
            "position_ids": torch.tensor([[input_length]], dtype=torch.long, device="cuda:0"),
            "cache_position": torch.tensor([input_length], dtype=torch.long, device="cuda:0"),
            "past_key_values": supporting_cache,
        }
        result = capture_only_with_receipts(
            self.model,
            cached_inputs,
            trial_id="QF-02",
            sites=self._sites(PROBE_PATHS, with_direction=False, coefficient=0.0),
        )
        result.receipt["resource_usage"] = self._resource_usage(started)
        self.total_capture_operations += 1
        self.total_supporting_prefills += 1
        receipt = self._annotate_receipt(result.receipt)
        receipt["fresh_model_instance"] = False
        receipt["fresh_cache"] = True
        receipt["teacher_forced_token_id"] = first_token
        receipt["supporting_unrecorded_prefill_count"] = 1
        record = {
            "artifact_type": "WP3_CAPTURE_ONLY_ATTEMPT",
            "operation_id": "QF-02",
            "case_id": operation["case_id"],
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "supporting_prefill_receipt": supporting_receipt,
            "receipt": receipt,
            "generated_answer": False,
            "scientific_evidence": False,
        }
        write_immutable_json(self.output_root / "QF-02.capture.json", record)
        if self.gpu_seconds > self.manifest["workload_hard_caps"]["maximum_gpu_hours"] * 3600:
            raise GateFailure("RESOURCES", "WP3 GPU-time cap exceeded; the raw capture was committed and no retry or overage is permitted.")
        self.qf02_receipt = receipt
        self.completed.add("QF-02")
        result.cache = None
        supporting_output.past_key_values = None
        validate_trace_schedule(receipt, expected_site_ids=["layer-2-block-output", "layer-3-block-output"], expected_phase="decode", coefficient=0.0, nonzero_edit=False)
        for capture in receipt["trace"]["captures"]:
            if capture["logical_token_positions"] != [input_length]:
                raise GateFailure("CAPTURE_CONTRACT", "QF-02 logical cached-token position is incorrect.")
        return receipt

    def _record_gate(self, gate_id: str, details: dict[str, Any]) -> None:
        record = {
            "artifact_type": "WP3_MECHANICAL_GATE",
            "gate_id": gate_id,
            "status": "PASS",
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "details": details,
            "scientific_evidence": False,
        }
        write_immutable_json(self.output_root / f"gate_{len(self.gates)+1:02d}_{gate_id}.json", record)
        self.gates[gate_id] = record

    def _parity(self, reference_id: str, candidate_id: str) -> dict[str, Any]:
        return assert_exact_generation_parity(
            ExecutionResult(receipt=self.receipts[reference_id]),
            ExecutionResult(receipt=self.receipts[candidate_id]),
        )

    def _state_inventory(self) -> dict[str, Any]:
        self.current_operation = "STATE_INVENTORY"
        if self.qf01_receipt is None or self.qf02_receipt is None:
            raise GateFailure("STATE_INVENTORY", "Capture receipts are incomplete.")
        captures = {item["resolved_module_path"]: item for item in self.qf01_receipt["trace"]["captures"]}
        module_map = load_json(self._referenced("module_state_cache_map"))
        modules = []
        for index, path in enumerate(ALL_DECODER_PATHS):
            module = resolve_module(self.model, path)
            capture = captures.get(path)
            if capture is None or capture["shape"] != [1, 1, 4096] or capture["storage_dtype"] != "torch.bfloat16":
                raise GateFailure("STATE_INVENTORY", f"Missing BF16 all-layer prefill state summary at {path}.")
            expected_kind = module_map["layers"][index]["block_type"]
            if type(module).__name__ != "Qwen3_5DecoderLayer" or getattr(module, "block_type", None) != expected_kind:
                raise GateFailure("STATE_INVENTORY", f"Actual module mismatch at {path}.")
            modules.append({
                "path": path,
                "class": type(module).__name__,
                "block_type": expected_kind,
                "captured_shape": capture["shape"],
                "captured_dtype": capture["storage_dtype"],
                "pre_sha256": capture["pre_sha256"],
            })
        cache_receipt = self.qf02_receipt.get("cache_state", {})
        counts = _state_kind_counts(cache_receipt)
        expected_counts = {
            "linear_convolution_state": 24,
            "linear_recurrent_state": 24,
            "full_attention_key_cache": 8,
            "full_attention_value_cache": 8,
            "cache_or_position_metadata": 1,
            "position_state": 1,
        }
        if counts != expected_counts or cache_receipt.get("cache_implementation") is None or cache_receipt.get("position_state") is None:
            raise GateFailure("STATE_INVENTORY", f"Incomplete hybrid cache/position inventory: {counts}")
        record = {
            "artifact_type": "WP3_ALL_LAYER_STATE_INVENTORY",
            "status": "PASS",
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "modules": modules,
            "cache_implementation": cache_receipt["cache_implementation"],
            "future_affecting_tensor_counts": counts,
            "cache_state_receipt": cache_receipt,
            "same_layer_block_output_edit_is_not_direct_cache_edit": True,
            "research_checkpoint_used": True,
            "scientific_evidence": False,
        }
        write_immutable_json(self.output_root / "state_inventory.json", record)
        return record

    def _isolation_summary(self) -> dict[str, Any]:
        for trial_id, receipt in self.receipts.items():
            self._check_model_identity_for_trial(receipt)
            if receipt.get("fresh_cache") is not True:
                raise GateFailure("ISOLATION", f"Fresh-cache declaration missing at {trial_id}.")
            if trial_id != "QG-07" and receipt.get("fresh_model_instance") is not True:
                raise GateFailure("ISOLATION", f"Fresh-model isolation missing at {trial_id}.")
            if receipt.get("cache_state", {}).get("raw_tensors_retained") is not False:
                raise GateFailure("ISOLATION", f"Unbounded cache retention at {trial_id}.")
        return {
            "fresh_cache_every_generation": True,
            "fresh_model_every_in_process_generation": True,
            "fresh_process_restoration_required_next": True,
            "weights_unchanged_every_trial": True,
            "no_active_hooks_after_every_trial": True,
            "raw_full_states_or_caches_retained": False,
        }

    def _run_fresh_restoration(self, trial: dict[str, Any]) -> dict[str, Any]:
        self.current_operation = "QG-07"
        self._check_wall_clock()
        output_path = self.output_root / "QG-07.raw.json"
        command = [
            sys.executable,
            str(ROOT / "worker" / "run_wp3.py"),
            "--fresh-restoration-child",
            "--manifest", str(self.manifest_path),
            "--approval", str(self.approval_path),
            "--model-snapshot", str(self.snapshot_root),
            "--snapshot-attestation", str(self.snapshot_attestation_path),
            "--output-root", str(self.output_root),
            "--run-id", self.run_id,
            "--input-receipt", str(self.input_receipt_paths["quality-tie-base"]),
        ]
        environment = dict(os.environ)
        environment.update({
            "HF_HUB_OFFLINE": "1",
            "TRANSFORMERS_OFFLINE": "1",
            "HF_DATASETS_OFFLINE": "1",
            "HF_HUB_DISABLE_TELEMETRY": "1",
            "TOKENIZERS_PARALLELISM": "false",
            "PYTHONDONTWRITEBYTECODE": "1",
        })
        remaining = max(1.0, self.manifest["workload_hard_caps"]["maximum_wall_hours"] * 3600 - (time.monotonic() - self.started_monotonic))
        completed = subprocess.run(command, env=environment, text=True, capture_output=True, timeout=remaining, check=False)
        if completed.returncode != 0 or not output_path.is_file():
            raise GateFailure("RESTORATION", f"Fresh restoration child failed with exit {completed.returncode}: stdout={completed.stdout[-4000:]} stderr={completed.stderr[-4000:]}", technical=True)
        raw_record = load_json(output_path)
        if (
            raw_record.get("artifact_type") != "WP3_RAW_GENERATION_ATTEMPT"
            or raw_record.get("trial_id") != trial["trial_id"]
            or raw_record.get("run_id") != self.run_id
            or raw_record.get("manifest_sha256") != self.manifest_sha256
        ):
            raise GateFailure("RESTORATION", "Fresh-restoration raw record is not bound to the requested trial, run, and manifest.", technical=True)
        receipt = raw_record.get("receipt")
        if not isinstance(receipt, dict) or receipt.get("trial_id") != trial["trial_id"] or receipt.get("run_id") != self.run_id or receipt.get("manifest_sha256") != self.manifest_sha256:
            raise GateFailure("RESTORATION", "Fresh-restoration receipt identity does not match its raw record and parent run.", technical=True)
        self.total_generation_calls += 1
        self.total_new_tokens += receipt["new_token_count"]
        self.receipts["QG-07"] = receipt
        self.raw_hashes["QG-07"] = file_sha256(output_path)
        self.completed.add("QG-07")
        if receipt.get("fresh_process") is not True or receipt.get("process_id") == os.getpid() or receipt.get("hooks_after", {}).get("active_hook_count") != 0:
            raise GateFailure("RESTORATION", "QG-07 did not run uninstrumented in a fresh process.")
        if receipt.get("terminal_reason") not in {"eos", "max_new_tokens"} or receipt.get("terminal_reason_verified_from_token_ids_and_length") is not True:
            raise GateFailure("RESTORATION", "QG-07 stop reason was not verified.")
        self._check_model_identity_for_trial(receipt)
        return raw_record

    def _resource_summary(self) -> dict[str, Any]:
        output_bytes = sum(path.stat().st_size for path in self.output_root.rglob("*") if path.is_file())
        peak_allocated = max((receipt.get("resource_usage", {}).get("gpu_peak_allocated_bytes", 0) for receipt in self.receipts.values()), default=0)
        peak_reserved = max((receipt.get("resource_usage", {}).get("gpu_peak_reserved_bytes", 0) for receipt in self.receipts.values()), default=0)
        elapsed = time.monotonic() - self.started_monotonic
        caps = self.manifest["workload_hard_caps"]
        within_caps = (
            self.total_generation_calls == caps["maximum_generation_calls"]
            and self.total_new_tokens <= caps["maximum_total_new_tokens"]
            and self.total_capture_operations == caps["maximum_capture_only_operations"]
            and self.total_supporting_prefills == caps["maximum_supporting_unrecorded_prefill_forwards"]
            and self.gpu_seconds <= caps["maximum_gpu_hours"] * 3600
            and elapsed <= caps["maximum_wall_hours"] * 3600
            and output_bytes <= caps["maximum_working_storage_gib"] * (1024 ** 3)
        )
        if not within_caps:
            raise GateFailure("RESOURCES", "Measured workload/resource totals differ from or exceed the approved caps.")
        return {
            "generation_call_count": self.total_generation_calls,
            "new_token_count": self.total_new_tokens,
            "capture_only_operation_count": self.total_capture_operations,
            "captured_non_generative_forward_count": 2,
            "supporting_unrecorded_prefill_count": self.total_supporting_prefills,
            "model_load_count_in_parent": self.model_load_count,
            "gpu_operation_wall_seconds": self.gpu_seconds,
            "total_wall_seconds": elapsed,
            "gpu_peak_allocated_bytes_observed_in_parent_receipts": peak_allocated,
            "gpu_peak_reserved_bytes_observed_in_parent_receipts": peak_reserved,
            "snapshot_bytes": self.snapshot_report["total_bytes"],
            "evidence_output_bytes_at_measurement": output_bytes,
            "provider_cost_eur": None,
            "provider_invoice_reconciled": False,
            "provider_cost_reconciliation_required_before_wp3_pass": True,
            "within_measured_non_cost_caps": True,
        }

    def _record_failure_and_blocked(self, exc: Exception) -> None:
        technical = not isinstance(exc, GateFailure) or getattr(exc, "technical", False)
        gate_id = exc.gate_id if isinstance(exc, GateFailure) else self.current_operation or "IDENTITY"
        failure = {
            "artifact_type": "WP3_RUN_FAILURE",
            "status": "TECHNICAL_FAILURE" if technical else "MECHANICAL_GATE_FAILED",
            "gate_id": gate_id,
            "current_operation": self.current_operation,
            "run_id": self.run_id,
            "manifest_sha256": self.manifest_sha256,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "completed_operations": sorted(self.completed),
            "technical_failure_distinct_from_completed_invalid_output": True,
            "retry_allowed": False,
            "research_checkpoint_used": self.model_load_count > 0,
            "scientific_evidence": False,
        }
        write_immutable_json(self.output_root / "run_failed.json", failure)
        for operation_id in [f"QG-{i:02d}" for i in range(1, 8)] + ["QF-01", "QF-02"]:
            if operation_id not in self.completed:
                write_immutable_json(self.output_root / f"{operation_id}.blocked.json", {
                    "artifact_type": "WP3_BLOCKED_OPERATION",
                    "operation_id": operation_id,
                    "status": "NOT_RUN_GATE_BLOCKED",
                    "blocking_gate": gate_id,
                    "run_id": self.run_id,
                    "manifest_sha256": self.manifest_sha256,
                    "retry_allowed": False,
                    "research_model_execution": False,
                    "scientific_evidence": False,
                })

    def execute(self) -> dict[str, Any]:
        """Execute the exact seven-generation WP3 workload after separate approval."""
        authorization = self.verify_execution_authorization()
        if self.output_root.exists() and any(self.output_root.iterdir()):
            raise ManifestError(f"WP3 output directory must be new or empty: {self.output_root}")
        self.output_root.mkdir(parents=True, exist_ok=True)
        if self.run_id is None:
            self.run_id = "WP3-" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + self.manifest_sha256[:12]
        self.started_monotonic = time.monotonic()
        write_immutable_json(self.output_root / "run_started.json", {
            "artifact_type": "WP3_RUN_START",
            "run_id": self.run_id,
            "started_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "authorization": authorization,
            "manifest_sha256": self.manifest_sha256,
            "retry_allowed": False,
            "scientific_evidence": False,
        })
        try:
            self.verify_snapshot()
            self._load_tokenizer()
            self._load_model()
            self._attest_identity()
            write_immutable_json(self.output_root / "identity.json", self.identity_report)
            self._load_cases()
            self._prepare_inputs()
            self._record_gate("IDENTITY", {"module_paths_resolved": 32, "effective_generation_config_sha256": self.identity_report["resolved_call_time_generation_config_sha256"]})
            trials = self.manifest["generation_trials"]
            qg01 = self._generate_trial(trials[0])
            self._score_generation(trials[0], qg01)
            qg02 = self._generate_trial(trials[1])
            self._score_generation(trials[1], qg02)
            valid_count = sum(self.scores[trial_id]["valid"] is True for trial_id in ("QG-01", "QG-02"))
            if valid_count != 2:
                raise GateFailure("BASELINE_COMPETENCE", f"Mechanical baseline competence failed: {valid_count}/2 valid; no case substitution or retry.")
            self._record_gate("BASELINE_COMPETENCE", {"valid_count": valid_count, "denominator": 2, "claim_boundary": "Two-case mechanical screen only"})
            captures = self.manifest["capture_only_operations"]
            self._capture_qf01(captures[0])
            self._capture_qf02(captures[1])
            self._record_gate("CAPTURE_CONTRACT", {"qf01_all_layer_capture_count": 32, "qf02_probe_capture_count": 2, "generated_answers": 0})
            qg03 = self._generate_trial(trials[2], sites=self._sites(PROBE_PATHS, with_direction=False, coefficient=0.0))
            parity = self._parity("QG-02", "QG-03")
            validate_trace_schedule(self.receipts["QG-03"], expected_site_ids=["layer-2-block-output", "layer-3-block-output"], new_token_count=self.receipts["QG-03"]["new_token_count"], coefficient=0.0, nonzero_edit=False)
            self._record_gate("QG-03_INSTRUMENTATION_EQUIVALENCE", parity)
            qg04 = self._generate_trial(trials[3], sites=self._sites(PROBE_PATHS, with_direction=True, coefficient=0.0))
            parity = self._parity("QG-02", "QG-04")
            validate_trace_schedule(self.receipts["QG-04"], expected_site_ids=["layer-2-block-output", "layer-3-block-output"], new_token_count=self.receipts["QG-04"]["new_token_count"], coefficient=0.0, nonzero_edit=False)
            self._record_gate("QG-04_ZERO_EDIT_EQUIVALENCE", parity)
            inventory = self._state_inventory()
            self._record_gate("STATE_INVENTORY", {"module_count": len(inventory["modules"]), "future_affecting_tensor_counts": inventory["future_affecting_tensor_counts"]})
            self._generate_trial(trials[4], sites=self._sites((PROBE_PATHS[0],), with_direction=True, coefficient=1.0))
            validate_trace_schedule(self.receipts["QG-05"], expected_site_ids=["layer-2-block-output"], new_token_count=self.receipts["QG-05"]["new_token_count"], coefficient=1.0, nonzero_edit=True)
            self._record_gate("QG-05_REALIZED_EDIT", {"site": PROBE_PATHS[0], "behavioral_effect_required": False})
            self._generate_trial(trials[5], sites=self._sites((PROBE_PATHS[1],), with_direction=True, coefficient=1.0))
            validate_trace_schedule(self.receipts["QG-06"], expected_site_ids=["layer-3-block-output"], new_token_count=self.receipts["QG-06"]["new_token_count"], coefficient=1.0, nonzero_edit=True)
            self._record_gate("QG-06_REALIZED_EDIT", {"site": PROBE_PATHS[1], "behavioral_effect_required": False})
            self._record_gate("ISOLATION", self._isolation_summary())
            self._run_fresh_restoration(trials[6])
            parity = self._parity("QG-02", "QG-07")
            self._record_gate("RESTORATION", parity)
            resources = self._resource_summary()
            result = {
                "artifact_type": "WP3_MECHANICAL_OPERATIONS_RESULT",
                "status": "MECHANICAL_OPERATIONS_PASS_AWAITING_PROVIDER_COST_RECONCILIATION",
                "run_id": self.run_id,
                "manifest_sha256": self.manifest_sha256,
                "completed_operations": sorted(self.completed),
                "gate_count": len(self.gates),
                "resources": resources,
                "wp3_qualified": False,
                "qualification_pending": "Actual provider charges must be reconciled against the EUR 100 total WP3 cap before a final PASS.",
                "research_checkpoint_used": True,
                "research_model_execution": True,
                "scientific_evidence": False,
                "steering_evidence": False,
                "behavioral_effect_claimed": False,
            }
            write_immutable_json(self.output_root / "run_completed_pending_cost.json", result)
            return result
        except Exception as exc:
            self._record_failure_and_blocked(exc)
            raise
        finally:
            self.model = None
            gc.collect()

    def execute_fresh_restoration_child(self, input_receipt_path: Path) -> dict[str, Any]:
        """Internal QG-07 entry: exact approval + fresh process/model/cache, one call."""
        self.verify_execution_authorization()
        if self.run_id is None:
            raise ManifestError("Fresh-restoration child requires the parent run ID.")
        self.started_monotonic = time.monotonic()
        try:
            self.verify_snapshot()
            self._load_tokenizer()
            self._load_model()
            self._attest_identity()
            self._load_cases()
            self._load_child_input(Path(input_receipt_path))
            trial = self.manifest["generation_trials"][6]
            raw = self._generate_trial(trial)
            return {
                "status": "FRESH_RESTORATION_RAW_OUTPUT_COMMITTED",
                "trial_id": "QG-07",
                "raw_artifact_sha256": self.raw_hashes["QG-07"],
                "process_id": os.getpid(),
                "scientific_evidence": False,
            }
        except Exception as exc:
            if not (self.output_root / "QG-07.child_failure.json").exists():
                write_immutable_json(self.output_root / "QG-07.child_failure.json", {
                    "artifact_type": "WP3_FRESH_CHILD_FAILURE",
                    "run_id": self.run_id,
                    "manifest_sha256": self.manifest_sha256,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "retry_allowed": False,
                    "scientific_evidence": False,
                })
            raise
        finally:
            self.model = None
            gc.collect()


def reconcile_provider_cost(run_root: Path, cost_receipt_path: Path) -> dict[str, Any]:
    """Finalize WP3 only after actual provider charges are independently reconciled."""
    run_root = Path(run_root).resolve()
    completed = load_json(run_root / "run_completed_pending_cost.json")
    receipt = load_json(Path(cost_receipt_path).resolve())
    if completed.get("status") != "MECHANICAL_OPERATIONS_PASS_AWAITING_PROVIDER_COST_RECONCILIATION" or completed.get("gate_count") != 10:
        raise ManifestError("WP3 mechanical operations are not complete pending cost reconciliation.")
    if receipt.get("artifact_type") != "WP3_PROVIDER_COST_RECEIPT" or receipt.get("run_id") != completed.get("run_id") or receipt.get("manifest_sha256") != completed.get("manifest_sha256"):
        raise ManifestError("Provider cost receipt is not bound to this exact run and manifest.")
    if receipt.get("currency") != "EUR" or not _number(receipt.get("total_wp3_cost_eur")) or receipt.get("provider_invoice_reconciled") is not True or receipt.get("reconciled_by") != "Anonymous owner":
        raise ManifestError("Actual EUR provider charges are not reconciled by Anonymous owner.")
    cost = receipt["total_wp3_cost_eur"]
    if cost < 0 or cost > 100.0:
        raise GateFailure("RESOURCES", "Actual total WP3 provider cost exceeds the EUR 100 cap; no overage is authorized.")
    result = {
        "artifact_type": "WP3_FINAL_MECHANICAL_QUALIFICATION",
        "status": "PASS",
        "run_id": completed["run_id"],
        "manifest_sha256": completed["manifest_sha256"],
        "mechanical_operations_gate_count": completed["gate_count"],
        "resource_gate": "PASS",
        "mechanical_gate_count": completed["gate_count"] + 1,
        "total_wp3_cost_eur": cost,
        "cost_receipt_sha256": file_sha256(Path(cost_receipt_path).resolve()),
        "wp3_qualified": True,
        "research_checkpoint_used": True,
        "research_model_execution": True,
        "scientific_evidence": False,
        "steering_evidence": False,
        "meaning": "Mechanical WP3 qualification only. No steering direction, negotiation effect, robustness, untouched evaluation, or construct validity is established.",
    }
    write_immutable_json(run_root / "wp3_final_mechanical_qualification.json", result)
    return result
