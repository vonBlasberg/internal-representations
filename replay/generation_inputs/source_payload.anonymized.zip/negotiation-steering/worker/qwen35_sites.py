"""Declarative Qwen3.5 site inventory; imports no model runtime and executes nothing."""
from __future__ import annotations

from typing import Any

from worker.adapter_base import Site

LAYER_COUNT = 32
FULL_ATTENTION_LAYERS = frozenset({3, 7, 11, 15, 19, 23, 27, 31})
ALL_DECODER_PATHS = tuple(f"model.language_model.layers.{index}" for index in range(LAYER_COUNT))
PROBE_PATHS = ("model.language_model.layers.2", "model.language_model.layers.3")


class SiteInventoryError(ValueError):
    """The declared capture/edit workload differs from the frozen architecture map."""


def block_type_for_layer(index: int) -> str:
    if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < LAYER_COUNT:
        raise SiteInventoryError(f"Invalid zero-based decoder layer: {index!r}")
    return "full_attention" if index in FULL_ATTENTION_LAYERS else "linear_attention"


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise SiteInventoryError(message)


def _layer_index(path: str) -> int:
    prefix = "model.language_model.layers."
    _require(isinstance(path, str) and path.startswith(prefix), f"Unsafe decoder path: {path!r}")
    suffix = path[len(prefix):]
    _require(suffix.isdigit(), f"Decoder path must end in a nonnegative integer: {path!r}")
    index = int(suffix)
    _require(path == ALL_DECODER_PATHS[index], f"Non-canonical decoder path: {path!r}")
    return index


def validate_site_inventory(manifest: dict[str, Any], module_map: dict[str, Any]) -> dict[str, Any]:
    """Require all-layer prefill capture and exactly two cached/generation probes.

    This check is deliberately stricter than checking set membership: ordering and
    duplicate sites are workload-changing errors, not harmless serialization drift.
    """
    layers = module_map.get("layers")
    _require(isinstance(layers, list) and len(layers) == LAYER_COUNT, "Module map must contain exactly 32 layers.")
    observed_paths = []
    for expected_index, layer in enumerate(layers):
        _require(layer.get("layer_index_zero_based") == expected_index, "Module-map layers are not ordered 0..31.")
        expected_kind = block_type_for_layer(expected_index)
        _require(layer.get("block_type") == expected_kind, f"Wrong block type at layer {expected_index}.")
        path = layer.get("block_output_site", {}).get("path")
        _require(path == ALL_DECODER_PATHS[expected_index], f"Wrong block-output path at layer {expected_index}.")
        observed_paths.append(path)
    _require(tuple(observed_paths) == ALL_DECODER_PATHS, "Module-map decoder path inventory is incomplete.")

    captures = manifest.get("capture_only_operations")
    _require(isinstance(captures, list) and [item.get("operation_id") for item in captures] == ["QF-01", "QF-02"], "Expected ordered QF-01/QF-02 operations.")
    qf01, qf02 = captures
    _require(qf01.get("operation") == "capture_only_prefill", "QF-01 must be prefill capture only.")
    _require(tuple(qf01.get("sites", [])) == ALL_DECODER_PATHS, "QF-01 must capture all 32 ordered decoder outputs.")
    _require(qf02.get("operation") == "capture_only_cached_single_token_forward", "QF-02 must be a cached single-token capture.")
    _require(tuple(qf02.get("sites", [])) == PROBE_PATHS, "QF-02 must capture exactly layers 2 and 3.")
    _require(qf01.get("captured_forward_count") == qf02.get("captured_forward_count") == 1, "Each capture operation permits one recorded forward.")
    _require(qf02.get("supporting_unrecorded_prefill_count") == 1, "QF-02 permits exactly one supporting prefill.")
    _require(qf01.get("generated_answer") is False and qf02.get("generated_answer") is False, "Capture-only operations cannot generate answers.")

    trials = manifest.get("generation_trials")
    _require(isinstance(trials, list) and [item.get("trial_id") for item in trials] == [f"QG-{i:02d}" for i in range(1, 8)], "Expected the seven ordered QG trials.")
    _require(tuple(trials[2].get("recording_sites", [])) == PROBE_PATHS, "QG-03 recording is limited to layers 2 and 3.")
    _require(tuple(trials[3].get("sites", [])) == PROBE_PATHS, "QG-04 zero edit is limited to layers 2 and 3.")
    _require(tuple(trials[4].get("sites", [])) == (PROBE_PATHS[0],), "QG-05 must edit only the linear-attention probe.")
    _require(tuple(trials[5].get("sites", [])) == (PROBE_PATHS[1],), "QG-06 must edit only the full-attention probe.")
    _require(all(trial.get("retry_allowed") is False for trial in trials), "Every WP3 trial must forbid retries.")
    _require(all(trial.get("max_new_tokens") == 160 for trial in trials), "Every WP3 generation must retain the 160-token cap.")
    _require(not any(key in trials[6] for key in ("sites", "recording_sites")), "QG-07 restoration must be uninstrumented.")

    declared = manifest.get("sites_and_direction", {})
    _require(declared.get("linear_attention_probe", {}).get("path") == PROBE_PATHS[0], "Linear probe path mismatch.")
    _require(declared.get("full_attention_probe", {}).get("path") == PROBE_PATHS[1], "Full-attention probe path mismatch.")
    _require(declared.get("position_rule") == "prefill_last_active_plus_every_decode_token", "Unexpected position rule.")
    return {
        "status": "PASS",
        "decoder_layer_count": LAYER_COUNT,
        "qf01_site_count": len(qf01["sites"]),
        "qf02_sites": list(PROBE_PATHS),
        "generation_probe_sites": list(PROBE_PATHS),
        "generation_call_count": len(trials),
        "maximum_total_new_tokens": sum(trial["max_new_tokens"] for trial in trials),
        "research_runtime_resolution": "REQUIRED_NOT_PERFORMED_BY_THIS_CHECK",
    }


def sites_for_paths(
    paths: list[str] | tuple[str, ...],
    *,
    direction: Any = None,
    coefficient: float = 0.0,
) -> list[Site]:
    """Construct declared native sites without resolving them on a research model."""
    _require(bool(paths), "At least one site is required.")
    _require(len(set(paths)) == len(paths), "Duplicate sites are not permitted.")
    sites = []
    for path in paths:
        index = _layer_index(path)
        sites.append(Site(
            site_id=f"layer-{index}-block-output",
            module_path=path,
            block_type=block_type_for_layer(index),
            direction=direction,
            coefficient=coefficient,
        ))
    return sites
