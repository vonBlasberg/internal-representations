"""Source-bound one-use A10 calibration. Preparation has no provider access."""
import json
import math
from pathlib import Path
import sys
import tempfile
import time
import zipfile

from . import expanded_run as construction, depth_calibration_run as previous
from . import qualification_transport as delivery
from .expanded_calibration_worker import RUN_ID, LIMITS, PINNED, draft_request, check_request, checked_evidence
from .preparatory_phases import identity, save_new

ROOT = construction.ROOT
BASE = construction.BASE
DIRECTORY = BASE / "calibration"
BUDGET = construction.BUDGET
WORKER = "local_integration.expanded_calibration_worker"
TERMINAL = {"CALIBRATION_COMPLETE", "CALIBRATION_STOPPED_BASELINE_FEASIBILITY"}
EXTRA = ("local_integration/expanded_calibration_worker.py", "local_integration/expanded_calibration_run.py",
         "local_integration/expanded_calibration_audit.py")
SETTINGS = {"artifact_type":"EXPANDED_CALIBRATION_TRANSPORT", "schema_version":1,
    "run_id":RUN_ID, "stage":"calibration", "worker_module":WORKER, "base_image_id":delivery.BASE_IMAGE,
    "gpu":"L40S", "cpu_limit":8, "memory_limit_mib":65536, "maximum_containers":1,
    "maximum_generation_calls":41, "maximum_model_loads":1, "process_tree_timeout_seconds":7200,
    "application_retries":0, "maximum_reserved_usd":12.0, "aggregate_limit_usd":100.0,
    "checkpoint_download":False, "deployment":False}

def read(path):
    return json.loads(Path(path).read_bytes())

def source_evidence():
    parent, _, package, _ = construction.load()
    folder = construction.DIRECTORY / "launch/returned"
    files = {
        "previous-calibration.json":(previous.DIRECTORY/"request.json").read_bytes(),
        "parent-request.json":(construction.DIRECTORY/"request.json").read_bytes(),
        "parent-audit.json":(construction.DIRECTORY/"terminal_audit.json").read_bytes(),
        "parent-manifest.json":(folder/"manifest.json").read_bytes(),
        "parent-directions.json":(folder/"evidence/attempt/capture/directions/directions.json").read_bytes(),
    }
    for name, wanted in PINNED.items():
        if delivery.digest(files[name]) != wanted:
            raise ValueError("Pinned parent evidence changed: " + name)
    from .expanded_audit import verify_delivery
    terminal, count = verify_delivery(folder, parent, package)
    original = json.loads(files["parent-audit.json"])
    if terminal != original["outer_terminal"] or count != original["returned_files_verified"]:
        raise ValueError("Parent construction delivery differs from its independent audit.")
    for layers in json.loads(files["parent-directions.json"])["directions"].values():
        for entry in layers.values():
            files["directions/"+entry["path"]] = (folder/"evidence/attempt/capture/directions"/entry["path"]).read_bytes()
    checked_evidence(files)
    return files

def request_values():
    files = source_evidence()
    request = draft_request(files, delivery.file_digest(BASE/"CALIBRATION_AUTHORIZATION.md"),
                            delivery.file_digest(BASE/"calibration_reservation.json"))
    return request, files

def build(request, sources):
    _, _, _, payloads = previous.load()
    _, _, _, parent_payloads = construction.load()
    # Merge both verified dependency sets. Shared frozen files must be identical.
    payloads = {name:raw for name,raw in payloads.items() if not name.startswith("request/")}
    for name, raw in parent_payloads.items():
        if name.startswith("request/"):
            continue
        if name in payloads and payloads[name] != raw:
            raise ValueError("Verified source archives disagree: " + name)
        payloads[name] = raw
    for name in EXTRA:
        payloads[name] = (ROOT/name).read_bytes()
    for name, raw in sources.items():
        payloads["request/"+name] = raw
    payloads["request/research.json"] = delivery.encoded(request)
    for name in ("CALIBRATION_AUTHORIZATION.md", "calibration_reservation.json"):
        payloads["request/A10-"+name] = (BASE/name).read_bytes()
    inventory = [{"path":name, "sha256":delivery.digest(raw), "size_bytes":len(raw)} for name,raw in sorted(payloads.items())]
    return {**SETTINGS, "request_sha256":identity(request), "files":inventory, "inventory_sha256":identity(inventory)}, payloads

def approval_for(request, package):
    return {"owner_authorized":True, "paid_phase_authorized":True, **LIMITS,
        "request_sha256":identity(request), "transport_sha256":identity(package),
        "automatic_retry":False, "deployment_authorized":False,
        "owner_authorization_reference":"Active owner goal: revised intervention and prototype within US$100; independently verified A10 construction."}

def verify(package, payloads, approval, *, local=False):
    if any(package.get(key) != value for key,value in SETTINGS.items()):
        raise ValueError("Calibration transport settings changed.")
    inventory = {entry["path"]:entry for entry in package["files"]}
    if len(inventory) != len(package["files"]) or set(inventory) != set(payloads) or identity(package["files"]) != package["inventory_sha256"]:
        raise ValueError("Calibration source inventory differs.")
    for name, entry in inventory.items():
        delivery.safe_relative(name)
        if delivery.digest(payloads[name]) != entry["sha256"] or len(payloads[name]) != entry["size_bytes"]:
            raise ValueError("Calibration source changed: " + name)
    request = json.loads(payloads["request/research.json"])
    if package["request_sha256"] != identity(request) or approval["transport_sha256"] != identity(package):
        raise ValueError("Request or source identity differs.")
    for name,key in (("CALIBRATION_AUTHORIZATION.md","authorization_sha256"),("calibration_reservation.json","reservation_sha256")):
        if delivery.digest(payloads["request/A10-"+name]) != request[key]:
            raise ValueError("Authority or reservation bytes changed.")
    sources = {name.removeprefix("request/"):raw for name,raw in payloads.items()
               if name.removeprefix("request/") in PINNED or name.startswith("request/directions/")}
    check_request(request, approval, evidence_files=sources)
    if local:
        with tempfile.TemporaryDirectory(prefix="buyer-calibration-upload-") as temporary:
            root = Path(temporary)
            for name, raw in payloads.items():
                delivery.write_new(root / name, raw)
            check_request(request, approval, root=root)
    return request

def protected_inventory():
    inventory = construction.protected_inventory()
    # Construction's own freeze excluded A10 while it was being produced.
    # Its complete, now-historical tree is protected before calibration starts.
    for path in sorted(BASE.rglob("*")):
        if DIRECTORY in path.parents or path == DIRECTORY or "__pycache__" in path.parts:
            continue
        if path.is_symlink():
            raise ValueError("A10 preservation does not accept symlinks: " + str(path))
        if path.is_file():
            inventory[str(path.relative_to(ROOT))] = delivery.file_digest(path)
    return inventory

def verify_preflight(request, package):
    pointer = read(BASE/"calibration_preflight.json")
    path = ROOT / delivery.safe_relative(pointer["report_path"])
    if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("Unsafe calibration preflight report path.")
    report = read(path)
    if (delivery.file_digest(path) != pointer["report_sha256"] or report["status"] != "PASS"
            or report["request_sha256"] != identity(request) or report["transport_sha256"] != identity(package)
            or not set(EXTRA).issubset(report["source_sha256"])
            or not all(report[key] for key in ("exact_upload_checked","independent_auditor_tested","review_findings_resolved"))):
        raise PermissionError("Exact source-bound calibration preflight is required.")
    for name,wanted in report["source_sha256"].items():
        source = ROOT / delivery.safe_relative(name)
        if source.is_symlink() or not source.resolve().is_relative_to(ROOT.resolve()) or delivery.file_digest(source) != wanted:
            raise ValueError("Preflight source changed: " + name)
    return report

def prepare():
    request, files = request_values()
    package, payloads = build(request, files)
    approval = approval_for(request, package)
    verify(package, payloads, approval, local=True)
    verify_preflight(request, package)
    inventory = protected_inventory()
    approval.update(preserved_inventory_sha256=identity(inventory), preflight_sha256=delivery.file_digest(BASE/"calibration_preflight.json"))
    DIRECTORY.mkdir(exist_ok=False)
    for name,value in (("request.json",request),("approval.json",approval),("transport.json",package),("preserved_before.json",inventory)):
        save_new(DIRECTORY/name,value)
    with zipfile.ZipFile(DIRECTORY/"source_payload.zip","x",zipfile.ZIP_DEFLATED) as archive:
        for name,raw in payloads.items():
            archive.writestr(name,raw)
    save_new(DIRECTORY/"source_archive.json",{"sha256":delivery.file_digest(DIRECTORY/"source_payload.zip")})
    return {"status":"PREPARED_NOT_SUBMITTED", "request_sha256":identity(request), "files":len(payloads)}

def load():
    request,approval,package = [read(DIRECTORY/name) for name in ("request.json","approval.json","transport.json")]
    if delivery.file_digest(DIRECTORY/"source_payload.zip") != read(DIRECTORY/"source_archive.json")["sha256"]:
        raise ValueError("Frozen calibration archive changed.")
    with zipfile.ZipFile(DIRECTORY/"source_payload.zip") as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError("Duplicate upload path.")
        payloads = {name:archive.read(name) for name in archive.namelist()}
    if verify(package,payloads,approval,local=True) != request:
        raise ValueError("Saved request differs from upload.")
    for name,raw in payloads.items():
        if not name.startswith("request/") and (ROOT/name).read_bytes() != raw:
            raise ValueError("Frozen implementation changed: " + name)
    for name,key in (("CALIBRATION_AUTHORIZATION.md","authorization_sha256"),("calibration_reservation.json","reservation_sha256")):
        if delivery.file_digest(BASE/name) != request[key]:
            raise ValueError("Frozen authority changed.")
    if delivery.file_digest(BASE/"calibration_preflight.json") != approval["preflight_sha256"]:
        raise ValueError("Frozen preflight changed.")
    verify_preflight(request, package)
    inventory = read(DIRECTORY/"preserved_before.json")
    if identity(inventory) != approval["preserved_inventory_sha256"] or any(delivery.file_digest(ROOT/n)!=h for n,h in inventory.items()):
        raise ValueError("Protected originals changed.")
    current_sources = source_evidence()
    archived_sources = {name.removeprefix("request/"):raw for name,raw in payloads.items()
                        if name.removeprefix("request/") in PINNED or name.startswith("request/directions/")}
    if current_sources != archived_sources:
        raise ValueError("Live parent evidence differs from the frozen calibration upload.")
    return request,approval,package,payloads

def budget_check(budget):
    rows = budget["planned_reservations"]
    others = budget["new_runs"]
    amounts = [r["maximum_usd"] for r in rows]+[r["reserved_usd"] for r in others]
    ids = [r["run_id"] for r in rows+others]
    if (budget["aggregate_limit"]!=100 or len(ids)!=len(set(ids))
            or any(type(v) not in (int,float) or not math.isfinite(v) or v<=0 for v in amounts)
            or sum(amounts)>100 or budget["unreserved_usd"]!=100-sum(amounts)
            or not any(r["run_id"]==RUN_ID and r["maximum_usd"]==12 and r["status"]=="NOT_SUBMITTED" for r in rows)):
        raise PermissionError("No unused A10 calibration reservation within US$100.")

def remote(approval,package,payloads,claim,commit):
    request = verify(package,payloads,approval)
    if not claim(RUN_ID,{"request_sha256":identity(request),"claimed_at":time.time()}):
        return {"status":"ALREADY_CLAIMED_NO_EXECUTION","run_id":RUN_ID,"files":{}}
    outer = Path(delivery.MOUNT)/delivery.result_prefix(RUN_ID)
    outer.mkdir(parents=True,exist_ok=False)
    delivery.write_new(outer/"claimed.json",delivery.encoded({"run_id":RUN_ID,"request_sha256":identity(request)}));commit()
    try:
        root = Path(delivery.REMOTE)
        for name,raw in payloads.items():
            delivery.write_new(root/delivery.safe_relative(name),raw)
        delivery.write_new(root/"request/approval.json",delivery.encoded(approval))
        process = delivery.run_process([sys.executable,"-B","-m",WORKER,str(root/"request/research.json"),str(root/"request/approval.json"),delivery.SNAPSHOT,str(outer/"attempt")],root,outer/"stdout.log",outer/"stderr.log",7200)
        result = read(outer/"attempt/result.json") if (outer/"attempt/result.json").is_file() else {}
        status = result["status"] if process["returncode"]==0 and not process.get("timed_out") and result.get("status") in TERMINAL else "FAILED_OR_INDETERMINATE_NO_RETRY"
        terminal = {"status":status,"run_id":RUN_ID,"request_sha256":identity(request),"process":process,"automatic_retry":False,"held_out_result":False}
    except BaseException as error:
        terminal = {"status":"FAILED_NO_RETRY","run_id":RUN_ID,"request_sha256":identity(request),"error_type":type(error).__name__,"error":str(error),"automatic_retry":False}
    delivery.write_new(outer/"terminal.json",delivery.encoded(terminal))
    return delivery.publish_result(outer,terminal,package,commit)

def driver(package,payloads):
    import modal
    stage = Path(tempfile.mkdtemp(prefix="buyer-calibration-image-"))
    for name,raw in payloads.items():
        delivery.write_new(stage/name,raw)
    requirements = [s.strip() for s in payloads[delivery.LOCK].decode().splitlines() if s.strip() and not s.startswith(("#","./upstream"))]
    image = (modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements).add_local_dir(str(stage),"/opt/preparatory-build",copy=True)
             .pip_install("/opt/preparatory-build/"+delivery.UPSTREAM,extra_options="--no-deps"))
    volume = modal.Volume.from_name(delivery.VOLUME,create_if_missing=False)
    app = modal.App("orgsci-expanded-calibration-a10",include_source=False)
    @app.function(image=image,gpu="L40S",cpu=(8.0,8.0),memory=(65536,65536),volumes={delivery.MOUNT:volume},timeout=7260,retries=0,max_containers=1,max_inputs=1,block_network=True,serialized=True,include_source=False,env={"HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1","PYTHONDONTWRITEBYTECODE":"1","OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"})
    def execute(approval,package,payloads):
        import sys
        import modal
        sys.path.insert(0,"/opt/preparatory-build")
        from local_integration import expanded_calibration_run as run
        claims = modal.Dict.from_name("orgsci-revised-intervention-100usd-one-use",create_if_missing=True)
        volume = modal.Volume.from_name(run.delivery.VOLUME,create_if_missing=False)
        return run.remote(approval,package,payloads,lambda key,value:claims.put(key,value,skip_if_exists=True),volume.commit)
    return modal,app,execute

def launch():
    request,approval,package,payloads = load()
    budget_check(read(BUDGET))
    directory = DIRECTORY/"launch"
    directory.mkdir(exist_ok=False)
    save_new(directory/"submission_claim.json",{"run_id":RUN_ID,"request_sha256":identity(request),"transport_sha256":identity(package),"reserved_usd":12.0,"automatic_retry":False})
    try:
        modal,app,function = driver(package,payloads)
        with modal.enable_output(),app.run(detach=True):
            call = function.spawn(approval,package,payloads)
            result = {"artifact_type":"PACKAGE_QUALIFICATION_DETACHED_LAUNCH","run_id":RUN_ID,"modal_app_id":app.app_id,"modal_function_call_id":call.object_id,"transport_sha256":identity(package),"status":"SUBMITTED_NOT_VERIFIED"}
            if not result["modal_app_id"] or not result["modal_function_call_id"]:
                raise RuntimeError("No saved call identity. Never resubmit.")
            save_new(directory/"launch.json",result)
            return result
    except BaseException as error:
        save_new(directory/"submission_error.json",{"status":"ERROR_OR_INDETERMINATE_NO_RETRY","error_type":type(error).__name__,"error":str(error)})
        raise

if __name__ == "__main__":
    action = sys.argv[1]
    if action in {"launch","retrieve"}:
        sys.path.append(str(ROOT.parent/"model-trace-observatory/.venv/lib/python3.12/site-packages"))
    if action == "prepare":result = prepare()
    elif action == "check":
        request,_,_,payloads = load();result = {"status":"A10_CALIBRATION_SOURCE_CHECK_PASS","files":len(payloads),"request_sha256":identity(request)}
    elif action == "launch":result = launch()
    elif action == "retrieve":result = delivery.retrieve(DIRECTORY/"launch")
    elif action == "audit":
        from .expanded_calibration_audit import audit
        result = audit()
    else:raise ValueError("No implicit action.")
    print(json.dumps(result),flush=True)
