"""Prepare/check/transport the one A06 calibration after independent verification."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch
import zipfile

from . import authored_transport, depth_run, depth_audit, headroom_transport
from . import preparatory_transport as base
from . import qualification_transport as delivery
from .depth_calibration_worker import RUN_ID, REUSE_POLICY, check_request, check_evidence
from .construction_program import phase_plan, calibration_arms
from .preparatory_phases import identity, save_new

ROOT = depth_run.ROOT
BASE = depth_run.BASE
DIRECTORY = BASE / 'calibration'
WORKER = 'local_integration.depth_calibration_worker'
EXTRA = (*headroom_transport.EXTRA, *depth_run.EXTRA,
    'local_integration/reused_model.py', 'local_integration/calibration_diagnostics.py',
    'local_integration/depth_calibration_worker.py',
    'local_integration/depth_calibration_run.py', 'local_integration/depth_audit.py',
    'local_integration/depth_calibration_audit.py')
TERMINAL = {'CALIBRATION_COMPLETE', 'CALIBRATION_STOPPED_BASELINE_FEASIBILITY'}


def read(path):
    return json.loads(Path(path).read_text())


def reverify_construction():
    """Replay the frozen auditor without rewriting its original terminal report."""
    original = read(BASE / 'construction/terminal_audit.json')
    captured = []
    def retain_in_memory(path, value):
        if path != BASE / 'construction/terminal_audit.json' or captured:
            raise RuntimeError('Unexpected audit write.')
        captured.append(value)
    with patch.object(depth_audit, 'save_new', retain_in_memory):
        verified = depth_audit.audit()
    comparable = lambda value: {k: v for k, v in value.items() if k != 'checked_at_utc'}
    if len(captured) != 1 or comparable(original) != comparable(verified):
        raise ValueError('The saved independent construction audit no longer reproduces.')
    return original


def protected_inventory():
    output = {}
    for folder in (ROOT / 'records', ROOT / 'local_integration', ROOT / 'negotiation-steering/analysis', ROOT / 'negotiation-steering/worker'):
        for path in sorted(folder.rglob('*')):
            if (path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts
                    and DIRECTORY not in path.parents
                    and path not in {BASE / 'budget.json', BASE / 'calibration_preflight.json'}):
                output[str(path.relative_to(ROOT))] = delivery.file_digest(path)
    return output


def request_values():
    audit = reverify_construction()
    parent, parent_approval, _, _ = depth_run.load()
    returned = BASE / 'construction/launch/returned'
    evidence = returned / 'evidence/attempt'
    sources = {
        'parent-audit.json': (BASE / 'construction/terminal_audit.json').read_bytes(),
        'parent-manifest.json': (returned / 'manifest.json').read_bytes(),
        'parent-directions.json': (evidence / 'directions/directions.json').read_bytes(),
    }
    manifest = json.loads(sources['parent-directions.json'])
    directions = manifest['directions']
    for values in directions.values():
        for entry in values.values():
            sources['directions/' + entry['path']] = (evidence / 'directions' / entry['path']).read_bytes()
    plan = phase_plan(parent['program'], 'calibration', calibration_arms(parent['program'], directions))
    request = {'run_id': RUN_ID, 'stage': 'calibration', 'program': parent['program'],
        'program_sha256': identity(parent['program']), 'construction_request': parent,
        'construction_approval': parent_approval, 'construction_audit': audit,
        'construction_audit_object_sha256': identity(audit),
        'construction_audit_file_sha256': delivery.digest(sources['parent-audit.json']),
        'construction_manifest_file_sha256': delivery.digest(sources['parent-manifest.json']),
        'direction_manifest_file_sha256': delivery.digest(sources['parent-directions.json']),
        'verified_direction_manifest': manifest, 'directions': directions,
        'construction_source': parent['construction_source'],
        'maximum_generation_calls': 41, 'maximum_wall_seconds': 7200,
        'model_reuse_policy': REUSE_POLICY, 'phase_plan_sha256': identity(plan),
        'authorization_sha256': delivery.file_digest(BASE / 'CALIBRATION_AUTHORIZATION.md'),
        'reservation_sha256': delivery.file_digest(BASE / 'calibration_reservation.json'),
        'preserved_inventory_sha256': identity(protected_inventory())}
    check_evidence(request, sources)
    return request, sources


def build(request, sources):
    vectors = {name.removeprefix('directions/'): raw for name, raw in sources.items() if name.startswith('directions/')}
    package, payloads = authored_transport.build_package(request, vectors)
    for name in EXTRA:
        payloads[name] = (ROOT / name).read_bytes()
    for name, raw in sources.items():
        payloads['request/' + name] = raw
    inventory = [{'path': name, 'sha256': delivery.digest(raw), 'size_bytes': len(raw)} for name, raw in sorted(payloads.items())]
    package.update(files=inventory, inventory_sha256=identity(inventory), worker_module=WORKER,
        maximum_reserved_usd=12.0, aggregate_limit_usd=100.0, model_reuse_policy=REUSE_POLICY)
    return package, payloads


def approval_for(request, package):
    return {'owner_authorized': True, 'paid_phase_authorized': True, 'stage': 'calibration',
        'request_sha256': identity(request), 'transport_sha256': identity(package),
        'maximum_generation_calls': 41, 'maximum_wall_seconds': 7200,
        'maximum_reserved_usd': 12.0, 'aggregate_limit_usd': 100.0,
        'automatic_retry': False, 'deployment_authorized': False, 'f4_authorized': False,
        'owner_authorization_reference': 'Active owner goal: revised intervention experiments and prototype, aggregate US$100 cap; independent A06 gate passed.'}


def verify(package, payloads, approval, *, local=False):
    request = base.verify(package, payloads, approval)
    if any(package.get(k) != v for k, v in {'worker_module': WORKER,
            'maximum_reserved_usd': 12.0, 'aggregate_limit_usd': 100.0,
            'model_reuse_policy': REUSE_POLICY}.items()) or request['run_id'] != RUN_ID:
        raise ValueError('Calibration entry, budget or reuse policy changed.')
    evidence = {name.removeprefix('request/'): raw for name, raw in payloads.items()
                if name.startswith(('request/parent-', 'request/directions/'))}
    check_evidence(request, evidence)
    if local:
        check_request(request, approval, evidence_files=evidence)
    return request


def prepare():
    request, sources = request_values()
    package, payloads = build(request, sources)
    approval = approval_for(request, package)
    verify(package, payloads, approval, local=True)
    pointer = read(BASE / 'calibration_preflight.json')
    report = read(ROOT / pointer['report_path'])
    if (delivery.file_digest(ROOT / pointer['report_path']) != pointer['report_sha256']
            or report['status'] != 'PASS' or report['request_sha256'] != identity(request)
            or report['transport_sha256'] != identity(package)
            or not report['exact_upload_checked'] or not report['independent_auditor_tested']):
        raise PermissionError('Exact calibration preflight is missing or failed.')
    for name, digest in report['source_sha256'].items():
        if delivery.file_digest(ROOT / name) != digest:
            raise ValueError('Preflight source changed: ' + name)
    approval['preflight_sha256'] = delivery.file_digest(BASE / 'calibration_preflight.json')
    DIRECTORY.mkdir(exist_ok=False)
    for name, value in (('request.json', request), ('approval.json', approval), ('transport.json', package)):
        save_new(DIRECTORY / name, value)
    with zipfile.ZipFile(DIRECTORY / 'source_payload.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name, raw in payloads.items():
            archive.writestr(name, raw)
    save_new(DIRECTORY / 'source_archive.json', {'sha256': delivery.file_digest(DIRECTORY / 'source_payload.zip')})
    protected = protected_inventory()
    if identity(protected) != request['preserved_inventory_sha256']:
        raise ValueError('Preserved files changed during preparation.')
    save_new(DIRECTORY / 'preserved_before.json', protected)
    return {'status': 'PREPARED_NOT_SUBMITTED', 'request_sha256': identity(request), 'files': len(payloads)}


def load():
    request, approval, package = [read(DIRECTORY / name) for name in ('request.json', 'approval.json', 'transport.json')]
    if delivery.file_digest(DIRECTORY / 'source_payload.zip') != read(DIRECTORY / 'source_archive.json')['sha256']:
        raise ValueError('Saved source archive changed.')
    with zipfile.ZipFile(DIRECTORY / 'source_payload.zip') as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError('Duplicate payload file.')
        payloads = {name: archive.read(name) for name in archive.namelist()}
    if verify(package, payloads, approval, local=True) != request:
        raise ValueError('Saved request differs from its transported copy.')
    for name, raw in payloads.items():
        if not name.startswith('request/') and (ROOT / name).read_bytes() != raw:
            raise ValueError('Frozen source changed: ' + name)
    if (delivery.file_digest(BASE / 'CALIBRATION_AUTHORIZATION.md') != request['authorization_sha256']
            or delivery.file_digest(BASE / 'calibration_reservation.json') != request['reservation_sha256']
            or delivery.file_digest(BASE / 'calibration_preflight.json') != approval['preflight_sha256']):
        raise PermissionError('Calibration authorization, reservation or preflight changed.')
    protected = read(DIRECTORY / 'preserved_before.json')
    if identity(protected) != request['preserved_inventory_sha256']:
        raise ValueError('Original preservation inventory changed.')
    if any(delivery.file_digest(ROOT / name) != digest for name, digest in protected.items()):
        raise ValueError('Protected original source or evidence changed.')
    return request, approval, package, payloads


def remote(approval, package, payloads, claim, commit):
    request = verify(package, payloads, approval)
    if not claim(RUN_ID, {'request_sha256': identity(request), 'time': time.time()}):
        return {'status': 'ALREADY_CLAIMED_NO_EXECUTION', 'run_id': RUN_ID}
    outer = Path(delivery.MOUNT) / delivery.result_prefix(RUN_ID)
    outer.mkdir(parents=True, exist_ok=False)
    delivery.write_new(outer / 'claimed.json', delivery.encoded({'run_id': RUN_ID, 'request_sha256': identity(request)}))
    commit()
    try:
        root = Path(delivery.REMOTE)
        for name, raw in payloads.items():
            delivery.write_new(root / delivery.safe_relative(name), raw)
        delivery.write_new(root / 'request/approval.json', delivery.encoded(approval))
        process = delivery.run_process([sys.executable, '-m', WORKER, str(root / 'request/research.json'),
            str(root / 'request/approval.json'), delivery.SNAPSHOT, str(outer / 'attempt')],
            root, outer / 'stdout.log', outer / 'stderr.log', 7200)
        path = outer / 'attempt/result.json'
        result = read(path) if path.is_file() else {}
        status = (result['status'] if process['returncode'] == 0 and not process.get('timed_out')
                  and result.get('status') in TERMINAL else 'FAILED_OR_INDETERMINATE_NO_RETRY')
        terminal = {'status': status, 'run_id': RUN_ID, 'request_sha256': identity(request),
            'process': process, 'automatic_retry': False, 'held_out_result': False}
    except BaseException as error:
        terminal = {'status': 'FAILED_NO_RETRY', 'run_id': RUN_ID,
            'error_type': type(error).__name__, 'error': str(error)}
    delivery.write_new(outer / 'terminal.json', delivery.encoded(terminal))
    return delivery.publish_result(outer, terminal, package, commit)


def driver(package, payloads):
    import modal
    stage = Path(tempfile.mkdtemp(prefix='orgsci-depth-calibration-image-'))
    for name, raw in payloads.items():
        delivery.write_new(stage / name, raw)
    requirements = [line.strip() for line in payloads[delivery.LOCK].decode().splitlines()
                    if line.strip() and not line.startswith(('#', './upstream'))]
    image = (modal.Image.from_id(delivery.BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage), '/opt/preparatory-build', copy=True)
        .pip_install('/opt/preparatory-build/' + delivery.UPSTREAM, extra_options='--no-deps'))
    volume = modal.Volume.from_name(delivery.VOLUME, create_if_missing=False)
    app = modal.App('orgsci-depth-calibration-a06', include_source=False)
    @app.function(image=image, gpu='L40S', cpu=8.0, memory=65536, volumes={delivery.MOUNT: volume},
        timeout=7260, retries=0, max_containers=1, max_inputs=1, block_network=True,
        serialized=True, include_source=False, env={'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
        'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'})
    def execute(approval, package, payloads):
        import sys
        import modal
        sys.path.insert(0, '/opt/preparatory-build')
        from local_integration import depth_calibration_run as run
        claims = modal.Dict.from_name('orgsci-revised-intervention-100usd-one-use', create_if_missing=True)
        volume = modal.Volume.from_name(run.delivery.VOLUME, create_if_missing=False)
        return run.remote(approval, package, payloads,
            lambda key, value: claims.put(key, value, skip_if_exists=True), volume.commit)
    return modal, app, execute


def launch():
    request, approval, package, payloads = load()
    reverify_construction()
    budget = read(BASE / 'budget.json')
    reservation = read(BASE / 'calibration_reservation.json')
    rows = budget['planned_reservations']
    amounts = [row['maximum_usd'] for row in rows] + [row.get('reserved_usd') for row in budget['new_runs']]
    if (budget['aggregate_limit'] != 100 or reservation['run_id'] != RUN_ID or reservation['maximum_usd'] != 12
            or any(type(x) not in (int, float) or not 0 < x <= 100 for x in amounts) or sum(amounts) > 100
            or not any(r['run_id'] == RUN_ID and r['maximum_usd'] == 12 and r['status'] == 'NOT_SUBMITTED' for r in rows)):
        raise PermissionError('No unused calibration reservation within the aggregate cap.')
    directory = DIRECTORY / 'launch'
    directory.mkdir(exist_ok=False)
    save_new(directory / 'submission_claim.json', {'run_id': RUN_ID, 'request_sha256': identity(request),
        'reserved_usd': 12.0, 'aggregate_limit_usd': 100.0, 'automatic_retry': False})
    try:
        modal, app, function = driver(package, payloads)
        with modal.enable_output(), app.run(detach=True):
            call = function.spawn(approval, package, payloads)
            receipt = {'artifact_type': 'PACKAGE_QUALIFICATION_DETACHED_LAUNCH', 'run_id': RUN_ID,
                'modal_app_id': app.app_id, 'modal_function_call_id': call.object_id,
                'transport_sha256': identity(package), 'status': 'SUBMITTED_NOT_VERIFIED'}
            save_new(directory / 'launch.json', receipt)
            return receipt
    except BaseException as error:
        save_new(directory / 'submission_error.json', {'status': 'ERROR_OR_INDETERMINATE_NO_RETRY',
            'error_type': type(error).__name__, 'error': str(error)})
        raise


if __name__ == '__main__':
    action = sys.argv[1]
    if action in {'launch', 'retrieve'}:
        sys.path.append(str(ROOT.parent / 'model-trace-observatory/.venv/lib/python3.12/site-packages'))
    if action == 'prepare':
        result = prepare()
    elif action == 'check':
        request, _, _, payloads = load()
        result = {'status': 'A06_CALIBRATION_CHECK_PASS', 'files': len(payloads), 'request_sha256': identity(request)}
    elif action == 'launch':
        result = launch()
    elif action == 'retrieve':
        result = delivery.retrieve(DIRECTORY / 'launch')
    else:
        raise ValueError('Unknown action.')
    print(json.dumps(result), flush=True)
