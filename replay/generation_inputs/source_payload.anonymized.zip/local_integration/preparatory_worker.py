"""One-shot construction or calibration using the already-qualified model route."""
from dataclasses import asdict
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import time

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1",
    HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false", DO_NOT_TRACK="1", PYTHONDONTWRITEBYTECODE="1")

from .construction_program import ROOT, phase_plan, phase_approval, calibration_arms
from .preparatory_phases import identity, save_new, execute_phase, check_construction_labels, summarize_calibration
from .construction_inputs import prepare_pairs
from .direction_construction import ConstructionSpec, construct_directions, input_hash
from .calibration_selection import select
from .package_qualification import source_inventory, validate_plan as qualification_contract
from .qualification_worker import check_artifacts, load_admitted_model
from .preparatory_inspect import InspectPhaseGenerator

def check_request(request, approval):
    program = request["program"]
    if request["stage"] not in {"construction", "calibration"} or request["program_sha256"] != identity(program):
        raise ValueError("Unrecognized stage or changed program.")
    required = {"owner_authorized": True, "paid_phase_authorized": True, "request_sha256": identity(request),
        "stage": request["stage"], "maximum_generation_calls": request["maximum_generation_calls"],
        "maximum_wall_seconds": request["maximum_wall_seconds"], "automatic_retry": False,
        "deployment_authorized": False, "f4_authorized": False}
    if any(approval.get(k) != v for k, v in required.items()) or not approval.get("owner_authorization_reference"):
        raise PermissionError("This exact request is not authorized.")
    limits = program["limits"]
    if request["maximum_generation_calls"] != limits[request["stage"] + "_generation_calls"] or request["maximum_wall_seconds"] != limits[request["stage"] + "_wall_seconds"]:
        raise ValueError("Request limits differ from the frozen program.")
    if program["qualification_plan"]["source_sha256"] != source_inventory():
        raise ValueError("The qualified generation/construction sources changed.")
    audit = request["qualification_audit"]
    if identity(audit) != program["qualification_audit_object_sha256"] or audit.get("mechanical_qualification_verified") is not True or audit.get("worker_terminal_status") != "PASS":
        raise ValueError("The saved mechanical qualification has not passed.")
    check_artifacts(program["qualification_plan"])
    if request["stage"] == "calibration" and request.get("construction_audit", {}).get("status") != "CONSTRUCTION_AND_CONTROLS_VERIFIED":
        raise ValueError("Calibration needs independently verified construction records.")
    return qualification_contract(program["qualification_plan"])

def generate_control_files(program, constructed, directory):
    """Derive predeclared diagnostics without more model calls or redrawing."""
    import numpy as np
    import torch
    directory.mkdir(exist_ok=False)
    manifest = {kind: {} for kind in ("raw", "random_1", "random_2", "random_3", "permuted")}
    checks = []
    for layer, _ in program["sites"]:
        target = constructed.raw.directions[layer].detach().cpu().float()
        norm = target.norm()
        values = {"raw": target}
        for number, seed in enumerate(program["random_controls"]["seeds"], 1):
            rng = np.random.Generator(np.random.PCG64(seed + layer * 1000))
            value = torch.from_numpy(rng.standard_normal(tuple(target.shape)).astype("<f4"))
            values[f"random_{number}"] = value / value.norm() * norm
        signed = []
        for index, pair in enumerate(constructed.record["pairs"]):
            positive, negative = (torch.tensor(pair["responses"][label]["pooled_states"][str(layer)], dtype=torch.float32).reshape_as(target)
                for label in ("positive", "negative"))
            sign = -1 if index in program["permuted_control"]["swapped_pair_indices"] else 1
            signed.append(sign * (positive - negative))
        permuted = sum(signed, torch.zeros_like(target)) / len(signed)
        permuted_norm = permuted.norm()
        cosine = float(torch.nn.functional.cosine_similarity(target, permuted, dim=1)[0])
        valid = bool(torch.isfinite(permuted).all() and torch.isfinite(permuted_norm) and permuted_norm > 0 and abs(cosine) < 0.999999)
        checks.append({"layer": layer, "permuted_raw_norm": float(permuted_norm), "cosine_with_target": cosine, "distinct_from_target_and_reversal": valid})
        values["permuted"] = permuted / permuted_norm * norm if valid else permuted
        for kind, value in values.items():
            data = value.contiguous().numpy().astype("<f4").tobytes()
            name = f"{kind}-layer-{layer}.f32le"
            with (directory / name).open("xb") as stream:
                stream.write(data)
            manifest[kind][str(layer)] = {"path": name, "sha256": hashlib.sha256(data).hexdigest(),
                "size_bytes": len(data), "shape": list(value.shape), "norm": float(value.norm()),
                "seed": None if kind in {"raw", "permuted"} else program["random_controls"]["seeds"][int(kind[-1])-1] + layer * 1000}
    save_new(directory / "directions.json", {"directions": manifest, "permutation_checks": checks,
        "program_sha256": identity(program), "additional_model_calls": 0})
    if not all(row["distinct_from_target_and_reversal"] for row in checks):
        raise ValueError("The fixed permuted diagnostic is degenerate; no alternative permutation or retry.")
    return manifest

def run_construction(program, reference, destination, model_factory, tokenizer, *, generator_class=InspectPhaseGenerator):
    contract = qualification_contract(program["qualification_plan"])
    results = {}
    for phase in ("construction_check", "construction_fit"):
        plan = phase_plan(program, phase)
        connection = generator_class(plan, contract, model_factory=model_factory, direction_loader=None)
        result = execute_phase(plan, program["cases"][phase], phase_approval(plan, reference), destination / "phases", generate=connection)
        results[phase] = result
        if result["failure"]:
            raise RuntimeError(phase + " stopped; see preserved invalid/technical records.")
        if phase == "construction_check":
            check = check_construction_labels(plan, program["cases"][phase], result)
            save_new(destination / "construction_check.json", check)
            if check["status"] != "PASS":
                raise RuntimeError("Construction policies failed their separate behavioral check; no fitting or calibration.")
    pairs, input_record = prepare_pairs(plan, program["cases"]["construction_fit"], result, tokenizer,
        position_policy=program["position_policy"])
    save_new(destination / "teacher_forcing_inputs.json", {**input_record, "pairs": [asdict(pair) for pair in pairs]})
    location = destination / "capture_model"
    location.mkdir(exist_ok=False)
    model, _ = model_factory(location)
    try:
        spec = ConstructionSpec(contract.model_id, contract.model_revision, contract.model_type,
            tuple(tuple(site) for site in program["sites"]), model.get_input_embeddings().weight.shape[1],
            tuple(p.pair_id for p in pairs), input_hash(pairs),
            tuple(f for f, p in program["family_partitions"].items() if p != "construction_fit"),
            program["pooling"], program["accumulation_dtype"], program["insertion_dtype"],
            contract.max_input_tokens + contract.max_new_tokens, False)
        save_new(destination / "construction_spec.json", asdict(spec))
        fitted = construct_directions(model, pairs, spec)
        if fitted.record["capture_forward_count"] != program["limits"]["construction_capture_forwards"]:
            raise RuntimeError("Capture allowance differs.")
        fitted.save(destination / "constructed")
        directions = generate_control_files(program, fitted, destination / "directions")
    finally:
        del model
        gc.collect()
    return {"status": "CONSTRUCTION_COMPLETE", "direction_manifest": directions,
        "generation_calls": sum(sum(r["execution_status"] != "NOT_RUN_AFTER_FAILURE" for r in v["records"]) for v in results.values()),
        "capture_forwards": fitted.record["capture_forward_count"], "behavioral_steering_result": False}

def run_calibration(request, reference, destination, model_factory):
    import numpy as np
    import torch
    program = request["program"]
    directions = request["directions"]
    plan = phase_plan(program, "calibration", calibration_arms(program, directions))
    if identity(plan) != request["phase_plan_sha256"]:
        raise ValueError("Calibration plan differs from the prospectively bound inputs.")
    def load_direction(edit, _):
        entries = [item for by_layer in directions.values() for item in by_layer.values() if item["sha256"] == edit["direction_sha256"]]
        if not entries:
            raise ValueError("Undeclared direction.")
        entry = entries[0]
        path = ROOT / "request/directions" / entry["path"]
        data = path.read_bytes()
        if len(data) != entry["size_bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError("Direction bytes differ.")
        return torch.from_numpy(np.frombuffer(data, dtype="<f4").copy()).reshape(entry["shape"])
    connection = InspectPhaseGenerator(plan, qualification_contract(program["qualification_plan"]),
        model_factory=model_factory, direction_loader=load_direction)
    baseline_receipt = None
    def generate(trial, directory):
        nonlocal baseline_receipt
        output = connection(trial, directory)
        receipt = json.loads((directory / "state_execution.json").read_text())["records"][-1]
        if trial["kind"] == "unchanged":
            baseline_receipt = receipt
        if trial["kind"] == "sham":
            keys = ("input_token_ids", "generated_token_ids", "processed_logit_steps")
            if baseline_receipt is None or any(receipt[k] != baseline_receipt[k] for k in keys):
                save_new(directory / "sham_failure_output.json", output)
                raise RuntimeError("Zero edit changed the baseline; stop calibration.")
        return output
    result = execute_phase(plan, program["cases"]["calibration"], phase_approval(plan, reference),
        destination / "phases", generate=generate)
    summary = summarize_calibration(plan, program["cases"]["calibration"], result)
    selection = select(plan, program["cases"]["calibration"], result)
    save_new(destination / "calibration_summary.json", summary)
    save_new(destination / "selection.json", selection)
    if result["failure"]:
        raise RuntimeError("Calibration stopped; all attempted and unattempted rows retained.")
    return {"status": "CALIBRATION_COMPLETE", "selection": selection,
        "generation_calls": len(result["records"]), "held_out_result": False}

def main():
    request_path, approval_path, snapshot, destination = map(Path, sys.argv[1:])
    request, approval = json.loads(request_path.read_text()), json.loads(approval_path.read_text())
    contract = check_request(request, approval)
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination / "started.json", {"request": request, "approval": approval})
    started = time.monotonic()
    calls = 0
    program = request["program"]
    def factory(directory):
        nonlocal calls
        if calls >= request["maximum_generation_calls"] + (1 if request["stage"] == "construction" else 0):
            raise RuntimeError("Model-loading allowance exhausted.")
        calls += 1
        import torch
        gc.collect()
        torch.cuda.empty_cache()
        model, tokenizer, unused = load_admitted_model(program["qualification_plan"], snapshot, directory)
        del unused
        return model, tokenizer
    try:
        # Tokenization-only admission of every planned generation precedes the first model load.
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
        plans = [phase_plan(program, p) for p in ("construction_check", "construction_fit")] if request["stage"] == "construction" else [phase_plan(program, "calibration", calibration_arms(program, request["directions"]))]
        admission = []
        for plan in plans:
            for trial in plan["trials"]:
                ids = tokenizer.apply_chat_template(trial["messages"], tokenize=True, return_dict=False, add_generation_prompt=True, enable_thinking=False)
                admission.append({"trial_id": trial["trial_id"], "input_token_ids": ids, "sha256": identity(ids), "within_limit": len(ids) <= contract.max_input_tokens})
        save_new(destination / "input_admission.json", admission)
        if not all(row["within_limit"] for row in admission):
            raise ValueError("An actual input exceeds the qualified limit; no truncation or model generation.")
        if request["stage"] == "construction":
            result = run_construction(program, approval["owner_authorization_reference"], destination, factory, tokenizer)
        else:
            result = run_calibration(request, approval["owner_authorization_reference"], destination, factory)
    except BaseException as error:
        result = {"status": "FAILED_NO_RETRY", "error_type": type(error).__name__, "error": str(error)}
    result.update(run_id=request["run_id"], request_sha256=identity(request), elapsed_seconds=time.monotonic()-started,
        model_loads=calls, automatic_retry=False, f4_accessed=False, deployment=False)
    save_new(destination / "result.json", result)
    print(json.dumps(result), flush=True)
    if result["status"] == "FAILED_NO_RETRY":
        raise SystemExit(1)

if __name__ == "__main__":
    main()
