"""Model-free, prospective calibration admission. Never edits an existing run."""
from copy import deepcopy
import json

from submission_analysis.analyze import scorer

PARENT_CASE_ID = "cal-lab-base"
PARENT_CASE_SHA256 = "e9bc7ce8331aa06f9dad75cb1e484cc4624f0955b3f2e5c11b19eeb845e78b00"

VARIANT_RULE = {
    "version": 1,
    "scope": "One prospective calibration variant; not an additional independent family.",
    "operation": "Change only the standing offer's declared compatible issue.",
    "candidates": "Permissible offers strictly worse for both parties than the original standing offer, above both reservation values.",
    "selection": "Smallest combined-payoff reduction, then canonical package key.",
    "unchanged": "All payoffs, constraints, other offer terms, priorities, scenario, instructions and family/partition.",
    "baseline": "A fresh unedited response is required; accepting the standing offer is not assumed.",
    "failure": "No feasible improvement after the baseline means stop before treatment generation, without case replacement or search expansion.",
}


def response(package, decision="accept"):
    return json.dumps({"decision": decision, "package": package})


def admission(case, baseline_response):
    """Check exact attainability of the unchanged selector using one saved answer.

    The rule is proposed joint payoff > baseline, and own payoff >= baseline.
    This is a mathematical check, not a model run or evidence of an edit effect.
    """
    s = scorer()
    s.validate_case(case)
    baseline = s.score_response(case, baseline_response)
    if not baseline["valid"]:
        return {"status": "STOP_INVALID_BASELINE", "baseline_valid": False,
                "treatments_allowed_by_feasibility": False, "execution_authorized": False}
    packages = s.enumerate_packages(case)
    values = [(p, *s.payoffs(case, p)) for p in packages]
    own, joint = baseline["proposed_self_payoff"], baseline["proposed_joint_gain"]
    higher_joint = [(p, a, b) for p, a, b in values if a + b > joint]
    eligible = [(p, a, b) for p, a, b in higher_joint if a >= own]
    status = ("FEASIBLE_IMPROVEMENT" if eligible else
              "STOP_JOINT_CEILING" if not higher_joint else "STOP_OWN_PAYOFF_CONSTRAINT")
    return {"status": status, "case_id": case["case_id"],
        "case_content_sha256": case["case_content_sha256"], "baseline_valid": True,
        "baseline_decision": baseline["decision"], "baseline_package": baseline["package"],
        "baseline_own_payoff": own, "baseline_joint_payoff": joint,
        "best_joint_payoff": max(a+b for _, a, b in values),
        "strict_joint_headroom": max(a+b for _, a, b in values)-joint,
        "feasible_packages": len(values), "higher_joint_packages": len(higher_joint),
        "eligible_packages": len(eligible),
        "witness": None if not eligible else {"package": eligible[0][0],
            "own_payoff": eligible[0][1], "counterpart_payoff": eligible[0][2],
            "joint_payoff": eligible[0][1]+eligible[0][2]},
        "treatments_allowed_by_feasibility": bool(eligible), "execution_authorized": False}


def standing_offer_check(case):
    result = admission(case, response(case["counterpart_last_package"]))
    return {**result, "reference": "Acceptance of the standing offer, not an observed model baseline."}


def after_baseline(case, baseline_response, *, continue_with_remaining):
    """Testable gate for a future caller; no provider/model/worker dependency.

    Feasibility never supplies execution authority. The caller must independently
    enforce its exact request, budget and approval before providing a continuation.
    """
    result = admission(case, baseline_response)
    if not result["treatments_allowed_by_feasibility"]:
        return {"admission": result, "remaining_called": False, "result": None}
    return {"admission": result, "remaining_called": True,
            "result": continue_with_remaining()}


def prepare_variant(case):
    """Author the declared one-field change from the table, not model outputs."""
    s = scorer()
    s.validate_case(case)
    if (case["partition"] != "calibration" or case["case_id"] != PARENT_CASE_ID
            or case["case_content_sha256"] != PARENT_CASE_SHA256):
        raise ValueError("Only the one declared original calibration case is admitted; no adaptive replacement.")
    issue = case["compatible_issue"]
    original = case["counterpart_last_package"]
    old_own, old_other = s.payoffs(case, original)
    candidates = []
    for option in s.option_map(case, issue):
        p = {**original, issue: option}
        if p == original or not s.package_allowed(case, p):
            continue
        own, other = s.payoffs(case, p)
        if (own < old_own and other < old_other
                and own >= case["reservation_values"]["self"]
                and other >= case["reservation_values"]["counterpart"]):
            candidates.append((old_own+old_other-own-other, s.package_key(p), p))
    if not candidates:
        raise ValueError("No declared one-field variant exists; do not change another field.")
    reduction, _, selected = min(candidates)
    result = deepcopy(case)
    new_id = case["case_id"] + "-headroom-v1"
    result.update(case_id=new_id, variant_id="headroom-v1", variant_of=new_id,
                  variant_kind="base", counterpart_last_package=selected)
    result["system_text"], result["user_text"] = s.render_prompt(result)
    result["case_content_sha256"] = s.case_content_sha256(result)
    s.validate_case(result)
    check = standing_offer_check(result)
    if check["status"] != "FEASIBLE_IMPROVEMENT":
        raise ValueError("Authored variant lacks the required reference headroom.")
    return result, {"rule": deepcopy(VARIANT_RULE), "parent_case_id": case["case_id"],
        "parent_case_content_sha256": case["case_content_sha256"],
        "changed_offer_issue": issue, "old_option": original[issue], "new_option": selected[issue],
        "standing_joint_payoff_reduction": reduction,
        "family_id_unchanged": result["family_id"] == case["family_id"],
        "original_retained": True, "model_outputs_used_to_rank_variant_options": False,
        "prepared_after_observing_A04_ceiling": True, "standing_offer_check": check,
        "independent_validation_case": False, "execution_authorized": False}
