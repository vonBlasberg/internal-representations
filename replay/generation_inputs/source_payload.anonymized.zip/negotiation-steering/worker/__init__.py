"""Headless qualification and execution support.

Nothing in this package authorizes model downloads, provider contact, or paid work.
"""
