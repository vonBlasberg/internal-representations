"""Additional read-only diagnostics for a separately authorized depth experiment.

The qualified state operation remains in research_pipeline.py. This subclass
records bounded scores and norms without changing logits, token choices or edits.
"""
from contextlib import contextmanager
import base64
import json
from unittest.mock import patch

import torch

from .research_pipeline import RecordedSteeringPipeline, _tensor


class DiagnosticPipeline(RecordedSteeringPipeline):
    def generate(self, *args, **kwargs):
        native = self.research_model.generate
        details = {"state_steps": [], "token_steps": []}

        def observed_native(*positional, **call):
            handles, pending = [], {}
            try:
                for layer, path in self.observation_sites:
                    def before(module, inputs, output, layer=layer):
                        pending[layer] = _tensor(output)[:, -1, :].detach().clone()
                    def after(module, inputs, output, layer=layer):
                        original = pending.pop(layer)
                        edited = _tensor(output)[:, -1, :].detach()
                        initial = original.float()
                        final = edited.float()
                        norm = float(initial.norm())
                        displacement = float((final - initial).norm())
                        if self.edit and self.edit.layer == layer and self.edit.coefficient != 0 and displacement == 0:
                            raise RuntimeError("A requested nonzero edit rounded to no realized change.")
                        row={"layer": layer,
                            "step": sum(x["layer"] == layer for x in details["state_steps"]),
                            "before_l2": norm, "after_l2": float(final.norm()),
                            "realized_l2": displacement,
                            "relative_displacement": displacement / norm if norm else None}
                        if self.edit and self.edit.layer == layer:
                            row["values"]={"dtype":str(original.dtype),"shape":list(original.shape),
                                "before":base64.b64encode(original.contiguous().view(torch.uint8).cpu().numpy().tobytes()).decode("ascii"),
                                "after":base64.b64encode(edited.contiguous().view(torch.uint8).cpu().numpy().tobytes()).decode("ascii")}
                        details["state_steps"].append(row)
                    module = self.research_model.get_submodule(path)
                    handles.append(module.register_forward_hook(before, prepend=True))
                    handles.append(module.register_forward_hook(after))
                output = native(*positional, **call)
                generated = output.sequences[0, call["input_ids"].shape[1]:]
                for index, scores in enumerate(output.scores):
                    values, ids = torch.topk(scores[0].float(), 5)
                    finite = torch.isfinite(values)
                    selected_score = scores[0, generated[index]].float()
                    maximum_score = scores[0].float().max()
                    details["token_steps"].append({"step": index,
                        "selected_token_id": int(generated[index]),
                        "selected_score": float(selected_score) if bool(torch.isfinite(selected_score)) else None,
                        "maximum_score": float(maximum_score) if bool(torch.isfinite(maximum_score)) else None,
                        "top_ids": ids.cpu().tolist(),
                        "top_scores": [float(v) if bool(ok) else None for v,ok in zip(values,finite)],
                        "top_scores_finite": finite.cpu().tolist(),
                        "top_two_margin": float(values[0] - values[1]) if bool(finite[:2].all()) else None})
                return output
            finally:
                for handle in handles:
                    handle.remove()

        try:
            with patch.object(self.research_model, "generate", new=observed_native):
                return super().generate(*args, **kwargs)
        finally:
            if self.records:
                self.records[-1]["depth_diagnostics"] = details


@contextmanager
def diagnostic_connection():
    """Use the existing Inspect connection with passive extra diagnostics only."""
    from . import preparatory_inspect
    with patch.object(preparatory_inspect, "RecordedSteeringPipeline", DiagnosticPipeline):
        yield


def proposal_changed(left, right):
    """Proposal changes are separate from agreement-adjusted outcome changes."""
    return (left.get("decision"), left.get("package")) != (right.get("decision"), right.get("package"))


@contextmanager
def typed_decision_parser():
    """Fix malformed decision types for this new run, without changing old sources."""
    from .preparatory_phases import scorer
    module = scorer()
    original = module.parse_negotiation_output
    def checked(raw, output_contract_version=1):
        try:
            return original(raw, output_contract_version)
        except TypeError:
            # Only translate the known unhashable-decision defect. Never hide an
            # unrelated programming TypeError under a generic invalid response.
            value = json.loads(raw)
            if isinstance(value, dict) and isinstance(value.get("decision"), (list, dict)):
                raise module.OutputError("DECISION", "Expected 'offer' or 'accept'.") from None
            raise
    with patch.object(module, "parse_negotiation_output", checked):
        yield
