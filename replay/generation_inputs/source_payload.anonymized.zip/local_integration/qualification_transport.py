"""Prepare, launch once, or retrieve the separately approved qualification.

Preparing and checking are local. Modal is imported only after approval and
source checks. No deployment or public endpoint is defined.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = "integration-checks/steerability-inspect-2026-10-29/upstream"
LOCK = "integration-checks/steerability-inspect-2026-10-29/requirements.local-lock.txt"
BASE_IMAGE = "im-T0JhRRVpTMVV3J7CIpVhsZ"
VOLUME = "wp3-qwen35-l40s-modal-01-data"
MOUNT = "/opt/wp3-state"
REMOTE = "/tmp/package-route-execution"
SNAPSHOT = MOUNT + "/qwen35-9b/c202236235762e1c871ad0ccb60c8ee5ba337b9a/approved-snapshot"
CLAIMS = "orgsci-package-qualification-one-use-claims"
RESULT_POINTER = "PERSISTED_QUALIFICATION_RESULT"
RESULT_MANIFEST = "QUALIFICATION_RESULT_MANIFEST"
MAX_POINTER_BYTES = 4096
MAX_MANIFEST_BYTES = 4 * 1024 * 1024
MAX_EVIDENCE_FILE_BYTES = 256 * 1024 * 1024
MAX_EVIDENCE_TOTAL_BYTES = 2 * 1024 * 1024 * 1024


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def canonical_hash(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode())


def write_new(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def safe_relative(name):
    value = Path(name)
    if not name or value.is_absolute() or ".." in value.parts or str(value) != name:
        raise ValueError("Unsafe or noncanonical transport path.")
    return value


def file_digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def result_prefix(run_id):
    if not isinstance(run_id, str) or not run_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in run_id):
        raise ValueError("Unsafe result run ID.")
    return "package-route-qualification/" + run_id + "-supervisor"


def publish_result(outer, envelope, package, commit):
    """Commit every output before returning a small reference, never file bytes."""
    outer = Path(outer)
    prefix = result_prefix(envelope["run_id"])
    if outer != Path(MOUNT) / prefix or outer.is_symlink() or outer.resolve() != (Path(MOUNT).resolve() / prefix):
        raise ValueError("Unexpected result directory.")
    files = []
    for path in sorted(outer.rglob("*")):
        if path.is_symlink():
            raise ValueError("Result evidence cannot contain symlinks.")
        if path.is_file():
            name = path.relative_to(outer).as_posix()
            safe_relative(name)
            size = path.stat().st_size
            if size > MAX_EVIDENCE_FILE_BYTES:
                raise ValueError("Evidence file exceeds the transfer bound.")
            files.append({"path": name, "size_bytes": size, "sha256": file_digest(path)})
    if sum(row["size_bytes"] for row in files) > MAX_EVIDENCE_TOTAL_BYTES:
        raise ValueError("Evidence exceeds the total transfer bound.")
    manifest = {"artifact_type": RESULT_MANIFEST, "schema_version": 1,
        "run_id": envelope["run_id"], "terminal": envelope,
        "transport_sha256": canonical_hash(package), "files": files}
    data = encoded(manifest)
    if len(data) > MAX_MANIFEST_BYTES:
        raise ValueError("Result manifest exceeds the transfer bound.")
    write_new(outer / "result-manifest.json", data)
    commit()
    pointer = {"artifact_type": RESULT_POINTER, "schema_version": 1,
        "run_id": envelope["run_id"], "status": envelope["status"], "volume": VOLUME,
        "transport_sha256": canonical_hash(package), "file_count": len(files),
        "manifest": {"path": prefix + "/result-manifest.json", "size_bytes": len(data), "sha256": digest(data)}}
    if len(encoded(pointer)) > MAX_POINTER_BYTES:
        raise ValueError("Result reference exceeds its bound.")
    return pointer


def _valid_digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def retrieve_persisted_result(directory, receipt, pointer, *, volume_class=None):
    """Read committed files once and verify their sizes and hashes locally."""
    prefix = result_prefix(receipt["run_id"])
    if len(encoded(pointer)) > MAX_POINTER_BYTES or pointer.get("schema_version") != 1 or pointer.get("run_id") != receipt["run_id"] or pointer.get("volume") != VOLUME or pointer.get("transport_sha256") != receipt["transport_sha256"]:
        raise ValueError("Result reference identity or size differs.")
    record = pointer.get("manifest", {})
    if record.get("path") != prefix + "/result-manifest.json" or type(record.get("size_bytes")) is not int or not 0 < record["size_bytes"] <= MAX_MANIFEST_BYTES or not _valid_digest(record.get("sha256")):
        raise ValueError("Invalid result manifest reference.")
    if volume_class is None:
        from modal import Volume as volume_class
    volume = volume_class.from_name(VOLUME, create_if_missing=False)
    chunks, size = [], 0
    for chunk in volume.read_file(record["path"]):
        size += len(chunk)
        if size > record["size_bytes"]:
            raise ValueError("Manifest is larger than declared.")
        chunks.append(chunk)
    data = b"".join(chunks)
    if len(data) != record["size_bytes"] or digest(data) != record["sha256"]:
        raise ValueError("Result manifest length or hash differs.")
    manifest = json.loads(data)
    if manifest.get("artifact_type") != RESULT_MANIFEST or manifest.get("schema_version") != 1 or manifest.get("run_id") != receipt["run_id"] or manifest.get("transport_sha256") != receipt["transport_sha256"]:
        raise ValueError("Manifest belongs to different execution.")
    terminal = manifest.get("terminal", {})
    if terminal.get("run_id") != receipt["run_id"] or terminal.get("status") != pointer.get("status"):
        raise ValueError("Terminal status differs from the result reference.")
    files, names, total = manifest.get("files"), set(), 0
    if not isinstance(files, list) or type(pointer.get("file_count")) is not int or len(files) != pointer["file_count"]:
        raise ValueError("Result file count differs.")
    for row in files:
        name = row["path"]
        safe_relative(name)
        if name in names or name in (".", "result-manifest.json") or type(row.get("size_bytes")) is not int or not 0 <= row["size_bytes"] <= MAX_EVIDENCE_FILE_BYTES or not _valid_digest(row.get("sha256")):
            raise ValueError("Invalid or duplicate evidence record.")
        names.add(name)
        total += row["size_bytes"]
    if total > MAX_EVIDENCE_TOTAL_BYTES or "terminal.json" not in names:
        raise ValueError("Evidence exceeds its bound or lacks its terminal record.")
    returned = Path(directory) / "returned"
    returned.mkdir(exist_ok=False)
    write_new(returned / "pointer.json", encoded(pointer))
    write_new(returned / "manifest.json", data)
    try:
        for row in files:
            target = returned / "evidence" / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            partial = target.with_name(target.name + ".partial")
            value, count = hashlib.sha256(), 0
            with partial.open("xb") as stream:
                for chunk in volume.read_file(prefix + "/" + row["path"]):
                    count += len(chunk)
                    if count > row["size_bytes"]:
                        raise ValueError("Evidence file larger than declared: " + row["path"])
                    stream.write(chunk)
                    value.update(chunk)
                stream.flush()
                os.fsync(stream.fileno())
            if count != row["size_bytes"] or value.hexdigest() != row["sha256"]:
                raise ValueError("Evidence hash or length differs: " + row["path"])
            if target.exists():
                raise FileExistsError("Evidence target already exists.")
            partial.rename(target)
        if json.loads((returned / "evidence/terminal.json").read_text()) != terminal:
            raise ValueError("Persisted terminal record differs from manifest.")
        write_new(returned / "result.json", encoded(terminal))
        write_new(returned / "retrieval.json", encoded({"status": "ALL_COMMITTED_FILES_VERIFIED", "file_count": len(files),
            "total_bytes": total, "manifest_sha256": digest(data), "launch_performed": False, "retry_performed": False}))
    except BaseException as error:
        write_new(returned / "retrieval_error.json", encoded({"status": "PARTIAL_RETRIEVAL_PRESERVED_NO_RESUBMISSION",
            "error_type": type(error).__name__, "error": str(error), "launch_performed": False, "retry_performed": False}))
        raise
    return terminal


def build_package(plan):
    from .qualification_worker import check_artifacts
    from .package_qualification import SOURCE_FILES
    check_artifacts(plan)
    paths = set(SOURCE_FILES) | {"local_integration/__init__.py", "local_integration/qualification_transport.py", LOCK}
    paths.update(item["path"] for item in plan["artifacts"].values())
    paths.update("negotiation-steering/" + item for item in (
        "worker/__init__.py", "worker/qwen35_sites.py", "analysis/__init__.py", "analysis/negotiation.py", "analysis/parse.py"))
    paths.update((path.relative_to(ROOT).as_posix()) for path in (ROOT / UPSTREAM / "steerability").rglob("*.py"))
    paths.update(UPSTREAM + "/" + name for name in ("pyproject.toml", "README.md", "LICENSE"))
    payloads = {}
    for name in sorted(paths):
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError("Transport source is missing or unsafe: " + name)
        payloads[name] = path.read_bytes()
    payloads["request/plan.json"] = encoded(plan)
    inventory = [{"path": name, "size_bytes": len(data), "sha256": digest(data)} for name, data in sorted(payloads.items())]
    package = {"artifact_type": "PACKAGE_ROUTE_QUALIFICATION_TRANSPORT", "schema_version": 1,
        "run_id": plan["run_id"], "plan_sha256": canonical_hash(plan), "files": inventory,
        "inventory_sha256": canonical_hash(inventory), "base_image_id": BASE_IMAGE,
        "gpu": "L40S", "maximum_containers": 1, "maximum_generation_calls": 10,
        "process_tree_timeout_seconds": 1800, "application_retries": 0,
        "checkpoint_download": False, "deployment": False, "owner_authorized": False}
    return package, payloads


def verify_payloads(package, payloads):
    if package.get("artifact_type") != "PACKAGE_ROUTE_QUALIFICATION_TRANSPORT" or package.get("schema_version") != 1:
        raise ValueError("Unsupported transport package.")
    if canonical_hash(package["files"]) != package["inventory_sha256"]:
        raise ValueError("Transport inventory hash differs.")
    expected = {row["path"]: row for row in package["files"]}
    if len(expected) != len(package["files"]) or set(expected) != set(payloads):
        raise ValueError("Transport file set differs or contains duplicates.")
    for name, row in expected.items():
        safe_relative(name)
        if len(payloads[name]) != row["size_bytes"] or digest(payloads[name]) != row["sha256"]:
            raise ValueError("Transport source changed: " + name)
    plan = json.loads(payloads["request/plan.json"])
    if canonical_hash(plan) != package["plan_sha256"] or plan["run_id"] != package["run_id"]:
        raise ValueError("Transport plan identity differs.")
    if package["base_image_id"] != BASE_IMAGE or package["gpu"] != "L40S" or package["maximum_containers"] != 1 or package["maximum_generation_calls"] != 10 or package["process_tree_timeout_seconds"] != 1800 or package["application_retries"] != 0 or package["checkpoint_download"] is not False or package["deployment"] is not False:
        raise ValueError("Transport limits differ from the fixed qualification.")
    return plan


def verify_authority(plan, approval, package):
    from .package_qualification import validate_approval
    validate_approval(plan, approval)
    if approval.get("transport_sha256") != canonical_hash(package) or approval.get("launch_mode") != "detached_spawn" or approval.get("provider") != "Modal":
        raise PermissionError("Approval must bind this transport and detached Modal launch.")


def run_process(command, cwd, stdout_path, stderr_path, timeout):
    """Bound only the newly created child process group; never other workers."""
    import signal
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        child = subprocess.Popen(command, cwd=cwd, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            return {"returncode": child.wait(timeout=timeout), "timed_out": False}
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            return {"returncode": child.returncode, "timed_out": True}


def remote_execute(approval, package, payloads, claim, commit):
    """Container entry. The provider supplies an atomic durable one-use claim."""
    plan = verify_payloads(package, payloads)
    if approval.get("owner_authorized") is not True or approval.get("paid_qualification_authorized") is not True or approval.get("transport_sha256") != canonical_hash(package) or approval.get("plan_sha256") != canonical_hash(plan):
        raise PermissionError("No approval for these exact remote inputs.")
    if not claim(plan["run_id"], {"plan_sha256": canonical_hash(plan), "claimed_at": time.time()}):
        return {"status": "ALREADY_CLAIMED_NO_EXECUTION", "run_id": plan["run_id"], "files": {}}
    root = Path(REMOTE)
    outer = Path(MOUNT) / "package-route-qualification" / (plan["run_id"] + "-supervisor")
    outer.mkdir(parents=True, exist_ok=False)
    write_new(outer / "claimed.json", encoded({"run_id": plan["run_id"], "plan_sha256": canonical_hash(plan), "process_id": os.getpid()}))
    commit()
    try:
        for name, data in payloads.items():
            write_new(root / safe_relative(name), data)
        write_new(root / "request/approval.json", encoded(approval))
        command = [sys.executable, "-m", "local_integration.qualification_worker", "execute",
            "--plan", str(root / "request/plan.json"), "--approval", str(root / "request/approval.json"),
            "--snapshot-root", SNAPSHOT, "--runs-root", str(outer / "attempt")]
        process = run_process(command, root, outer / "stdout.log", outer / "stderr.log", 1800)
        result_path = outer / "attempt" / plan["run_id"] / "result.json"
        status = "PASS" if process["returncode"] == 0 and result_path.is_file() and json.loads(result_path.read_text()).get("status") == "PASS" else "FAILED_OR_INDETERMINATE_NO_RETRY"
        envelope = {"status": status, "run_id": plan["run_id"], "process": process,
            "automatic_retry": False, "scientific_evidence": False, "deployment": False}
    except BaseException as error:
        envelope = {"status": "FAILED_NO_RETRY", "run_id": plan["run_id"],
            "error_type": type(error).__name__, "error": str(error), "scientific_evidence": False}
    write_new(outer / "terminal.json", encoded(envelope))
    return publish_result(outer, envelope, package, commit)


def modal_driver(package, payloads):
    """Called only after local admission; this function can contact Modal."""
    import modal
    # Reuse the preserved native base. Added packages require their own check.
    requirements = [line.strip() for line in payloads[LOCK].decode().splitlines()
        if line.strip() and not line.startswith("#") and not line.startswith("./upstream")]
    stage = Path(tempfile.mkdtemp(prefix="orgsci-qualification-image-"))
    for name, data in payloads.items():
        if name.startswith(UPSTREAM + "/"):
            write_new(stage / "upstream" / name.removeprefix(UPSTREAM + "/"), data)
    write_new(stage / "qualification_transport.py", payloads["local_integration/qualification_transport.py"])
    image = (modal.Image.from_id(BASE_IMAGE).pip_install(requirements)
        .add_local_dir(str(stage), "/opt/package-qualification-build", copy=True)
        .pip_install("/opt/package-qualification-build/upstream", extra_options="--no-deps"))
    volume = modal.Volume.from_name(VOLUME, create_if_missing=False)
    app = modal.App("orgsci-package-route-qualification", include_source=False)

    @app.function(image=image, gpu="L40S", cpu=8.0, memory=65536, volumes={MOUNT: volume},
        timeout=1860, retries=0, max_containers=1, max_inputs=1,
        block_network=True, serialized=True, include_source=False,
        env={"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
             "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false", "DO_NOT_TRACK": "1",
             "PYTHONDONTWRITEBYTECODE": "1", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
    def run(approval, package, payloads):
        import importlib.util
        import modal
        spec = importlib.util.spec_from_file_location("qualification_transport", "/opt/package-qualification-build/qualification_transport.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        # Resolve handles in the worker; do not pickle unresolved client objects.
        claims = modal.Dict.from_name(module.CLAIMS, create_if_missing=True)
        volume = modal.Volume.from_name(module.VOLUME, create_if_missing=False)
        return module.remote_execute(approval, package, payloads,
            lambda key, value: claims.put(key, value, skip_if_exists=True), volume.commit)

    return modal, app, run


def launch(plan, approval, package, payloads, directory, *, driver=modal_driver):
    if canonical_hash(verify_payloads(package, payloads)) != canonical_hash(plan):
        raise ValueError("Local and transported plans differ.")
    verify_authority(plan, approval, package)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    # Commit before the first provider contact. An uncertain submission cannot retry.
    write_new(directory / "submission_claim.json", encoded({"run_id": plan["run_id"],
        "plan_sha256": canonical_hash(plan), "transport_sha256": canonical_hash(package), "automatic_retry": False}))
    try:
        modal, app, function = driver(package, payloads)
        with modal.enable_output(), app.run(detach=True):
            call = function.spawn(approval, package, payloads)
            receipt = {"artifact_type": "PACKAGE_QUALIFICATION_DETACHED_LAUNCH", "run_id": plan["run_id"],
                "modal_app_id": app.app_id, "modal_function_call_id": call.object_id,
                "transport_sha256": canonical_hash(package), "status": "SUBMITTED_NOT_VERIFIED"}
            if not receipt["modal_app_id"] or not receipt["modal_function_call_id"]:
                raise RuntimeError("Submission returned no usable handle; never resubmit.")
            write_new(directory / "launch.json", encoded(receipt))
            return receipt
    except BaseException as error:
        write_new(directory / "submission_error.json", encoded({"status": "ERROR_OR_INDETERMINATE_NO_RETRY",
            "error_type": type(error).__name__, "error": str(error)}))
        raise


def retrieve(directory, *, function_call_class=None, volume_class=None):
    directory = Path(directory)
    receipt = json.loads((directory / "launch.json").read_text())
    if receipt.get("artifact_type") != "PACKAGE_QUALIFICATION_DETACHED_LAUNCH" or not receipt.get("modal_function_call_id"):
        raise ValueError("An existing launch handle is required.")
    if (directory / "returned").exists():
        raise FileExistsError("The returned evidence is already preserved.")
    if function_call_class is None:
        from modal import FunctionCall as function_call_class
    try:
        result = function_call_class.from_id(receipt["modal_function_call_id"]).get(timeout=0)
    except TimeoutError:
        return {"status": "PENDING_NO_RESUBMISSION", "modal_function_call_id": receipt["modal_function_call_id"]}
    if result.get("run_id") != receipt["run_id"]:
        raise ValueError("Returned evidence belongs to a different run.")
    if result.get("artifact_type") == RESULT_POINTER:
        return retrieve_persisted_result(directory, receipt, result, volume_class=volume_class)
    # Historical attempts returned file bytes. Keep their read path unchanged.
    for name in result["files"]:
        safe_relative(name)
    returned = directory / "returned"
    returned.mkdir(exist_ok=False)
    for name, data in result.pop("files").items():
        write_new(returned / "evidence" / name, data)
    write_new(returned / "result.json", encoded(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "check", "launch", "retrieve"))
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--approval", type=Path)
    args = parser.parse_args()
    if args.action == "retrieve":
        print(json.dumps(retrieve(args.request / "launch")))
        return
    plan = json.loads((args.request / "plan.json").read_text())
    package, payloads = build_package(plan)
    verify_payloads(package, payloads)
    package_path = args.request / "transport.json"
    if args.action == "prepare":
        draft = json.loads((args.request / "approval.NOT_AUTHORIZED.json").read_text())
        if draft.get("owner_authorized") is not False or draft.get("paid_qualification_authorized") is not False:
            raise PermissionError("Preparation must start from an unapproved request.")
        draft.update(transport_sha256=canonical_hash(package), launch_mode="detached_spawn", provider="Modal")
        write_new(package_path, encoded(package))
        write_new(args.request / "transport-approval.NOT_AUTHORIZED.json", encoded(draft))
        print("Prepared transport. No provider contact or execution.")
        return
    if package_path.read_bytes() != encoded(package):
        raise ValueError("Current sources differ from the prepared transport; do not launch.")
    if args.action == "check":
        print(json.dumps({"status": "OFFLINE_TRANSPORT_CHECK_PASS", "files": len(payloads),
            "transport_sha256": canonical_hash(package), "execution_authorized": False, "provider_contacted": False}))
        return
    if args.approval is None:
        raise PermissionError("A new owner approval is required before launch.")
    approval = json.loads(args.approval.read_text())
    print(json.dumps(launch(plan, approval, package, payloads, args.request / "launch")))


if __name__ == "__main__":
    main()
