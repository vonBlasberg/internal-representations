# Proposed calibration ceiling correction

October 30, 2026. Prepared and tested locally at the owner's request. This document does not adopt a new research design or authorize execution. A04, its case, source, settings and results remain unchanged. F4 remains paused and untouched.

## Reason for the correction

A04's saved baseline accepts an offer worth 75 points to the buyer and 72 to the supplier. Its total, 147, equals the maximum across all 72 permissible offers. The unchanged selector requires strictly higher proposed joint payoff without reducing proposed own payoff. No valid response can satisfy that rule on this baseline.

The existing case validation checks whether some pair of offers has a Pareto improvement. It does not check whether an improvement remains possible from the actual model baseline. The new local check closes that gap without weakening the selector.

## One separately versioned input

Preserve `cal-lab-base` with content hash `e9bc7ce8331aa06f9dad75cb1e484cc4624f0955b3f2e5c11b19eeb845e78b00`.

The proposed `cal-lab-base-headroom-v1` changes only the standing offer's payment term from `net_30` to `net_60`. Its content hash is `cf3a0608480d5628ee28c477cce8fc7307749a450d6e9204f99daf4e6a442c74`. Price, delivery, warranty, payoff tables, constraints, reservation values, stated priorities, scenario and instructions remain unchanged. New identifiers, rendered prompt and content hash record the change. The case remains in the same `cal-lab` calibration family; it is not another independent family or held-out case.

The authoring rule considers only permissible changes to the declared compatible issue that lower both parties' standing-offer payoffs while preserving their reservation values. It chooses the smallest total reduction, with a fixed lexical tie-break. It ranks no new model outputs and permits no second adaptive variant. The decision to prepare this correction follows the observed A04 ceiling and must be disclosed as such.

Acceptance of the proposed standing offer would yield 70 buyer points and 67 supplier points, totaling 137. Returning to `net_30` would add 5 points to each party. Seventeen permissible offers satisfy the original improvement rule relative to acceptance of the new standing offer. These are exact table calculations, not predicted model behavior. This simple shared gain tests feasibility, not a general negotiation capability.

## Stop before an impossible comparison

1. Before any future execution, validate the exact case and enumerate its permissible offers. Record the standing-offer reference check explicitly as hypothetical acceptance, not a model baseline.
2. Under separate one-use execution authority, obtain one fresh unedited baseline. Do not reuse A04's response for the changed input.
3. Before any prompt, sham or nonzero-edit generation, enumerate offers with strictly higher proposed joint payoff and no lower proposed own payoff than that actual response.
4. Stop if the response is invalid or no offer qualifies. Record the baseline and the exact reason. Do not replace the case again, relax the rule, increase strengths or launch another attempt automatically.
5. Only if both feasibility and separate execution checks pass may a future worker perform the remaining unchanged conditions. A feasible baseline is not evidence that steering works.

`headroom.py` implements this calculation and a continuation gate tested with synthetic callbacks. It has no model/provider dependency. The current worker and its frozen source are not patched. Adopting the correction would require a new immutable request and worker connection, tested with this gate; no such executable request or approval was created here.

## What does not change

Reuse the verified A04 construction and direction/control files if execution is later authorized. Do not repeat construction. Model checkpoint, precision, sites, raw-direction estimator, coefficients, prompt alternatives, control draws, scorer, candidate-selection rule and time/generation caps remain as in A04. Development, untouched evaluation, deployment, F4 and manuscript changes are outside this preparation.

All new local artifacts and successful checks are retained separately. The existing A04 call remains under its original read-only completion monitor. Its eventual terminal outcome must be reported on its original case, not replaced by this proposal.
