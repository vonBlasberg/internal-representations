"""Independent capture audit without loading the research model.

audit_attempt replays construction artifacts. audit additionally verifies the
delivered inventory, source and outer process. Neither opens calibration.
"""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import tempfile

import torch

from .expanded_capture import audit_selected_states
from .direction_construction import ConstructedDirections, ConstructionSpec, input_hash
from .package_qualification import validate_plan
from .preparatory_phases import identity, save_new
from .preparatory_worker import generate_control_files
from . import expanded_references as references
from .generation_sensitivity import snapshot_attestation, PACKAGE_VERSIONS
from . import qualification_transport as delivery
from steerability.algorithms.state_control.common.steering_vector import SteeringVector

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_WIDTH = 4096


def read(path):
    return json.loads(Path(path).read_text())


def check(value, message):
    if not value:
        raise ValueError(message)


def replay_vectors(program, evidence, pairs, spec):
    """Replay raw/normalized vectors and fixed controls from retained states."""
    evidence = Path(evidence)
    means = audit_selected_states(evidence, pairs, spec)
    header = read(evidence / 'constructed/construction.json')
    expected_flags = {'pair_count': references.PAIR_COUNT, 'capture_forward_count': references.FORWARD_COUNT, 'generation_calls': 0,
        'hooks_after': 0, 'capture_cache': False, 'capture_dtype': 'bfloat16', 'batch_size': 1,
        'estimator': 'equal_pair_mean_positive_minus_negative', 'scientific_finding': False,
        'synthetic_test': spec.synthetic_test, 'release_authorized': False, 'behavioral_qualification': False}
    check(all(header.get(key) == value for key, value in expected_flags.items()), 'Construction estimator or scope differs.')
    expected_files = {'raw.svec', 'normalized.svec'} | {
        f'layer-{layer}-{form}.f32le' for layer, _ in spec.sites for form in ('raw', 'normalized')}
    check(set(header['files']) == expected_files, 'Direction inventory differs.')
    check({path.name for path in (evidence / 'constructed').iterdir()} == expected_files | {'construction.json'},
          'Constructed directory inventory differs.')
    check(header['construction_spec_sha256'] == identity(asdict(spec)), 'Construction specification hash differs.')
    for name, entry in header['files'].items():
        raw = (evidence / 'constructed' / name).read_bytes()
        check(hashlib.sha256(raw).hexdigest() == entry['sha256'] and len(raw) == entry['bytes'], 'Direction file changed: ' + name)
    raw_vectors = {}
    for layer, _ in spec.sites:
        total = torch.zeros((1, spec.hidden_width), dtype=torch.float32)
        for row in header['pairs']:
            values = [torch.tensor(row['responses'][label]['pooled_states'][str(layer)], dtype=torch.float32).reshape(1, -1)
                      for label in ('positive', 'negative')]
            check(all(value.shape == total.shape and torch.isfinite(value).all() for value in values), 'Invalid response mean.')
            total += values[0] - values[1]
        value = total / len(pairs)
        check(torch.isfinite(value).all() and torch.isfinite(value.norm()) and value.norm() > 0, 'Invalid target direction.')
        raw_vectors[layer] = value
        check(value.numpy().astype('<f4').tobytes() == (evidence / 'constructed' / f'layer-{layer}-raw.f32le').read_bytes(),
              'Raw direction does not reproduce from paired response means.')
    vector = SteeringVector(model_type=spec.model_type, directions=raw_vectors)
    normalized = vector.normalized()
    for layer in raw_vectors:
        check(normalized.directions[layer].numpy().astype('<f4').tobytes()
              == (evidence / 'constructed' / f'layer-{layer}-normalized.f32le').read_bytes(),
              'Normalized direction does not reproduce.')
    metadata_keys = {'model_fingerprint', 'location', 'construction_spec',
                     'construction_spec_sha256', 'release_authorized', 'behavioral_qualification'}
    metadata_keys.update(key for key in ('config_fingerprint', 'chat_template_fingerprint') if key in header)
    expected_metadata = {key: header[key] for key in metadata_keys}
    check(identity(expected_metadata['construction_spec']) == identity(asdict(spec))
          and expected_metadata['location'] == spec.location, 'Native vector construction metadata differs.')
    for form, expected_vector in (('raw', vector), ('normalized', normalized)):
        path = evidence / 'constructed' / (form + '.svec')
        serialized = read(path)
        check(set(serialized) == {'model_type', 'directions', 'meta'}, 'Native vector fields differ: ' + form)
        loaded = SteeringVector.load(str(path))
        check(loaded.model_type == spec.model_type and set(loaded.directions) == set(raw_vectors)
              and identity(loaded.meta) == identity(expected_metadata), 'Native vector identity or metadata differs: ' + form)
        for layer, expected_values in expected_vector.directions.items():
            values = loaded.directions[layer]
            check(values.shape == expected_values.shape and values.dtype == torch.float32
                  and torch.isfinite(values).all() and torch.equal(values, expected_values),
                  'Native vector does not reproduce from retained states: ' + form)
    with tempfile.TemporaryDirectory(prefix='buyer-control-replay-') as temporary:
        controls = Path(temporary) / 'controls'
        generate_control_files(program, ConstructedDirections(vector, normalized, header), controls)
        check({path.name for path in controls.iterdir()} == {path.name for path in (evidence / 'directions').iterdir()},
              'Control file inventory differs.')
        for path in controls.iterdir():
            check(path.read_bytes() == (evidence / 'directions' / path.name).read_bytes(), 'Fixed control does not reproduce: ' + path.name)
    return {**means, 'raw_and_normalized_vectors_reproduced': True,
            'native_svec_vectors_reproduced': True,
            'fixed_controls_reproduced': True, 'candidate_selected': False}


def audit_attempt(request, approval, evidence, tokenizer, *, root=ROOT):
    """Recompute every construction artifact after separately checking delivery."""
    evidence = Path(evidence)
    program = request['program']
    qualification = program['qualification_plan']
    contract = validate_plan(qualification)
    attestation = snapshot_attestation(qualification, root)
    started, result = read(evidence / 'started.json'), read(evidence / 'result.json')
    check(started['request'] == request and started['approval'] == approval
          and started['request_sha256'] == identity(request), 'Admission record differs.')
    required = {'status': 'EXPANDED_CONSTRUCTION_COMPLETE', 'run_id': request['run_id'],
        'request_sha256': identity(request), 'model_load_attempts': 1,
        'generation_calls': 0, 'capture_forwards': references.FORWARD_COUNT,
        'attempted_forwards': references.FORWARD_COUNT, 'retained_captures': references.FORWARD_COUNT,
        'selected_token_states_retained': True, 'forward_restored': True,
        'calibration_started': False, 'candidate_selected': False, 'behavioral_result': False, 'automatic_retry': False}
    check(all(result.get(key) == value for key, value in required.items())
          and 0 < result['elapsed_seconds'] <= request['limits']['maximum_wall_seconds'], 'Result scope or counts differ.')
    check(read(evidence / 'authored_references.json') == request['construction_source']['references'], 'Authored references changed.')
    pairs, tokens = references.token_inputs(program['cases']['construction_fit'],
        request['construction_source']['references'], tokenizer, asdict(contract))
    check(read(evidence / 'teacher_forcing_inputs.json') == tokens, 'Actual token inputs differ.')
    loaded = read(evidence / 'capture_model/loaded_model.json')
    check(loaded['admitted_model_id'] == contract.model_id and loaded['admitted_model_revision'] == contract.model_revision
          and loaded['weights']['entries_sha256'] == qualification['model_weight_entries_sha256']
          and identity(loaded['generation_contract']) == identity(asdict(contract))
          and loaded['research_checkpoint_loaded'] is True, 'Loaded research checkpoint differs.')
    check(read(evidence / 'weights_after.json') == loaded['weights'] and result.get('weights_unchanged') is True,
          'Model parameters or buffers were not verified unchanged after construction.')
    expected_snapshot = {'status': 'EXACT_LOCAL_SNAPSHOT_VERIFIED', 'files': len(attestation['files']),
        'total_bytes': attestation['total_bytes'], 'inventory_sha256': identity(attestation['files']),
        'download_performed': False}
    check(read(evidence / 'capture_model/snapshot.json') == expected_snapshot, 'Checkpoint snapshot receipt differs.')
    token_names = {'tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja', 'config.json', 'merges.txt', 'vocab.json'}
    token_files = {entry['path']: entry['sha256'] for entry in attestation['files'] if entry['path'] in token_names}
    check(set(token_files) == token_names and read(evidence / 'tokenizer_check.json')
          == {'before_model_load': True, 'files': token_files}, 'Pre-load tokenizer receipt differs.')
    runtime = read(evidence / 'capture_model/runtime.json')
    reference = qualification['runtime_reference']
    check(runtime['versions'] == reference['actual_runtime_versions']
          and runtime['optional_kernels'] == reference['optional_kernel_module_visibility']
          and runtime['gpu']['name'] == reference['actual_gpu']['name']
          and runtime['gpu']['driver_version'] == reference['actual_gpu']['driver_version']
          and runtime['gpu']['bf16_supported'] is True
          and abs(runtime['gpu']['total_memory_gib'] - reference['actual_gpu']['total_memory_gib']) <= .1
          and runtime['packages'] == PACKAGE_VERSIONS, 'Qualified runtime differs.')
    spec = ConstructionSpec(contract.model_id, contract.model_revision, contract.model_type,
        tuple(tuple(site) for site in program['sites']), EXPECTED_WIDTH, tuple(pair.pair_id for pair in pairs), input_hash(pairs),
        tuple(family for family, partition in program['family_partitions'].items() if partition != 'construction_fit'),
        program['pooling'], program['accumulation_dtype'], program['insertion_dtype'],
        contract.max_input_tokens + contract.max_new_tokens, contract.synthetic_test)
    check(identity(read(evidence / 'capture/construction_spec.json')) == identity(asdict(spec)), 'Capture specification differs.')
    capture_result = read(evidence / 'capture/capture_result.json')
    check(capture_result['status'] == 'EXPANDED_CAPTURE_COMPLETE'
          and all(capture_result.get(key) == result.get(key) for key in required if key not in (
              'status', 'run_id', 'request_sha256', 'model_load_attempts')), 'Nested capture result differs.')
    verified = replay_vectors(program, evidence / 'capture', pairs, spec)
    from .direction_construction import construct_directions, capture_hidden, aggregate_condition_hidden, artifact_provenance_meta
    header = read(evidence / 'capture/constructed/construction.json')
    source_hashes = {name: hashlib.sha256(Path(inspect.getfile(function)).read_bytes()).hexdigest()
                    for name, function in {'capture': capture_hidden, 'pooling': aggregate_condition_hidden,
                        'vector': SteeringVector, 'fingerprint': artifact_provenance_meta}.items()}
    check(header['implementation_sha256'] == hashlib.sha256(Path(inspect.getfile(construct_directions)).read_bytes()).hexdigest()
          and header['package_source_sha256'] == source_hashes, 'Construction implementation source differs.')
    check(header['packages'] == {'steerability': PACKAGE_VERSIONS['steerability'],
        'torch': reference['actual_runtime_versions']['pytorch'].split('+')[0],
        'transformers': reference['actual_runtime_versions']['transformers']}, 'Construction package versions differ.')
    check(result['directions'] == capture_result['directions']
          == read(evidence / 'capture/directions/directions.json')['directions'], 'Result direction manifest differs.')
    return {'status': 'CONSTRUCTION_ARTIFACTS_REPLAYED', **verified,
            'outer_delivery_source_and_process_checks_still_required': True,
            'research_model_loaded': False, 'calibration_authorized': False}


def verify_delivery(returned, request, package):
    returned = Path(returned)
    receipt, manifest = read(returned / 'retrieval.json'), read(returned / 'manifest.json')
    check(receipt['status'] == 'ALL_COMMITTED_FILES_VERIFIED'
          and receipt['manifest_sha256'] == delivery.file_digest(returned / 'manifest.json'), 'Delivery is incomplete or changed.')
    check(manifest['run_id'] == request['run_id'] and manifest['transport_sha256'] == identity(package), 'Wrong returned request.')
    names = [entry['path'] for entry in manifest['files']]
    check(len(names) == len(set(names)) == receipt['file_count']
          and set(names) == {path.relative_to(returned / 'evidence').as_posix()
                            for path in (returned / 'evidence').rglob('*') if path.is_file()}, 'Returned inventory differs.')
    for entry in manifest['files']:
        path = returned / 'evidence' / delivery.safe_relative(entry['path'])
        check(not path.is_symlink() and path.stat().st_size == entry['size_bytes']
              and delivery.file_digest(path) == entry['sha256'], 'Returned bytes changed: ' + entry['path'])
    terminal = read(returned / 'evidence/terminal.json')
    check(terminal == manifest['terminal'] == read(returned / 'result.json'), 'Outer terminal copies differ.')
    check(terminal['run_id'] == request['run_id'] and terminal['request_sha256'] == identity(request), 'Outer process identity differs.')
    return terminal, len(names)


def audit():
    from . import expanded_run as run
    request, approval, package, _ = run.load()
    returned = run.DIRECTORY / 'launch/returned'
    terminal, count = verify_delivery(returned, request, package)
    check(terminal['status'] == 'EXPANDED_CONSTRUCTION_COMPLETE'
          and terminal['process']['returncode'] == 0 and terminal['process'].get('timed_out') is False,
          'Execution failed or is indeterminate; never substitute a successful audit.')
    qualification = request['program']['qualification_plan']
    snapshot = run.ROOT / 'negotiation-steering/snapshots/qwen35-9b' / qualification['generation_contract']['model_revision'] / 'verified-snapshot'
    from .generation_sensitivity import verify_tokenizer_files
    from transformers import AutoTokenizer
    hashes = verify_tokenizer_files(qualification, snapshot, run.ROOT)
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False, use_fast=True)
    report = audit_attempt(request, approval, returned / 'evidence/attempt', tokenizer, root=run.ROOT)
    check(read(returned / 'evidence/attempt/tokenizer_check.json')['files'] == hashes, 'Local tokenizer and worker differ.')
    report.update(status='EXPANDED_CONSTRUCTION_VERIFIED', run_id=request['run_id'],
        request_sha256=identity(request), outer_delivery_source_and_process_checks_still_required=False,
        outer_terminal=terminal, returned_files_verified=count,
        protected_originals_unchanged=len(read(run.DIRECTORY / 'preserved_before.json')),
        checked_at_utc=datetime.now(timezone.utc).isoformat(), provider_contact=False,
        calibration_authorized=False, retry_performed=False)
    save_new(run.DIRECTORY / 'terminal_audit.json', report)
    return report
