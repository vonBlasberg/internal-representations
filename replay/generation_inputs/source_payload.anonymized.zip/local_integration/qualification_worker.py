"""Offline-snapshot GPU worker for a separately approved package qualification.

The default command only checks the plan. There is no provider launch, download,
deployment or retry entry point. A provider supervisor must supply the approved
container and enforce the same wall limit around the whole process tree.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import gc
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1",
    HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false", DO_NOT_TRACK="1",
    PYTHONDONTWRITEBYTECODE="1")

from .direction_construction import canonical_hash
from .package_qualification import ROOT, execute, validate_approval, validate_plan
from worker.generation import generate_with_receipts
from worker.receipts import weight_fingerprint
from worker.wp3_runner import file_sha256, load_json, write_immutable_json


def read_artifact(plan, name):
    record = plan["artifacts"][name]
    relative = Path(record["path"])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Artifact paths must remain inside the submitted source tree.")
    path = ROOT / relative
    if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("A declared artifact is missing or escapes the submitted source tree.")
    if file_sha256(path) != record["sha256"]:
        raise ValueError("Artifact hash changed: " + name)
    return path


def verify_snapshot(snapshot_root, attestation, contract):
    """Verify regular local checkpoint files only. Never fetch missing files."""
    root = Path(snapshot_root)
    if not root.is_dir() or root.is_symlink():
        raise ValueError("The admitted local snapshot directory is missing.")
    if attestation.get("artifact_type") != "WP3_MODEL_SNAPSHOT_ATTESTATION" or (
        attestation.get("model_id"), attestation.get("model_revision")) != (contract.model_id, contract.model_revision):
        raise ValueError("Snapshot identity differs from the qualification plan.")
    expected = {}
    for record in attestation["files"]:
        name = record["path"]
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or name in expected:
            raise ValueError("Unsafe or duplicate snapshot inventory path.")
        expected[name] = record
    if not expected:
        raise ValueError("A nonempty snapshot inventory is required.")
    actual = {path.relative_to(root).as_posix(): path for path in root.rglob("*") if path.is_file() or path.is_symlink()}
    if set(actual) != set(expected):
        raise ValueError("Local snapshot files differ from the attested inventory.")
    for name, path in actual.items():
        entry = expected[name]
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()) or path.stat().st_size != entry["size_bytes"] or file_sha256(path) != entry["sha256"]:
            raise ValueError("Checkpoint file differs from attestation: " + name)
    total = sum(path.stat().st_size for path in actual.values())
    if total != attestation["total_bytes"]:
        raise ValueError("Snapshot byte total differs from attestation.")
    return {"status": "EXACT_LOCAL_SNAPSHOT_VERIFIED", "files": len(actual), "total_bytes": total,
            "inventory_sha256": canonical_hash(attestation["files"]), "download_performed": False}


def runtime_identity(plan):
    import torch
    expected = plan["runtime_reference"]
    actual = {"python": platform.python_version(), "pytorch": torch.__version__,
              "transformers": importlib.metadata.version("transformers"), "cuda": torch.version.cuda}
    if actual != expected["actual_runtime_versions"]:
        raise RuntimeError("Runtime differs from the admitted native reference.")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1 or not torch.cuda.is_bf16_supported():
        raise RuntimeError("One BF16-capable CUDA GPU is required.")
    gpu = {"name": torch.cuda.get_device_name(0),
           "total_memory_gib": torch.cuda.get_device_properties(0).total_memory / 1024**3,
           "driver_version": subprocess.check_output(
               ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"], text=True, timeout=30).strip(),
           "bf16_supported": True}
    declared = expected["actual_gpu"]
    if gpu["name"] != declared["name"] or gpu["driver_version"] != declared["driver_version"] or abs(gpu["total_memory_gib"] - declared["total_memory_gib"]) > 0.1:
        raise RuntimeError("GPU or driver differs from the admitted reference.")
    optional = {name: importlib.util.find_spec(name) is not None for name in ("causal_conv1d", "fla", "triton")}
    if optional != expected["optional_kernel_module_visibility"]:
        raise RuntimeError("Optional kernel availability differs from the admitted reference.")
    return {"versions": actual, "gpu": gpu, "optional_kernels": optional,
            "packages": {name: importlib.metadata.version(name) for name in ("steerability", "inspect-ai")}}


def load_admitted_model(plan, snapshot_root, directory):
    """Called only inside the separately authorized execution or restoration path."""
    import numpy as np
    import torch
    from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration
    contract = validate_plan(plan)
    if contract.synthetic_test or contract.model_id != "Qwen/Qwen3.5-9B" or contract.model_revision != "c202236235762e1c871ad0ccb60c8ee5ba337b9a" or contract.dtype != "bfloat16":
        raise ValueError("This loader admits only the declared Qwen3.5-9B BF16 snapshot.")
    identity = runtime_identity(plan)
    write_immutable_json(directory / "runtime.json", identity)
    attestation = load_json(read_artifact(plan, "snapshot_attestation"))
    snapshot = verify_snapshot(snapshot_root, attestation, contract)
    write_immutable_json(directory / "snapshot.json", snapshot)
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot_root), local_files_only=True, trust_remote_code=False, use_fast=True)
    tokenizer.padding_side = "left"
    model = Qwen3_5ForConditionalGeneration.from_pretrained(str(snapshot_root), local_files_only=True,
        trust_remote_code=False, dtype=torch.bfloat16, attn_implementation="eager")
    model.generation_config.pad_token_id = contract.pad_token_id
    model.generation_config.eos_token_id = list(contract.eos_token_ids)
    model.to("cuda:0")
    model.eval()
    model.set_attn_implementation("eager")
    weights = weight_fingerprint(model)
    if weights["entries_sha256"] != plan["model_weight_entries_sha256"]:
        raise RuntimeError("The loaded model weights differ from the preserved reference.")
    original_metadata = {"name_or_path": model.config._name_or_path,
                         "commit_hash": getattr(model.config, "_commit_hash", None)}
    # HF local-directory loading does not retain Hub identity. Bind that metadata
    # only after verifying every snapshot file and the loaded native-weight hash.
    model.config._name_or_path = contract.model_id
    model.config._commit_hash = contract.model_revision
    direction_bytes = read_artifact(plan, "instrumentation_direction").read_bytes()
    direction = torch.from_numpy(np.frombuffer(direction_bytes, dtype="<f4").copy()).reshape(1, -1)
    write_immutable_json(directory / "loaded_model.json", {"weights": weights,
        "original_local_load_metadata": original_metadata, "admitted_model_id": contract.model_id,
        "admitted_model_revision": contract.model_revision,
        "hub_identity_metadata_bound_after_snapshot_and_weight_verification": True,
        "generation_contract": asdict(contract), "direction_sha256": hashlib.sha256(direction_bytes).hexdigest(),
        "research_checkpoint_loaded": True, "scientific_evidence": False})
    return model, tokenizer, direction


def check_artifacts(plan):
    contract = validate_plan(plan)
    for name in plan["artifacts"]:
        read_artifact(plan, name)
    for index, item in enumerate(plan["inputs"]):
        original = load_json(read_artifact(plan, f"input_{index}"))
        reference = load_json(read_artifact(plan, f"reference_{index}"))
        scored = load_json(read_artifact(plan, f"score_{index}"))
        if any(item[key] != original[key] for key in ("case_id", "messages", "input_token_ids", "input_token_ids_sha256")):
            raise ValueError("Qualification input differs from its preserved record.")
        if any(item["native_reference"][key] != reference["receipt"][key] for key in ("input_token_ids", "generated_token_ids", "processed_logit_steps")):
            raise ValueError("Reference generation differs from its preserved record.")
        # The preserved v2 contract asks for decision and package only. Payoffs
        # are computed by the scorer; null model-payoff claims are not failures.
        if scored["score"]["valid"] is not True or scored["score"]["technical_status"] != "COMPLETED":
            raise ValueError("The preserved competence score did not pass.")
        if scored["raw_artifact_sha256"] != plan["artifacts"][f"reference_{index}"]["sha256"] or reference["input_receipt"]["sha256"] != plan["artifacts"][f"input_{index}"]["sha256"]:
            raise ValueError("The preserved input, response and score records are not linked by their hashes.")
        if scored["case_id"] != item["case_id"] or reference["case_id"] != item["case_id"]:
            raise ValueError("The preserved records refer to different cases.")
    identity = load_json(read_artifact(plan, "identity"))
    if plan["model_weight_entries_sha256"] != identity["model_weight_entries_sha256"] or contract.generation_config_sha256 != canonical_hash(identity["loaded_generation_config"]):
        raise ValueError("Model weights or generation defaults differ from the preserved reference.")
    expected_runtime = {key: identity[key] for key in ("actual_runtime_versions", "actual_gpu", "optional_kernel_module_visibility")}
    if plan["runtime_reference"] != expected_runtime:
        raise ValueError("Runtime requirements differ from the preserved reference.")
    manifest = load_json(read_artifact(plan, "native_manifest"))
    generation = manifest["generation"]
    expected_contract = {
        "model_id": identity["model_id"], "model_revision": identity["model_revision"],
        "model_type": "qwen3_5", "dtype": "bfloat16", "synthetic_test": False,
        "chat_template_sha256": identity["tokenizer"]["chat_template_sha256"],
        "max_input_tokens": manifest["input_preparation"]["max_input_tokens_per_trial"],
        "max_new_tokens": generation["max_new_tokens"], "min_new_tokens": generation["min_new_tokens"],
        "eos_token_ids": tuple(generation["generation_eos_token_ids"]), "pad_token_id": generation["pad_token_id"],
        "attention_implementation": "eager", "max_generation_calls": 1}
    if any(getattr(contract, key) != value for key, value in expected_contract.items()):
        raise ValueError("Generation contract differs from the preserved native qualification.")
    if plan["direction_sha256"] != plan["artifacts"]["instrumentation_direction"]["sha256"]:
        raise ValueError("Instrumentation direction differs from its preserved bytes.")
    native = load_json(read_artifact(plan, "native_qualification"))
    if native.get("status") != "PASS" or native.get("wp3_qualified") is not True:
        raise ValueError("The preserved native route must already have final mechanical qualification.")
    return {"status": "OFFLINE_ARTIFACT_CHECK_PASS", "artifact_count": len(plan["artifacts"]),
        "model_loaded": False, "provider_contacted": False, "execution_authorized": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "execute", "restore-child"))
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--approval", type=Path)
    parser.add_argument("--snapshot-root", type=Path)
    parser.add_argument("--runs-root", type=Path)
    args = parser.parse_args()
    plan = load_json(args.plan)
    checked = check_artifacts(plan)
    if args.action == "check":
        print(json.dumps(checked, sort_keys=True))
        return
    if args.approval is None or args.snapshot_root is None or args.runs_root is None:
        raise PermissionError("Execution needs explicit approval, an existing snapshot and a fixed run directory.")
    approval = load_json(args.approval)
    validate_approval(plan, approval)
    contract = validate_plan(plan)
    directory = args.runs_root / plan["run_id"]
    if args.action == "restore-child":
        if (directory / "failure.json").exists() or (directory / "result.json").exists():
            raise PermissionError("A terminal attempt cannot start another restoration.")
        parent = load_json(directory / "started.json")
        if parent["plan_sha256"] != canonical_hash(plan) or parent["process_id"] != os.getppid():
            raise PermissionError("Fresh restoration is not bound to the active parent attempt.")
        for name in ("native-baseline-1", "native-baseline-2", "package-baseline-1", "package-baseline-2", "package-zero", "native-linear-edit", "package-linear-edit", "native-full-edit", "package-full-edit"):
            if load_json(directory / name / "check.json")["status"] != "PASS":
                raise PermissionError("Fresh restoration cannot precede all parent checks.")
        child_dir = directory / "fresh-child"
        child_dir.mkdir(exist_ok=False)
        write_immutable_json(child_dir / "started.json", {"process_id": os.getpid(), "parent_process_id": parent["process_id"]})
        model, tokenizer, direction = load_admitted_model(plan, args.snapshot_root, child_dir)
        import torch
        ids = torch.tensor([plan["inputs"][1]["input_token_ids"]], dtype=torch.long, device="cuda:0")
        output = generate_with_receipts(model, {"input_ids": ids, "attention_mask": torch.ones_like(ids)},
            trial_id="fresh-restoration", max_new_tokens=contract.max_new_tokens,
            min_new_tokens=contract.min_new_tokens, eos_token_id=list(contract.eos_token_ids))
        output.receipt.update(process_id=os.getpid(), fresh_process=True, research_checkpoint_used=True)
        write_immutable_json(child_dir / "execution.json", output.receipt)
        return

    def factory(value):
        return load_admitted_model(value, args.snapshot_root, directory)

    def restore(value, location):
        # The parent core has released the model and cache before this callback.
        completed = subprocess.run([sys.executable, "-m", "local_integration.qualification_worker", "restore-child",
            "--plan", str(args.plan.resolve()), "--approval", str(args.approval.resolve()),
            "--snapshot-root", str(args.snapshot_root.resolve()), "--runs-root", str(args.runs_root.resolve())],
            cwd=ROOT, capture_output=True, text=True, timeout=value["maximum_wall_seconds"], check=False)
        write_immutable_json(location / "fresh-child-process.json", {"returncode": completed.returncode,
            "stdout": completed.stdout, "stderr": completed.stderr, "retry_count": 0})
        if completed.returncode:
            raise RuntimeError("Fresh-process restoration failed; inspect the preserved process log.")
        return load_json(location / "fresh-child/execution.json")

    result = execute(plan, approval, args.runs_root, model_factory=factory, fresh_process_restore=restore)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
