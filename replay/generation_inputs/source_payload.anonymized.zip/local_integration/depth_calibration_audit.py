"""Independent audit of one-load A06 calibration, without research model loading."""
from dataclasses import asdict
from datetime import datetime, timezone
import base64
import json
import math
from pathlib import Path

import torch
from inspect_ai.log import read_eval_log

from . import depth_calibration_run as run
from .depth_audit import require, near, decode_state
from .depth_calibration_worker import REUSE_POLICY
from .depth_diagnostics import typed_decision_parser, proposal_changed
from .headroom_worker import gate_module
from .construction_program import phase_plan, calibration_arms
from .package_qualification import validate_plan
from .preparatory_phases import identity, save_new, checked_scores, summarize_calibration
from .calibration_selection import select
from worker.receipts import tensor_sha256


def read(path):
    return json.loads(Path(path).read_text())


def audit_record(record, trial, contract, weights, ids, direction=None):
    require(record['status'] == 'completed' and record['generation_call_count'] == 1
        and record['retry_count'] == 0 and record['weights_unchanged'] and record['hooks_restored'], 'Incomplete generation/restoration.')
    require(record['weights_before'] == record['weights_after']
        and record['weights_before']['entries_sha256'] == weights, 'Admitted weights differ.')
    require(identity(record['contract']) == identity(asdict(contract)) == record['contract_sha256']
        and record['generation_call'] == contract.generation_kwargs()
        and identity(record['loaded_generation_config']) == contract.generation_config_sha256, 'Generation contract differs.')
    require(record['trial_id'] == trial['trial_id'] and record['edit'] == trial['edit']
        and record['input_token_ids'] == ids and record['attention_mask'] == [1] * len(ids), 'Trial/input differs.')
    tokens = record['generated_token_ids']
    require(0 < len(tokens) <= contract.max_new_tokens
        and len(record['processed_logit_steps']) == len(tokens), 'Incomplete output tokens/scores.')
    details = record['depth_diagnostics']
    require(len(details['token_steps']) == len(tokens), 'Missing token-choice diagnostics.')
    for i, (token, detail, processed) in enumerate(zip(tokens, details['token_steps'], record['processed_logit_steps'], strict=True)):
        require(detail['step'] == processed['step'] == i and detail['selected_token_id'] == processed['selected_token_id'] == token,
            'Token diagnostic belongs to another step.')
        scores = detail['top_scores']
        require(len(scores) == len(detail['top_ids']) == len(detail['top_scores_finite']) == 5,
            'Wrong token diagnostic width.')
        require([score is not None for score in scores] == detail['top_scores_finite'], 'Masked score encoding differs.')
        finite = [score for score in scores if score is not None]
        require(detail['top_scores_finite'][0] is True
            and detail['top_scores_finite'] == sorted(detail['top_scores_finite'], reverse=True)
            and all(type(score) in (int, float) and math.isfinite(score) for score in finite)
            and finite == sorted(finite, reverse=True),
            'Invalid top-score ordering.')
        require(detail['selected_score'] == detail['maximum_score'] == scores[0],
            'Selected greedy score is not maximal.')
        if all(detail['top_scores_finite'][:2]):
            require(near(detail['top_two_margin'], scores[0] - scores[1]), 'Margin does not reproduce.')
        else:
            require(detail['top_two_margin'] is None, 'Undefined margin was assigned a value.')
    observations, states = record['state_observations'], details['state_steps']
    edit = trial['edit']
    if edit is None:
        require(not observations and not states and not record['calibration_prefill'] and record['applied_direction_sha256'] is None,
            'An unedited condition contains an intervention.')
        return {'edited_steps': 0, 'token_steps': len(tokens)}
    require(direction is not None and tensor_sha256(direction) == edit['direction_sha256']
        and tensor_sha256(direction.to(torch.bfloat16)) == record['applied_direction_sha256'], 'Direction identity/cast differs.')
    require(len(observations) == len(states) == len(tokens), 'Incomplete edit schedule.')
    width = direction.shape[1]
    require(len(record['calibration_prefill']) == 1, 'One complete prefill capture is required.')
    prefill = record['calibration_prefill'][0]
    require(prefill['layer'] == edit['layer'] and prefill['module_path'] == edit['module_path']
        and prefill['shape'] == [1, len(ids), width] and prefill['dtype'] == 'torch.bfloat16', 'Prefill location/shape differs.')
    raw = base64.b64decode(prefill['before'], validate=True)
    require(len(raw) == 2 * len(ids) * width, 'Prefill byte count differs.')
    full_before = torch.frombuffer(bytearray(raw), dtype=torch.bfloat16).clone().reshape(prefill['shape'])
    require(torch.isfinite(full_before).all().item(), 'Nonfinite prefill values.')
    full_after = full_before.clone()
    full_after[:, -1, :] += direction.to(torch.bfloat16) * edit['coefficient']
    require(tensor_sha256(full_before) == observations[0]['before_sha256']
        and tensor_sha256(full_after) == observations[0]['after_sha256'], 'Prefill bytes differ from generation observation.')
    displacements = []
    for i, (state, observation) in enumerate(zip(states, observations, strict=True)):
        before, after = (decode_state(state['values'], name, width) for name in ('before', 'after'))
        if i == 0:
            require(torch.equal(before, full_before[:, -1, :]) and torch.equal(after, full_after[:, -1, :]),
                'Selected-row diagnostics differ from the complete prefill.')
        expected = before + direction.to(torch.bfloat16) * edit['coefficient']
        require(torch.equal(after, expected), 'Recorded state is not the declared BF16 addition.')
        length = len(ids) if i == 0 else 1
        require(state['step'] == observation['forward_index'] == i
            and state['layer'] == observation['layer'] == edit['layer']
            and observation['module_path'] == edit['module_path']
            and observation['shape'] == [1, length, width] and observation['dtype'] == 'torch.bfloat16'
            and observation['exact_expected_state'] is True, 'Edited location differs.')
        delta = float((after.float() - before.float()).norm())
        initial, final = float(before.float().norm()), float(after.float().norm())
        require(near(delta, state['realized_l2']) and near(delta, observation['realized_l2'])
            and near(initial, state['before_l2']) and near(final, state['after_l2']), 'State norms do not reproduce.')
        require((initial == 0 and state['relative_displacement'] is None)
            or (initial > 0 and near(state['relative_displacement'], delta / initial)), 'Relative displacement differs.')
        require(observation['changed_batch_token_indices'] == ([] if edit['coefficient'] == 0 else [[0, length - 1]]),
            'Edit changed the wrong positions.')
        if length == 1:
            require(observation['before_sha256'] == tensor_sha256(before.reshape(1, 1, width))
                and observation['after_sha256'] == tensor_sha256(after.reshape(1, 1, width)), 'State bytes differ from observation hashes.')
        require(delta == 0 if edit['coefficient'] == 0 else delta > 0, 'Zero/nonzero edit differs.')
        displacements.append(state['relative_displacement'])
    return {'edited_steps': len(states), 'token_steps': len(tokens), 'relative_displacements': displacements}


def verify_outcome(request, evidence, *, tokenizer=None, direction_files=None):
    program = request['program']
    contract = validate_plan(program['qualification_plan'])
    plan = phase_plan(program, 'calibration', calibration_arms(program, request['directions']))
    directory = evidence / 'phases' / plan['run_id']
    result, terminal, phase = read(evidence / 'result.json'), read(evidence.parent / 'terminal.json'), read(directory / 'result.json')
    require(result['request_sha256'] == terminal['request_sha256'] == identity(request)
        and result['run_id'] == terminal['run_id'] == request['run_id'], 'Terminal identity differs.')
    require(terminal['process']['returncode'] == 0 and terminal['process'].get('timed_out') is False
        and terminal['status'] in run.TERMINAL, 'Outer execution did not complete successfully.')
    case = program['cases']['calibration'][0]
    with typed_decision_parser():
        scores = checked_scores(plan, [case], phase)
        baseline = phase['records'][0]
        require(baseline['execution_status'] == 'COMPLETED', 'No completed baseline.')
        admission = gate_module().admission(case, baseline['raw_response'])
        selection = select(plan, [case], phase)
        summary = summarize_calibration(plan, [case], phase)
    stopped = not admission['treatments_allowed_by_feasibility']
    count = 1 if stopped else 41
    status = 'CALIBRATION_STOPPED_BASELINE_FEASIBILITY' if stopped else 'CALIBRATION_COMPLETE'
    require(result['status'] == terminal['status'] == status, 'Wrong baseline-stop classification.')
    require(all(value == admission for value in (phase['baseline_admission'], result['baseline_admission'], read(directory / 'baseline_admission.json'))),
        'Baseline feasibility does not reproduce.')
    require(result['generation_calls'] == count and result['skipped_conditions'] == 41 - count
        and result['planned_conditions'] == 41, 'Generation/skip counts differ.')
    expected_session = {'model_load_attempts': 1, 'attempted_trials': count, 'generation_attempts': count,
        'generation_attempts_lower_bound': count, 'generation_count_verified': True,
        'completed_trials': count, 'failed': False, 'automatic_retry': False,
        'concurrent_generation': False, 'reuse_policy': REUSE_POLICY}
    require(result['session'] == expected_session and 0 < result['elapsed_seconds'] <= 7200,
        'Model-reuse accounting or runtime differs.')
    require(result['construction_repeated'] is False and result['automatic_retry'] is False
        and result['held_out_result'] is False and result['deployment'] is False, 'Execution scope differs.')
    require(phase['status'] == ('STOPPED_BASELINE_FEASIBILITY' if stopped else 'COMPLETE_NOT_SCIENTIFICALLY_QUALIFIED'), 'Phase status differs.')
    if stopped:
        require(phase['failure']['error_type'] == 'BaselineFeasibilityStop' and phase['failure']['technical_failure'] is False,
            'Baseline stop was not explicit.')
    else:
        require(phase['failure'] is None, 'Calibration has a failure.')
    loaded = read(evidence / 'shared_model/loaded_model.json')
    runtime = read(evidence / 'shared_model/runtime.json')
    qualified = program['qualification_plan']
    require(loaded['weights']['entries_sha256'] == qualified['model_weight_entries_sha256']
        and loaded['admitted_model_id'] == contract.model_id and loaded['admitted_model_revision'] == contract.model_revision
        and identity(loaded['generation_contract']) == identity(asdict(contract)), 'Shared model is not the admitted checkpoint.')
    reference = qualified['runtime_reference']
    require(runtime['versions'] == reference['actual_runtime_versions']
        and runtime['optional_kernels'] == reference['optional_kernel_module_visibility']
        and runtime['gpu']['name'] == reference['actual_gpu']['name']
        and runtime['gpu']['driver_version'] == reference['actual_gpu']['driver_version'], 'Runtime/GPU differs from qualification.')
    if tokenizer is None:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(run.ROOT / 'negotiation-steering/snapshots/qwen35-9b' / contract.model_revision / 'verified-snapshot'),
            local_files_only=True, trust_remote_code=False)
    inputs = read(evidence / 'input_admission.json')
    require(len(inputs) == 41, 'Input admission count differs.')
    baseline_receipt = None
    diagnostics = {}
    for i, (trial, row) in enumerate(zip(plan['trials'], phase['records'], strict=True)):
        require(read(directory / f'record-{i:05d}.json') == row, 'Original phase row differs.')
        ids = tokenizer.apply_chat_template(trial['messages'], tokenize=True, return_dict=False,
            add_generation_prompt=True, enable_thinking=False)
        require(inputs[i] == {'trial_id': trial['trial_id'], 'input_token_ids': ids, 'sha256': identity(ids),
            'within_limit': len(ids) <= contract.max_input_tokens} and inputs[i]['within_limit'], 'Input admission differs.')
        location = directory / trial['trial_id']
        if i >= count:
            require(row['execution_status'] == 'NOT_RUN_AFTER_FAILURE' and row['skip_reason'] == admission['status']
                and not location.exists(), 'A condition ran after baseline stop.')
            continue
        require(row['execution_status'] == 'COMPLETED' and row['score'] == scores[trial['trial_id']], 'Original score differs.')
        require(read(location / 'trial.json') == trial, 'Trial specification differs.')
        saved_generation = dict(row)
        saved_generation.pop('score')
        require(read(location / 'generation.json') == saved_generation, 'Original generation record differs.')
        source = row['source']
        path = location / run.delivery.safe_relative(source['source_log_path'])
        require(run.delivery.file_digest(path) == source['source_log_sha256'], 'Inspect log changed.')
        log = read_eval_log(str(path))
        require(log.status == 'success' and len(log.samples or []) == 1 and log.samples[0].error is None
            and log.samples[0].output.completion == row['raw_response'], 'Inspect output differs.')
        metadata = {'run_id': plan['run_id'], 'phase': plan['phase'], 'plan_sha256': identity(plan),
            'fixture_only': plan['fixture_only'], 'model_id': plan['model_id'], 'model_revision': plan['model_revision'],
            **{k: trial[k] for k in ('trial_id', 'case_id', 'family_id', 'arm_id', 'kind', 'edit', 'messages_sha256', 'case_content_sha256', 'output_contract_version')}}
        require(log.samples[0].id == source['source_sample_id'] == trial['trial_id']
            and log.samples[0].metadata['preparatory_trial'] == source['metadata'] == metadata, 'Inspect sample metadata differs.')
        records = read(location / 'state_execution.json')['records']
        require(len(records) == 1, 'One original execution record required.')
        record = records[0]
        require(read(location / 'input.json') == {'input_token_ids': ids, 'input_token_ids_sha256': identity(tuple(ids)),
            'messages_sha256': trial['messages_sha256']}, 'Saved input differs.')
        require(record['generated_token_ids'] == source['generated_token_ids']
            and tokenizer.decode(record['generated_token_ids'], skip_special_tokens=True) == row['raw_response'], 'Text/token mismatch.')
        require(read(location / 'loaded_model.json') == loaded, 'Trial load identity differs from shared origin.')
        require(read(location / 'model_use.json') == {'trial_id': trial['trial_id'], 'attempt_index': i + 1,
            'load_index': 1, 'reused_weights': i > 0, 'load_record': 'shared_model/loaded_model.json',
            'load_record_sha256': run.delivery.file_digest(evidence / 'shared_model/loaded_model.json'),
            'fresh_dynamic_cache_per_generation': True, 'past_key_values_supplied': False, 'concurrent_generation': False}, 'Model-use provenance differs.')
        expected = {**expected_session, 'attempted_trials': i + 1, 'generation_attempts': i + 1,
            'generation_attempts_lower_bound': i + 1, 'completed_trials': i + 1}
        require(read(location / 'model_session.json') == expected, 'Cumulative session counts differ.')
        direction = None
        if trial['edit']:
            matches = [entry for values in request['directions'].values() for entry in values.values()
                       if entry['sha256'] == trial['edit']['direction_sha256']]
            require(len(matches) == 1, 'Direction missing or ambiguous.')
            # Direction bytes are obtained from the bound source archive, not an inferred current vector.
            if direction_files is None:
                import zipfile
                with zipfile.ZipFile(run.DIRECTORY / 'source_payload.zip') as archive:
                    raw = archive.read('request/directions/' + matches[0]['path'])
            else:
                raw = direction_files[matches[0]['path']]
            require(run.delivery.digest(raw) == matches[0]['sha256'], 'Direction bytes changed.')
            direction = torch.frombuffer(bytearray(raw), dtype=torch.float32).clone().reshape(matches[0]['shape'])
        diagnostics[trial['arm_id']] = audit_record(record, trial, contract, qualified['model_weight_entries_sha256'], ids, direction)
        if i == 0:
            baseline_receipt = record
        if trial['kind'] == 'sham':
            require(all(record[key] == baseline_receipt[key] for key in ('input_token_ids', 'generated_token_ids', 'processed_logit_steps')),
                'Baseline versus zero-edit parity failed after intervening prompts.')
    require(selection == read(evidence / 'selection.json') == result['selection'], 'Selection does not reproduce.')
    require(summary == read(evidence / 'calibration_summary.json'), 'Summary does not reproduce.')
    return {'status': 'BASELINE_STOP_VERIFIED' if stopped else 'CALIBRATION_VERIFIED', 'completed_generations': count,
        'unrun_conditions': 41 - count, 'baseline_admission': admission, 'selection': selection,
        'worker_result': result, 'outer_terminal': terminal, 'rows': phase['records'], 'diagnostics': diagnostics,
        'proposals_changed': {row['arm_id']: (proposal_changed(row['score'], baseline['score'])
            if row['score']['valid'] and baseline['score']['valid'] else None)
            for row in phase['records'] if row['execution_status'] == 'COMPLETED'},
        'held_out_result': False, 'further_execution_authorized': False}


def audit():
    request, approval, package, _ = run.load()
    returned = run.DIRECTORY / 'launch/returned'
    receipt, manifest = read(returned / 'retrieval.json'), read(returned / 'manifest.json')
    require(receipt['status'] == 'ALL_COMMITTED_FILES_VERIFIED'
        and receipt['manifest_sha256'] == run.delivery.file_digest(returned / 'manifest.json'), 'Delivery is incomplete or changed.')
    require(manifest['run_id'] == request['run_id'] and manifest['transport_sha256'] == identity(package), 'Wrong returned run.')
    names = [row['path'] for row in manifest['files']]
    require(len(names) == len(set(names)) == receipt['file_count']
        and set(names) == {str(p.relative_to(returned / 'evidence')) for p in (returned / 'evidence').rglob('*') if p.is_file()}, 'Returned file set differs.')
    for row in manifest['files']:
        path = returned / 'evidence' / run.delivery.safe_relative(row['path'])
        require(path.stat().st_size == row['size_bytes'] and run.delivery.file_digest(path) == row['sha256'], 'Delivered file changed: ' + row['path'])
    require(read(returned / 'evidence/terminal.json') == manifest['terminal'] == read(returned / 'result.json'), 'Outer terminal copies differ.')
    evidence = returned / 'evidence/attempt'
    require(read(evidence / 'started.json') == {'request': request, 'approval': approval}, 'Worker started with other inputs.')
    report = verify_outcome(request, evidence)
    report.update(run_id=request['run_id'], request_sha256=identity(request),
        returned_files_verified=len(names), checked_at_utc=datetime.now(timezone.utc).isoformat(),
        research_model_loaded=False, model_generations=0, retry_performed=False)
    save_new(run.DIRECTORY / 'terminal_audit.json', report)
    return report


if __name__ == '__main__':
    result = audit()
    print(json.dumps({key: result[key] for key in ('status', 'completed_generations', 'selection')}), flush=True)
